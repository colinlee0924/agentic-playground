---
paths: ["src/**/*.py"]
---
# Python style (path-scoped)

- Python 3.12.x; use `from __future__ import annotations` in every file
- Type hints required on all public functions
- Use `httpx.AsyncClient` (not `requests`); always pass `timeout=` explicitly
- Format with `ruff format`; lint with `ruff check`
- Type-check with `mypy --strict`
- Tests with `pytest -v`; async tests use `pytest-asyncio`
- Logging: use `structlog` with `tenant_id`, `bu_id`, `trace_id` bound context
