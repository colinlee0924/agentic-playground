---
paths: ["src/agents/**", "specs/**/a2a-extensions/**", "src/shared/a2a_extensions.py"]
---
# A2A protocol rules (path-scoped)

When editing A2A-related code:

1. Use `a2a-sdk` version **1.0.2** exactly. Do not import from
   `a2a.legacy` or `a2a.experimental`.
2. AgentCard MUST be Ed25519-signed before serving on
   `/.well-known/agent.json`. Signing key path:
   `${MASK_KERNEL_AGENT_SIGNING_KEY}`.
3. AgentCard `extensions` array MUST list the URIs your agent supports:
   - `urn:m-corp:masksdk:trajectory:v1` (mandatory for all sub-agents)
   - `urn:m-corp:mask-kernel:handoff:v1` (mandatory for cross-BU agents)
4. When sending cross-BU messages, MUST propagate:
   - `tenant_id`, `bu_id` (multi-tenant invariant)
   - `trace_id` (Langfuse span propagation)
   - `langsmith_run_id` (if present)
5. Never use deprecated APIs:
   - ❌ `tasks/send` → ✅ `message/send`
   - ❌ `tasks/sendSubscribe` → ✅ `message/stream`

Reference: `.claude/skills/a2a-sub-agent/SKILL.md`,
`specs/mask-kernel/a2a-extensions/`.
