---
paths: ["src/pipe/**", "src/supervisor/**"]
---
# Streaming rules (path-scoped)

When editing code under `src/pipe/` or `src/supervisor/`:

1. **Never** emit `delta.tool_calls` chunks. Tool calls MUST render as
   `<details type="tool_calls">...</details>` markdown blocks.
2. **Always** terminate the Pipe response with
   `yield {"choices": [{"delta": {}, "finish_reason": "stop"}]}`.
3. **Never** call `get_stream_writer()` inside an `async def` tool. Use
   `from langchain_core.callbacks import adispatch_custom_event` instead.
4. Trajectory events MUST use one of these names:
   `trajectory.node.start`, `trajectory.node.end`, `trajectory.tool.call`,
   `trajectory.tool.result`, `trajectory.handoff`.
5. The Pipe MUST handle `__event_call__` timeouts by re-checkpointing to
   Postgres and pushing to Redis queue (see ADR-0007).

Reference: `.claude/skills/pipe-event-translation/SKILL.md`,
`docs/architecture/50-streaming-architecture.md`.
