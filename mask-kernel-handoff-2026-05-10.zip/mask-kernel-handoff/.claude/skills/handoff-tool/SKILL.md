---
name: handoff-tool
description: |
  Use this skill when wiring `Command(goto=..., graph=Command.PARENT)` handoff
  tools between sub-agents within the same BU. Trigger when the user mentions
  "handoff", "transfer to agent", "Command(goto=...)", "delegate to sub-agent".
  Do NOT use this skill for cross-BU handoff (use a2a-sub-agent skill + A2A
  send_message instead).
when_to_use: |
  - Adding a new same-BU handoff path between agents
  - Refactoring legacy RouteDecision-style routing
  - Debugging Command.PARENT routing failures
allowed-tools: [Read, Write, Edit, Bash]
---

# Skill: Wire a Command-based handoff tool

## When to use this skill

Trigger when implementing or modifying handoff between sub-agents that share
the same BU LangGraph. For cross-BU handoff, use `a2a-sub-agent` skill +
`a2a-sdk` `send_message` instead.

## Procedure

1. **Identify target node**. The `goto=` value MUST be a node name registered
   in the supervisor's `StateGraph`. Check `src/supervisor/graph.py`.
2. **Define handoff tool**. Use `make_handoff_tool` factory in
   `src/supervisor/handoff_tools.py`:
   ```python
   from src.supervisor.handoff_tools import make_handoff_tool
   handoff_to_wiki = make_handoff_tool(
       target_agent="wiki_agent", bu_id="BU-A"
   )
   ```
3. **Emit trajectory event BEFORE Command return**. After `return Command(...)`
   the event won't fire. Use `adispatch_custom_event("trajectory.handoff", ...)`.
4. **Add to supervisor's tool list**:
   ```python
   supervisor = create_agent(
       model=model,
       tools=[handoff_to_wiki, handoff_to_jira, ...],
       middleware=[TodoListMiddleware(), ReflectorMiddleware()],
   )
   ```
5. **Test the routing path**. Add to `tests/unit/test_handoff_routing.py`:
   - Mock LLM returning the handoff tool call
   - Assert the supervisor graph routes to the target node

## Pitfalls

- ❌ Calling `Command(graph=Command.PARENT)` from a node that is itself the
  parent graph — it has no parent, will raise `GraphInvocationError`.
- ❌ Using `Command(goto=END)` to terminate — use `return AIMessage(...)`
  instead so the trajectory tree closes properly.
- ❌ Forgetting to dispatch the trajectory event — the iframe will not show
  the edge animation.
- ❌ Hard-coding agent names as strings throughout the codebase — use the
  `AGENT_NAMES` enum in `src/supervisor/handoff_tools.py`.

## References

- ADR-0001: sub-agent-as-tool pattern
- ADR-0002: BU-internal Command + cross-BU A2A
- `specs/mask-kernel/supervisor-spec.md`
- `src/supervisor/handoff_tools.py` (existing example)
