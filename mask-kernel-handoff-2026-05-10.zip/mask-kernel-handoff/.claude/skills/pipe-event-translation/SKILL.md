---
name: pipe-event-translation
description: |
  Use this skill when implementing or debugging the Open WebUI Pipe Function's
  translation from LangGraph / AG-UI events into Open WebUI's emit calls.
  Trigger when the user mentions "Pipe Function", "Open WebUI emit", "tool
  call rendering", "delta.tool_calls", "30-retry bug", "AG-UI event", or
  reports streaming bugs (no output, infinite loop, missing tool call display).
when_to_use: |
  - Wiring a new event type from LangGraph to Open WebUI display
  - Debugging the 30-retry bug or stuck-streaming issues
  - Adding new event types for trajectory iframe consumption
allowed-tools: [Read, Write, Edit, Bash]
---

# Skill: Translate AG-UI / LangGraph events to Open WebUI emit

## When to use this skill

Trigger when modifying `src/pipe/event_translator.py` or debugging streaming
issues between LangGraph and Open WebUI's chat UI.

## Event mapping table

| Source event | Target | Notes |
|---|---|---|
| `on_chain_start` (node) | `__event_emitter__("status", {...})` | Show "running node X" |
| `on_chat_model_stream` | `yield {"choices":[{"delta":{"content": chunk}}]}` | Token streaming |
| `on_tool_start` | Append `<details type="tool_calls" data-tool="X">` | NOT delta.tool_calls |
| `on_tool_end` | Close `</details>` block | Render result inside |
| `trajectory.handoff` | `__event_emitter__("status")` + iframe postMessage | Edge animation |
| `__interrupt__` | `__event_call__({"type":"input"})` | HITL approval |
| End of stream | `yield {"choices":[{"delta":{},"finish_reason":"stop"}]}` | MANDATORY |

## Procedure

1. **Read** `src/pipe/event_translator.py` and `src/pipe/mask_kernel_pipe.py`
   to understand current structure.
2. **For new event types**: add a handler function `handle_<event_name>(...)`
   in `event_translator.py`, return either a markdown string or an emitter
   call dict.
3. **For tool call rendering**: produce markdown like:
   ```
   <details type="tool_calls" data-tool="search_jira" data-status="running">
   <summary>🔧 search_jira</summary>
   ```json
   {"args": {...}, "result": null}
   ```
   </details>
   ```
4. **Always end with `finish_reason: stop`**. Never finish with `tool_calls`
   or no terminator at all.
5. **Test with** `pytest src/tests/unit/test_event_translation.py -v`.

## Pitfalls (the 30-retry bug)

If you see Open WebUI repeatedly calling your pipe (~30 times) for one user
message, you almost certainly emitted `delta.tool_calls`. Open WebUI sees
those as native tool calls to execute and loops back. Fix by removing all
`delta.tool_calls` emissions and rendering tools as markdown details.

Reference: Open WebUI issues #23066, #23118.

## Other pitfalls

- ❌ Forgetting `finish_reason: stop` — UI hangs forever.
- ❌ Calling `get_stream_writer()` in an async tool — use
  `adispatch_custom_event`.
- ❌ Emitting trajectory events to the main message body — use the iframe
  channel via Redis pub/sub instead.

## References

- ADR-0003: Open WebUI Pipe + iframe short-term frontend
- `docs/architecture/50-streaming-architecture.md`
- `.claude/rules/streaming-rules.md` (auto-loaded for src/pipe/**)
