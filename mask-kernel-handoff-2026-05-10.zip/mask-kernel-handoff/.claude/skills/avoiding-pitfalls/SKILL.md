---
name: avoiding-pitfalls
description: |
  Use this skill to audit code for known mask-kernel anti-patterns and verify
  CI grep gates pass. Trigger before any merge, when the user mentions "code
  review", "audit", "anti-pattern check", "CI failing", or after any large
  refactor. Also trigger proactively when reading legacy code from external
  sources (StackOverflow, Coding-Crashkurse, blog tutorials).
when_to_use: |
  - Pre-merge audit
  - Onboarding review of external/legacy code
  - Investigating CI grep gate failures
allowed-tools: [Read, Bash, Grep]
---

# Skill: Audit code for mask-kernel anti-patterns

## When to use this skill

Trigger when reviewing code that may contain known anti-patterns. This skill
runs the same grep gates as CI plus contextual checks.

## Anti-pattern checklist

Run this checklist on any code being merged or copied into the repo:

| Pattern | Detection | Why banned | Reference |
|---|---|---|---|
| `from langgraph_supervisor` | grep | Soft-deprecated by LangChain team | ADR-0001 |
| `from langgraph_swarm` | grep | Untested with v1 `create_agent` | ADR-0001 |
| `delta.tool_calls` emit | grep in src/pipe | Triggers Open WebUI 30-retry bug | Issue #23066 |
| `get_stream_writer()` in async | grep + AST | LangGraph #6447, race condition | LangGraph issue |
| `RouteDecision` Pydantic class | grep | Deprecated routing pattern | ADR-0008 |
| Missing `finish_reason: stop` | AST: trailing yield | UI hangs forever | Article III |
| Hardcoded AIDE Gateway URL | grep `aide.*\.m-corp\.` | Should be env var | Security |
| Direct cross-BU module import | grep `from src\.agents\.bu_` | Multi-tenant violation | Article IX |
| `Command(graph=Command.PARENT)` from root | static analysis | Would raise `GraphInvocationError` | handoff-tool skill |
| Missing AgentCard signature | grep `agent_card.json` w/o `signature` | Security gate | A2A protocol |

## Procedure

1. **Run grep gates** (same as CI):
   ```bash
   grep -rE "from langgraph_supervisor|from langgraph_swarm" src/ && exit 1
   grep -rE "delta\.tool_calls" src/pipe/ && exit 1
   grep -rE "get_stream_writer\(.*async" src/ && exit 1
   grep -rE "class RouteDecision\b" src/ && exit 1
   ```
2. **Run AST checks**:
   ```bash
   python -m src.shared.audit --check-finish-reason --check-graph-parent
   ```
3. **Read context** for any flagged pattern. Some patterns may be in test
   fixtures or migration scripts (allowed via `# noqa: pitfall-X` comment
   with ADR reference).
4. **Generate audit report**:
   ```bash
   python -m src.shared.audit --format markdown > /tmp/audit.md
   ```

## When to override (with caution)

A pattern can be allowed via `# noqa: pitfall-<name>` if:
- It is in a `tests/legacy/` migration test
- It has an inline ADR reference proving the override is approved
- The override is reviewed by Colin (Tech Lead)

Example:
```python
# noqa: pitfall-langgraph-supervisor — see ADR-0009 (legacy migration shim)
from langgraph_supervisor import create_supervisor
```

## References

- `docs/architecture/90-anti-patterns.md` (full evidence)
- `memory/constitution.md` Article VII
- `src/shared/audit.py` (the grep gate runner)
