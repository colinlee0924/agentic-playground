---
name: trajectory-iframe
description: |
  Use this skill when working on the trajectory tree iframe rendering — the
  visual execution tree shown in Open WebUI alongside the chat. Trigger when
  the user mentions "trajectory tree", "iframe", "execution graph",
  "trajectory visualization", "Cytoscape", "edge animation", or reports the
  iframe is missing/broken/stale.
when_to_use: |
  - Adding a new node type to the trajectory visualization
  - Fixing iframe sandbox / cross-tab cross-talk issues
  - Wiring a new trajectory event to the iframe consumer
allowed-tools: [Read, Write, Edit, Bash]
---

# Skill: Render trajectory tree inside Open WebUI embeds iframe

## When to use this skill

Trigger when modifying `src/artifacts/trajectory_tree.html` or the
trajectory-relay code that feeds it. The iframe is the **only** safe way to
render trajectory in Open WebUI because main-message rendering suffers from
multi-tab cross-talk.

## Architecture

```
LangGraph events
   │  (adispatch_custom_event "trajectory.*")
   ▼
src/trajectory_relay/relay.py
   │  (Redis pub/sub: trajectory:<thread_id>)
   ▼
src/artifacts/trajectory_tree.html (iframe)
   │  (SSE consumer: GET /trajectory/<thread_id>/stream)
   ▼
Cytoscape.js render
```

## Procedure

1. **Add new event type in supervisor**:
   ```python
   await adispatch_custom_event("trajectory.tool.call", {
       "tool": "search_jira",
       "args": {...},
       "node": "jira_agent",
       "trace_id": trace_id,
   })
   ```
2. **Relay handler in `src/trajectory_relay/relay.py`** subscribes to events,
   transforms to Cytoscape graph delta, publishes to Redis.
3. **iframe consumer** in `trajectory_tree.html` opens an SSE connection,
   applies graph deltas to Cytoscape instance.
4. **Multi-tab isolation**: every iframe instance subscribes to a thread-
   specific Redis channel `trajectory:<thread_id>`. Other tabs receive
   nothing (this prevents cross-talk).
5. **Test rendering**:
   ```bash
   docker compose up -d
   open http://localhost:9100/trajectory/test-thread/preview
   ```

## Pitfalls

- ❌ Subscribing to a global trajectory channel — causes cross-tab leakage.
- ❌ Rendering trajectory in main message body — Open WebUI multi-tab race.
- ❌ Forgetting iframe `sandbox="allow-scripts"` — will break Cytoscape.
- ❌ Using server-side HTML generation for trajectory updates — too slow
  for streaming; always do client-side incremental updates.

## References

- ADR-0003: Open WebUI Pipe + iframe short-term frontend
- `docs/architecture/50-streaming-architecture.md` (section 7)
- `src/artifacts/trajectory_tree.html`
- `src/trajectory_relay/relay.py`
