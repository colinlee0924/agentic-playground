---
name: a2a-sub-agent
description: |
  Use this skill when adding a new BU sub-agent to mask-kernel, scaffolding an
  A2A-protocol-compliant agent (LangChain create_agent + a2a-sdk AgentCard +
  Trajectory extension). Trigger this skill whenever the user mentions
  "new sub-agent", "add BU agent", "create jira-style agent", "scaffold agent",
  even if they don't explicitly say A2A.
when_to_use: |
  - User asks to add a new BU agent
  - User asks "how do I create a sub-agent?"
  - User pastes an AgentCard and asks to wire it up
allowed-tools: [Read, Write, Edit, Bash]
---

# Skill: Add an A2A-compliant sub-agent

## When to use this skill

Trigger when the user wants to scaffold a new BU sub-agent that conforms to
`specs/mask-kernel/sub-agent-spec.md`. This skill produces a runnable agent
package under `src/agents/<name>_agent/` with `agent.py`, `tools.py`,
`agent_card.json`, `CLAUDE.md`, and a contract test.

## Procedure (step-by-step)

1. **Confirm name + BU**. Ask user for `name` (snake_case) and `bu_id` (e.g., BU-D).
2. **Read the spec**. Open `specs/mask-kernel/sub-agent-spec.md` and
   `specs/mask-kernel/a2a-extensions/trajectory-v1.md`.
3. **Copy template**. Duplicate `src/agents/jira_agent/` as starting point.
4. **Update `agent.py`**:
   - Replace agent name in `create_agent(name=...)`
   - Wire in BU-specific tools from `tools.py`
   - Ensure `adispatch_custom_event("trajectory.node.start", ...)` is called
5. **Author `tools.py`**: each tool MUST be `async def`, MUST raise on auth
   failure, MUST use `httpx.AsyncClient` with AIDE JWT bearer.
6. **Generate `agent_card.json`** with the URN extensions:
   `urn:m-corp:masksdk:trajectory:v1` and `urn:m-corp:mask-kernel:handoff:v1`.
   Sign with Ed25519 key from `${MASK_KERNEL_AGENT_SIGNING_KEY}`.
7. **Register in supervisor**: edit `src/supervisor/handoff_tools.py` to add a
   `Command(goto="<name>_agent", graph=Command.PARENT)` handoff tool.
8. **Write tests**: copy `tests/contract/test_sub_agent_conformance.py`
   template, add E2E scenario in `tests/e2e/`.
9. **Lint & test**: `ruff check`, `mypy`, `pytest src/tests/contract/`.
10. **Update `CLAUDE.md`** in the new agent dir (use
    `src/agents/jira_agent/CLAUDE.md` as template).

## Pitfalls

- ❌ Do NOT use `langgraph-supervisor`; this repo uses sub-agent-as-tool
  (ADR-0001).
- ❌ Do NOT call `get_stream_writer()` in an async tool — use
  `adispatch_custom_event`.
- ❌ Do NOT emit `delta.tool_calls` to the pipe — render markdown instead.
- ❌ Do NOT skip the Ed25519 signature on AgentCard — security gate fails CI.
- ❌ Do NOT hardcode AIDE Gateway URL — read from
  `os.environ["AIDE_GATEWAY_URL"]`.

## References

- Spec: `specs/mask-kernel/sub-agent-spec.md`
- ADR: `docs/decisions/0001-sub-agent-as-tool.md`
- Existing example: `src/agents/jira_agent/`
- A2A protocol v1.0.0 (Linux Foundation, 2026-03)
- Anti-patterns: `docs/architecture/90-anti-patterns.md`
