---
name: hitl-approval-flow
description: |
  Use this skill when implementing Human-in-the-Loop approval flows in
  mask-kernel. Trigger when the user mentions "HITL", "approval", "human
  approval", "interrupt", "checkpoint resume", or asks to add a destructive
  action that needs sign-off.
when_to_use: |
  - Adding a new write/destructive operation that needs approval
  - Debugging interrupt/resume flow
  - Migrating from event-only to checkpoint+queue dual storage
allowed-tools: [Read, Write, Edit, Bash]
---

# Skill: Implement HITL approval flow

## When to use this skill

Trigger when adding a write operation (JIRA mutation, Wiki page update, build
trigger, etc.) that requires human sign-off before execution. This skill
implements the **checkpoint + Redis queue dual-storage** pattern from
ADR-0007.

## Architecture (from ADR-0007)

```
LangGraph node                         Pipe Function                  User
    │                                       │                          │
    ├─ interrupt({"approval": ...}) ────────┤                          │
    │  (writes Postgres checkpoint)         │                          │
    │                                       ├─ __event_call__(...)  ───┤
    │                                       │  (renders form iframe)   │
    │                                       │                       click
    │                                       ├──── decision ◄───────────┤
    │                                       │                          │
    │                              (Redis queue: hitl:approvals)       │
    │  ◄─────── resume(decision) ────────── │                          │
    │  (loads checkpoint, continues)        │                          │
```

## Procedure

1. **In the LangGraph node**, raise `interrupt`:
   ```python
   from langgraph.types import interrupt
   decision = interrupt({
       "type": "approval_required",
       "action": "jira.add_comment",
       "payload": {"issue_key": "PROJ-123", "comment": "..."},
       "render_hint": "hitl_form.html",
   })
   if decision["approved"]:
       return await jira_client.add_comment(...)
   else:
       return {"status": "rejected", "reason": decision.get("reason")}
   ```
2. **In the Pipe**, detect `__interrupt__` event and call `__event_call__`:
   ```python
   if event.kind == "interrupt":
       result = await __event_call__({
           "type": "input",
           "data": {"render": event.payload["render_hint"], ...}
       })
       # Push to Redis as second source of truth
       await redis.lpush(
           f"hitl:approvals:{tenant_id}:{thread_id}",
           json.dumps(result)
       )
       # Resume the graph
       async for ev in graph.astream(
           Command(resume=result),
           config={"configurable": {"thread_id": thread_id}}
       ):
           ...
   ```
3. **Postgres checkpoint** is automatic via `AsyncPostgresSaver`. Verify:
   ```python
   checkpointer = AsyncPostgresSaver.from_conn_string(DATABASE_URL)
   graph = builder.compile(checkpointer=checkpointer)
   ```
4. **Redis queue** is the second source of truth in case the websocket
   disconnects mid-approval. The supervisor periodically scans
   `hitl:approvals:*` keys and resumes orphaned threads.
5. **HTML form** lives in `src/artifacts/hitl_form.html` and is rendered via
   the embeds iframe mechanism.
6. **Test resume after kill**:
   ```bash
   pytest src/tests/e2e/test_hitl_resume.py -v
   ```

## Pitfalls

- ❌ Long-poll for approval (will time out, lose state).
- ❌ Storing approval state in Python dict / in-memory cache.
- ❌ Forgetting to set `thread_id` in `config["configurable"]` — checkpoint
  cannot be resumed without it.
- ❌ Approving from one BU on another BU's thread — multi-tenant violation.

## References

- ADR-0007: HITL = checkpointer + Redis queue dual storage
- `specs/mask-kernel/api-contracts.md` (HITL section)
- `src/supervisor/handoff_tools.py` (existing pattern)
- `src/artifacts/hitl_form.html` (form template)
