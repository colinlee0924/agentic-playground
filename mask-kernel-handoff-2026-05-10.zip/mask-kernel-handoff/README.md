# mask-kernel SDK Handoff Package

> **M 公司 JIRA × AI Task Force — 2026-05 release**
> Owner: Colin (Senior SWE, Tech Lead)

## 這是什麼 / What is this

mask-kernel 是 M 公司內部 air-gapped 多代理框架,服務 ~9000 user × 15 BU。
本包是「**架構決策定稿 + 可執行 PoC + Claude Code 開發包**」三合一交付物。

mask-kernel is M-Corp's air-gapped multi-agent framework serving ~9000 users
across 15 BUs. This package bundles **finalized architecture decisions +
runnable PoC + Claude-Code-ready dev kit**.

## 角色閱讀路徑 / Role-based reading paths

| 角色 Role | 路徑 Path |
|---|---|
| **架構師 / Architect** | `INDEX.md` → `docs/architecture/00-overview.md` → `docs/decisions/0001`–`0008` → `docs/rfc/` |
| **後端工程師 / Backend Engineer** | `docs/architecture/30-multi-agent-architecture.md` → `specs/mask-kernel/` → `src/` → `tasks/backlog.md` |
| **前端工程師 / Frontend Engineer** | `docs/architecture/20-frontend-roadmap.md` → `docs/architecture/50-streaming-architecture.md` → `src/pipe/` → `src/artifacts/` |
| **PM / TPM** | `README.md` → `INDEX.md` → `docs/appendix/conversation-summary.md` → `docs/rfc/RFC-001` |
| **Claude Code** | `CLAUDE.md` → `memory/constitution.md` → `.claude/skills/` → `specs/001-poc-end-to-end/spec.md` → `tasks/backlog.md` |

## 中英分層原則 / Bilingual layering

- **繁中** — `docs/architecture/`, `docs/decisions/`, `docs/rfc/`, `docs/appendix/` (人讀,內部評審)
- **English** — `CLAUDE.md`, `.claude/skills/`, `specs/`, `src/`, `tasks/`, `memory/` (Claude Code 解析最佳化)
- **雙語** — `README.md`, `INDEX.md`, `GLOSSARY.md`

## 30 秒快速啟動 / 30-second quickstart

```bash
cd src/
cp .env.example .env       # 填入 AIDE Gateway URL、Postgres、Redis、Langfuse
docker compose up -d
# 開 http://localhost:3000 (Open WebUI),選 mask-kernel pipe
# 輸入 "PROJ-123 進度?還有 mask-design-spec 的最新狀態?"
```

## 核心技術棧 / Locked tech stack

LangChain **1.2.x** + LangGraph **1.1.x** + a2a-sdk **1.0.2** (A2A v1.0.0, LF 2026-03)
+ Postgres (self-hosted) + Redis (self-hosted) + Langfuse (self-hosted) + AIDE IT Gateway

任何一個鎖版本元件升級皆需新 ADR (詳見 `memory/constitution.md` Article V)。

## 目錄結構 / Directory layout

```
mask-kernel-handoff/
├── README.md / INDEX.md / GLOSSARY.md / CLAUDE.md
├── memory/constitution.md
├── .claude/{rules,skills}/
├── docs/
│   ├── architecture/      # 繁中架構決策
│   ├── decisions/         # MADR 4.0 ADR
│   ├── rfc/               # 提案討論
│   └── appendix/          # 摘要與引用
├── specs/                 # 英文 spec (Spec-Driven Development)
├── src/                   # 可執行 PoC (docker compose up)
└── tasks/                 # Claude Code dispatch list
```

## 授權 / License

內部使用 (M-Corp internal). 所有第三方授權見 `docs/appendix/references.md`.
