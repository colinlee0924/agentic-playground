# 術語對照表 / Glossary

| 中文 | English | 定義 / Definition |
|---|---|---|
| 子代理 | sub-agent | 單一 BU 內、被 supervisor 以 tool 形式呼叫的 agent |
| 監督者 | supervisor | 協調多個 sub-agent 的中央 LangGraph,擁有 trajectory + checkpoint |
| 移交 | handoff | `Command(goto=..., graph=Command.PARENT)` 或 A2A `agent.send_message` 的控制權轉移 |
| 軌跡 | trajectory | supervisor + 所有 sub-agent 的執行樹,以 iframe 渲染 |
| 軌跡中繼 | trajectory-relay | Redis pub/sub,把 LangGraph events 轉成前端可消費流 |
| 人類在迴路 | HITL (Human-in-the-Loop) | `__event_call__` 觸發 Postgres checkpoint + Redis queue 雙保險 |
| 反思器 | Reflector | 寫操作前的二次驗證 middleware |
| 計畫-執行-重規劃 | Plan-Execute-Replan | 巨型分析任務的 supervisor pattern,>5 步任務時啟用 |
| 待辦清單中介軟體 | TodoListMiddleware | LangGraph supervisor 的標準 middleware,管 step list |
| 代理卡 | AgentCard | a2a-sdk 的 agent metadata,含 name/version/capabilities/extensions/signature |
| 業務單位 | BU (Business Unit) | M 公司內部組織單位,每個 BU 獨立 tenant 隔離 |
| 氣隙 | air-gapped | 完全脫離外部網路的內網環境 |
| 嵌入框 | embeds iframe | Open WebUI 的 iframe 渲染機制,用於避免 multi-tab cross-talk |
| 軌跡擴充 | Trajectory Extension | A2A 自訂擴充 URI `urn:m-corp:masksdk:trajectory:v1` |
| 移交擴充 | Handoff Extension | A2A 自訂擴充 URI `urn:m-corp:mask-kernel:handoff:v1` |
| 反模式 | anti-pattern | 已驗證會產生問題的寫法,CI 強制阻擋 |
| 鎖版本 | locked version | 不可隨意升級,需新 ADR 才能變更 |
| 規格驅動開發 | SDD (Spec-Driven Development) | spec.md → plan.md → tasks.md 三層工作流 |
| 架構決策紀錄 | ADR (Architecture Decision Record) | MADR 4.0 格式,團隊評審用 |
| 提案請求 | RFC (Request for Comments) | 開放討論的提案,尚未定案 |
