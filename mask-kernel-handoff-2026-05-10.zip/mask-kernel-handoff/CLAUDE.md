# mask-kernel — Claude Code Project Memory

<!-- Maintainer: Colin. Last updated: 2026-05-10. Target length: <200 lines. -->
<!-- Procedures live in .claude/skills/. File-scoped rules in .claude/rules/. -->

## Project overview

mask-kernel is M-Corp's internal multi-agent SDK. It powers a JIRA + Wiki +
Build-Status assistant for ~9000 engineers across 15 BUs in an **air-gapped
intranet**. The system is built on **LangChain 1.2.x + LangGraph 1.1.x + a2a-sdk
1.0.2 (A2A protocol v1.0.0)**.

Frontend roadmap: Open WebUI (now) → LibreChat + Assistant-UI (mid) →
AG-UI/CopilotKit + A2UI (long).

For Chinese architecture rationale see `@docs/architecture/00-overview.md`.
For immutable principles see `@memory/constitution.md`.

## Architecture invariants (DO NOT violate)

1. **Two-layer routing**: within a BU use `Command(goto=..., graph=Command.PARENT)`;
   across BUs use `a2a-sdk` agent-to-agent messages. Never call a peer BU directly.
2. **Sub-agent as tool**: supervisor owns the graph; sub-agents are invoked via
   tool calls, never via the deprecated `langgraph-supervisor` package.
3. **TodoListMiddleware** is the supervisor backbone. Layer **Reflector** for
   write ops. Layer **Plan-Execute-Replan** only for analysis tasks > 5 steps.
4. **Streaming contract**: tool calls render as `<details type="tool_calls">`
   markdown blocks. **Never emit `delta.tool_calls`** to Open WebUI (triggers
   issue #23066/#23118 30-retry bug).
5. **Pipe Function MUST yield `finish_reason: stop`** at the end of every
   response.
6. **Custom A2A Extension URIs are frozen**:
   - `urn:m-corp:masksdk:trajectory:v1`
   - `urn:m-corp:mask-kernel:handoff:v1`
7. **HITL** uses `__event_call__` + `AsyncPostgresSaver` checkpoint + Redis
   queue. No long-poll.
8. **Trajectory tree** renders inside an Open WebUI **`embeds` iframe** to
   avoid multi-tab cross-talk.

## Tech stack (locked versions)

| Component | Version | Source of truth |
|---|---|---|
| Python | 3.12.x | `pyproject.toml` |
| langchain | 1.2.x | `requirements.txt` |
| langgraph | 1.1.x | `requirements.txt` |
| a2a-sdk | 1.0.2 | `requirements.txt` (do not bump without ADR) |
| langfuse | self-hosted, 2026-Q1 build | `docker-compose.yml` |
| Postgres | 16.x | `docker-compose.yml` |
| Redis | 7.x | `docker-compose.yml` |
| Open WebUI | latest stable | `docker-compose.yml` |

Pinning rationale: `@docs/architecture/10-tech-stack.md`. Bumping any of the
four locked items (langchain, langgraph, a2a-sdk, A2A protocol) requires a
new ADR.

## Critical anti-patterns (will be rejected in code review)

- ❌ `from langgraph_supervisor import ...` — soft-deprecated upstream.
- ❌ `from langgraph_swarm import ...` — incompatible with LangChain v1
  `create_agent`.
- ❌ Using `RouteDecision` (LLM with structured output → if/else) — use
  handoff tools.
- ❌ Emitting `delta.tool_calls` chunks — break Open WebUI; render markdown
  instead.
- ❌ Calling `get_stream_writer()` inside an `async` tool — use
  `adispatch_custom_event`.
- ❌ Coding-Crashkurse RouteDecision pattern — outdated for production
  multi-agent.
- ❌ CrewAI hierarchical mode (issue #4783) — manager delegation fails.

Full evidence: `@docs/architecture/90-anti-patterns.md`.

## Run commands

```bash
# Boot full stack (Open WebUI, Postgres, Redis, Langfuse, mask-kernel)
cd src && docker compose up -d

# Run a single agent locally
python -m src.agents.jira_agent.agent

# Run E2E test (PROJ-123 + mask-design-spec scenario)
pytest src/tests/e2e/test_proj123_scenario.py -v

# Lint + type-check before commit
ruff check src/ && mypy src/

# Generate trajectory inspection HTML
python -m src.trajectory_relay.relay --dump-html /tmp/trace.html
```

## Testing guidelines

- Every new sub-agent MUST ship: 1 unit test for tools, 1 contract test
  against `specs/mask-kernel/sub-agent-spec.md`, 1 E2E scenario in
  `src/tests/e2e/`.
- HITL flows MUST be tested with `langgraph.checkpoint.postgres` resume after
  `kill -9` (use `tests/e2e/test_hitl_resume.py` as template).
- Never mock the AIDE Gateway in E2E; use the staging endpoint with rotating
  JWT.

## Skills

The following skills are auto-loaded from `.claude/skills/`:
`a2a-sub-agent`, `handoff-tool`, `pipe-event-translation`,
`hitl-approval-flow`, `trajectory-iframe`, `avoiding-pitfalls`.

When the user asks to add a new BU agent, prefer the `a2a-sub-agent` skill.
When debugging streaming, prefer `pipe-event-translation`.

## Imports

@memory/constitution.md
@.claude/rules/streaming-rules.md
@.claude/rules/a2a-protocol.md
