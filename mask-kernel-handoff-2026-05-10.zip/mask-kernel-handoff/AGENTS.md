# AGENTS.md

This file is intentionally a thin pointer to `CLAUDE.md` for compatibility
with agents (e.g., GitHub Copilot, Cursor) that look for `AGENTS.md`.

The authoritative project memory lives in `CLAUDE.md` at the repo root.
