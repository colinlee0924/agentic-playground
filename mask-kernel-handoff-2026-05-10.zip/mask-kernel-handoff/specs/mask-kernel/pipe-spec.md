# Pipe Function Specification

## Interface (Open WebUI Pipe contract)

```python
class Pipe:
    class Valves(BaseModel):
        SUPERVISOR_URL: str
        AIDE_GATEWAY_URL: str
        REDIS_URL: str

    def __init__(self):
        self.valves = self.Valves()

    async def pipe(
        self,
        body: dict,
        __user__: dict,
        __event_emitter__: Callable,
        __event_call__: Callable,
    ) -> AsyncGenerator[dict | str, None]:
        ...
```

## Required behaviors

1. **Initial chunk**: send role announcement
2. **Token stream**: yield `{"choices":[{"delta":{"content": chunk}}]}`
3. **Tool calls**: render as markdown `<details type="tool_calls">` (NOT delta.tool_calls)
4. **HITL**: on `__interrupt__`, call `__event_call__` AND push to Redis queue
5. **Trajectory**: emit `__event_emitter__("status", ...)` for major milestones; iframe receives via Redis pub/sub
6. **Final chunk**: yield `{"choices":[{"delta":{},"finish_reason":"stop"}]}`

## Anti-patterns (CI gates)

- ❌ Yielding chunks with `delta.tool_calls` field
- ❌ Missing final `finish_reason: stop`
- ❌ Calling `get_stream_writer()` inside Pipe's async generator

## Reference

- ADR-0003
- `.claude/skills/pipe-event-translation/SKILL.md`
- `src/pipe/mask_kernel_pipe.py`
