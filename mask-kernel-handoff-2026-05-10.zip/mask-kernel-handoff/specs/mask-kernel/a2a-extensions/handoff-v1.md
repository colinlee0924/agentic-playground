# A2A Extension: mask-kernel Handoff v1

**URI**: `urn:m-corp:mask-kernel:handoff:v1`
**Status**: stable (frozen)

## Purpose

Carry handoff intent across A2A boundaries: who is asking whom to do what,
with which constraints, and how the result should be delivered back.

## Message metadata schema

```json
{
  "extensions": {
    "urn:m-corp:mask-kernel:handoff:v1": {
      "from_agent": "supervisor.bu-a",
      "to_agent": "supervisor.bu-b",
      "intent": "delegate | request_info | escalate",
      "task": {
        "summary": "Check build status of mask-design-spec",
        "deadline_hint": "2026-05-10T18:00:00Z",
        "priority": "normal | high | critical"
      },
      "return_path": {
        "callback_url": "...",
        "thread_id": "..."
      }
    }
  }
}
```

## Receiver behavior

1. Validate sender is in `allowed_callers` of receiver's AgentCard
2. Bind handoff metadata to its supervisor state
3. Honor `priority` for queue ordering
4. Return result via `return_path` when complete (or via SSE if streaming)
