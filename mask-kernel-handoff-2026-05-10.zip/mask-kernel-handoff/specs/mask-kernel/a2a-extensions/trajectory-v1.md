# A2A Extension: mask-kernel Trajectory v1

**URI**: `urn:m-corp:masksdk:trajectory:v1`
**Status**: stable (frozen, see constitution Article VI)

## Purpose

Carry execution trajectory information across A2A message boundaries so that
cross-BU calls produce a unified trajectory tree in the trajectory iframe.

## AgentCard declaration

```json
{
  "extensions": ["urn:m-corp:masksdk:trajectory:v1"]
}
```

## Message metadata schema

```json
{
  "extensions": {
    "urn:m-corp:masksdk:trajectory:v1": {
      "trace_id": "uuid",
      "parent_span_id": "uuid",
      "events": [
        {
          "kind": "trajectory.node.start | trajectory.tool.call | ...",
          "ts": "2026-05-10T10:00:00Z",
          "payload": {...}
        }
      ]
    }
  }
}
```

## Receiver behavior

The receiving a2a-server MUST:
1. Inherit `trace_id` and bind to its Langfuse span
2. Append received events to its local trajectory store
3. Emit own events with `parent_span_id` referencing inherited span
