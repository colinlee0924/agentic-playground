# mask-kernel Architecture Spec

> Authoritative English spec of record. Chinese rationale lives in
> `docs/architecture/`.

## Overview

mask-kernel is a multi-agent SDK with the following high-level components:

1. **Supervisor**: LangGraph compiled graph with TodoListMiddleware + Reflector + Plan-Execute-Replan middleware stack.
2. **Sub-agents**: Per-BU agents (jira_agent, wiki_agent, build_agent, ...). Same-BU sub-agents are nodes in a single LangGraph; cross-BU sub-agents communicate via a2a-sdk.
3. **Pipe**: Open WebUI Pipe Function translating LangGraph events to OpenAI-style chat completion stream.
4. **Trajectory Relay**: aiohttp service consuming `adispatch_custom_event` events, fanning out via Redis pub/sub.
5. **Artifacts**: HTML iframes (`trajectory_tree.html`, `hitl_form.html`) loaded by Open WebUI's embeds.

## Component contracts

| Component | Spec |
|---|---|
| Sub-agent | `sub-agent-spec.md` |
| Supervisor | `supervisor-spec.md` |
| Pipe | `pipe-spec.md` |
| API contracts (HTTP, Redis, Postgres) | `api-contracts.md` |
| A2A Trajectory Extension | `a2a-extensions/trajectory-v1.md` |
| A2A Handoff Extension | `a2a-extensions/handoff-v1.md` |

## Data flow (PoC scenario)

User asks "PROJ-123 進度?還有 mask-design-spec 的最新狀態?":

1. Open WebUI → Pipe Function (chat completion request)
2. Pipe → Supervisor (`astream_events("v2")`)
3. Supervisor → TodoList ("plan: query Jira + query Wiki")
4. Supervisor → handoff_to_jira (`Command(goto="jira_agent", graph=PARENT)`)
5. jira_agent → tool `search_jira` → Jira REST (via AIDE Gateway)
6. Supervisor → handoff_to_wiki
7. wiki_agent → tool `search_wiki`
8. Supervisor → consolidate response
9. Pipe yields markdown content with `<details type="tool_calls">` blocks
10. Trajectory iframe receives Redis pub/sub events, renders Cytoscape graph
11. Pipe yields `{"choices":[{"delta":{},"finish_reason":"stop"}]}`

## Constraints

- Air-gap: no external network egress
- Multi-tenant: tenant_id + bu_id required on every artifact
- Locked versions: see `CLAUDE.md` "Tech stack"
- Frozen URIs: `urn:m-corp:masksdk:trajectory:v1`, `urn:m-corp:mask-kernel:handoff:v1`

## Non-goals (this version)

- Real-time multi-user collaboration on a single thread
- Cross-region deployment
- External vendor agent integration (post-Phase 5)
