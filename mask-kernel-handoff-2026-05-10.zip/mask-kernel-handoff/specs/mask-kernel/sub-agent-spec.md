# Sub-Agent Specification (mask-kernel v1.0)

## Purpose

Defines the contract every BU sub-agent (Jira / Wiki / Build Status / future
BU agents) MUST implement to be invoked by a mask-kernel supervisor.

## Interface (Python)

```python
class SubAgentInterface:
    """All mask-kernel sub-agents MUST implement this contract."""
    name: str                       # e.g., "jira_agent"
    version: str                    # semver, e.g., "1.0.2"
    bu_id: str                      # e.g., "BU-A"
    agent_card: AgentCard           # a2a-sdk AgentCard, signed

    async def invoke(
        self,
        messages: list[BaseMessage],
        state: dict,
        config: RunnableConfig,
    ) -> AsyncIterator[StreamEvent]:
        """Streams trajectory events, then a final AIMessage."""
```

## AgentCard schema (JSON)

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "type": "object",
  "required": ["name", "version", "bu_id", "extensions", "auth", "signature"],
  "properties": {
    "name":      { "type": "string", "pattern": "^[a-z0-9_]+$" },
    "version":   { "type": "string", "pattern": "^\\d+\\.\\d+\\.\\d+$" },
    "bu_id":     { "type": "string", "pattern": "^BU-[A-Z0-9]+$" },
    "extensions": {
      "type": "array",
      "items": { "enum": [
        "urn:m-corp:masksdk:trajectory:v1",
        "urn:m-corp:mask-kernel:handoff:v1"
      ]}
    },
    "auth":      { "type": "object", "properties": { "type": { "const": "AIDE-JWT-Bearer" } } },
    "signature": { "type": "string", "description": "Ed25519 signature over canonical JSON" },
    "allowed_callers": {
      "type": "array",
      "items": { "type": "object", "properties": {
        "bu_id": { "type": "string" },
        "ops":   { "type": "array", "items": { "type": "string" } }
      }}
    }
  }
}
```

## Streaming events emitted

Every sub-agent MUST emit (via `adispatch_custom_event`):

| Event name | Payload | When |
|---|---|---|
| `trajectory.node.start` | `{node, input}` | On node entry |
| `trajectory.node.end`   | `{node, output, tokens}` | On node exit |
| `trajectory.tool.call`  | `{tool, args}` | Before tool invoke |
| `trajectory.tool.result`| `{tool, result}` | After tool return |
| `trajectory.handoff`    | `{target, reason}` | Before Command(goto=...) |

## Anti-patterns (rejected in CI)

- Calling `get_stream_writer()` inside async tool (use `adispatch_custom_event`)
- Direct `delta.tool_calls` emission (use markdown `<details type="tool_calls">`)
- Importing peer BU agent modules

## Conformance test

`src/tests/contract/test_sub_agent_conformance.py` — runs against any
sub-agent class implementing `SubAgentInterface`. Must pass before merge.

## References

- ADR-0001
- `docs/architecture/30-multi-agent-architecture.md`
- a2a-sdk v1.0.2 AgentCard spec
