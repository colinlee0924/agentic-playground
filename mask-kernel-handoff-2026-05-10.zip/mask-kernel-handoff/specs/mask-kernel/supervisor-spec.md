# Supervisor Specification

## Composition

```python
supervisor = create_agent(
    model=llm,
    tools=[
        # Same-BU handoffs
        handoff_to_jira, handoff_to_wiki, handoff_to_build,
        # Cross-BU handoffs (a2a-sdk wrapped tools)
        send_to_bu_b, send_to_bu_c,
        # Built-in
        request_human_approval,
    ],
    middleware=[
        TodoListMiddleware(),
        ReflectorMiddleware(triggers=[...]),
        PlanExecuteReplanMiddleware(min_steps_to_trigger=5),
    ],
    checkpointer=AsyncPostgresSaver.from_conn_string(DATABASE_URL),
)
```

## State schema

```python
class SupervisorState(TypedDict):
    messages: list[BaseMessage]
    todos: list[TodoItem]                # managed by TodoListMiddleware
    tenant_id: str
    bu_id: str
    trace_id: str
    handoff_history: list[HandoffRecord]
    pending_approvals: list[ApprovalRequest]
```

## Required behaviors

1. Every node MUST emit `trajectory.node.start` and `trajectory.node.end`.
2. Every handoff MUST emit `trajectory.handoff` BEFORE returning Command.
3. Every write tool MUST go through ReflectorMiddleware.
4. `interrupt(...)` MUST be used for HITL, NOT custom queue mechanisms.

## Handoff routing rules

- Same-BU handoff: `Command(goto=target_node, graph=Command.PARENT)`
- Cross-BU handoff: a2a-sdk `agent.send_message` with required metadata:
  - `tenant_id`, `bu_id` (source), `bu_id_target`, `trace_id`
- Cross-BU handoff is itself a tool call (returns a string result), NOT a Command.

## Reference

- ADR-0001, ADR-0002, ADR-0004
- `src/supervisor/graph.py`
- `src/supervisor/middleware.py`
- `src/supervisor/handoff_tools.py`
