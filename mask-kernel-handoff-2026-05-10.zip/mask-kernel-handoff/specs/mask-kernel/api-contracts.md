# API Contracts

## HTTP (between components)

### Supervisor exposes (a2a-sdk JSON-RPC)

- `POST /a2a/v1/messages` — send message (sync or stream via SSE)
- `GET /.well-known/agent.json` — AgentCard (signed Ed25519)

### Trajectory Relay exposes

- `GET /trajectory/<thread_id>/stream` — SSE consumer for iframe
- `POST /trajectory/<thread_id>/event` — internal: relay receives from supervisor

### Pipe consumes

- Supervisor `/a2a/v1/messages?stream=true`

## Redis

### Channels (pub/sub)

- `trajectory:<tenant_id>:<bu_id>:<thread_id>` — trajectory events for iframe

### Lists (queue)

- `hitl:approvals:<tenant_id>:<thread_id>` — pending HITL approvals (LPUSH/BRPOP)

### Hashes

- `agent_card:<tenant_id>:<bu_id>:<agent_name>` — AgentCard cache (TTL 1h)

## Postgres tables

```sql
-- LangGraph checkpoints (managed by AsyncPostgresSaver)
CREATE TABLE checkpoints (
  thread_id UUID,
  checkpoint_ns TEXT,
  checkpoint_id TEXT,
  parent_checkpoint_id TEXT,
  type TEXT,
  checkpoint JSONB,
  metadata JSONB,
  tenant_id UUID NOT NULL,    -- mask-kernel addition
  bu_id TEXT NOT NULL,         -- mask-kernel addition
  PRIMARY KEY (thread_id, checkpoint_ns, checkpoint_id)
);
ALTER TABLE checkpoints ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON checkpoints
  USING (tenant_id = current_setting('app.tenant_id')::uuid);

-- Trajectory ledger (for audit + replay, 7-year retention)
CREATE TABLE trajectory_events (
  event_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id UUID NOT NULL,
  tenant_id UUID NOT NULL,
  bu_id TEXT NOT NULL,
  trace_id UUID NOT NULL,
  event_kind TEXT NOT NULL,
  payload JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX trajectory_thread_idx ON trajectory_events (thread_id, created_at);
CREATE INDEX trajectory_trace_idx ON trajectory_events (trace_id);
```

## HITL flow contract

```
Supervisor                 Pipe                       User
    │                       │                          │
    ├─ interrupt(spec) ─────┤                          │
    │  (Postgres ckpt)      │                          │
    │                       ├─ Redis LPUSH             │
    │                       │  hitl:<tenant>:<thread>  │
    │                       ├─ __event_call__("input") │
    │                       ├──────────► render ──────►│
    │                       │                       click
    │                       ├─ Redis LREM (consume) ◄──┤
    │  ◄─ resume(decision) ─┤                          │
    │  (load ckpt)          │                          │
```

## A2A cross-BU message metadata

```json
{
  "trace_id": "uuid",
  "tenant_id": "uuid",
  "bu_id_source": "BU-A",
  "bu_id_target": "BU-B",
  "extensions": {
    "urn:m-corp:masksdk:trajectory:v1": {...},
    "urn:m-corp:mask-kernel:handoff:v1": {...}
  }
}
```
