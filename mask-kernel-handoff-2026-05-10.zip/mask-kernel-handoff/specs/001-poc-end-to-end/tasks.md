# Tasks: 001-poc-end-to-end

> Each task is independent. `[P]` = parallelizable. Sequential markers `(after Tn)`.

- [ ] **T01** [P] Scaffold `src/agents/jira_agent/` from sub-agent template
- [ ] **T02** [P] Scaffold `src/agents/wiki_agent/`
- [ ] **T03** [P] Scaffold `src/agents/build_agent/`
- [ ] **T04** Build `src/supervisor/graph.py` (after T01-T03)
- [ ] **T05** Build `src/supervisor/middleware.py` (TodoList + Reflector + Plan-Execute)
- [ ] **T06** Build `src/supervisor/handoff_tools.py` (after T04)
- [ ] **T07** Build `src/pipe/event_translator.py`
- [ ] **T08** Build `src/pipe/mask_kernel_pipe.py` (after T06, T07)
- [ ] **T09** Build `src/trajectory_relay/relay.py`
- [ ] **T10** Build `src/artifacts/trajectory_tree.html` (after T09)
- [ ] **T11** Build `src/artifacts/hitl_form.html`
- [ ] **T12** Wire `docker-compose.yml`
- [ ] **T13** [P] Write E2E test `tests/e2e/test_proj123_scenario.py`
- [ ] **T14** [P] Write contract test `tests/contract/test_sub_agent_conformance.py`
- [ ] **T15** [P] Write unit tests for handoff_tools
- [ ] **T16** Verify CI grep gates pass (all anti-patterns)
- [ ] **T17** Langfuse self-hosted setup verification
- [ ] **T18** Documentation review pass

## Definition of Done

- All 18 tasks checked
- `docker compose up` boots cleanly
- `pytest src/tests/` 100% pass
- `grep -r "langgraph_supervisor\|delta\.tool_calls" src/` empty
