# Plan: 001-poc-end-to-end

## Tech stack (locked)

See `CLAUDE.md` "Tech stack" section.

## Project structure

Single repo, monolithic deployment via docker-compose:

```
src/
├── agents/{jira,wiki,build}_agent/
├── supervisor/
├── pipe/
├── trajectory_relay/
├── shared/
├── artifacts/
├── tests/
└── docker-compose.yml
```

## Phase 0: Research (DONE in this handoff package)

- ADRs 0001-0008 accepted
- RFCs 001-003 drafted
- Architecture docs 00-90 written

## Phase 1: Implement

- M0 W1: scaffold src/ (jira_agent + supervisor + pipe)
- M0 W2: trajectory_relay + iframe
- M0 W3: HITL approval flow
- M0 W4: E2E test passing
- M1 W1-W2: Langfuse + observability hardening
- M1 W3-W4: BU-A 100-user 灰度

## Phase 2+: see RFC-001
