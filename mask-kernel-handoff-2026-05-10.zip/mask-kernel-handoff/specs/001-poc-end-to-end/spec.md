# Spec: PoC End-to-End Scenario

**Feature**: 001-poc-end-to-end
**Branch**: `feat/001-poc-end-to-end`
**Prerequisites**: none (foundational PoC)

## User story

As an M-Corp engineer, when I ask "PROJ-123 進度如何?還有 mask-design-spec
的最新狀態?", I want mask-kernel to query Jira + Wiki + Build Status, render
a unified summary with trajectory tree, and request my approval before any
write operation.

## Acceptance criteria

- [ ] Pipe answers within 8s p95 (cold start excluded)
- [ ] Trajectory iframe renders all node transitions
- [ ] HITL approval triggered before any JIRA mutation
- [ ] Final message ends with `finish_reason: stop`
- [ ] Langfuse trace captures supervisor + 3 sub-agents

## Out of scope

- Cross-BU A2A handoff (Phase 2)
- Generative UI components (Phase 4)

## [NEEDS CLARIFICATION] markers

- [x] None remaining
