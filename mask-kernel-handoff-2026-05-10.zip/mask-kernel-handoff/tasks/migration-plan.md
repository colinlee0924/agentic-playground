# Migration Plan: PoC → Production (4 phases × 14 months)

See `docs/rfc/RFC-001-poc-to-production-roadmap.md` for the discussion.

## Phase 1 (M0-M2): Single-BU production hardening

| | Detail |
|---|---|
| **Entry criteria** | PoC 12-step E2E test passes |
| **Exit criteria** | BU-A 100 user 灰度 SLO 連續 2 週達標 |
| **Migration tasks** | Langfuse OTel; Postgres backup drill; Redis cluster; CI grep gate; AgentCard signing; RLS policy tests |
| **Rollback plan** | 切回手工 JIRA 流程,Pipe 暫停;BU-A 100 user 暫停接受新請求 |

## Phase 2 (M2-M5): 2-3 BU expansion

| | Detail |
|---|---|
| **Entry criteria** | Phase 1 SLO 連續 30 天達標 |
| **Exit criteria** | 3 BU 上線、跨 BU handoff 驗證 |
| **Migration tasks** | AgentCard registry; BU-B/C a2a-server; Reflector middleware; Linux Foundation A2A WG URI 註冊 |
| **Rollback plan** | 新 BU fallback 到 BU-A 集中處理 |

## Phase 3 (M5-M9): LibreChat + Assistant-UI

| | Detail |
|---|---|
| **Entry criteria** | 3 BU 穩定;Open WebUI 客製天花板已被使用者反饋 |
| **Exit criteria** | LibreChat 上線;Open WebUI 維護模式 |
| **Migration tasks** | LibreChat 部署;Pipe→plugin 改寫;Assistant-UI BU portal PoC;雙前端並行 1 個月 |
| **Rollback plan** | 兩前端並存,Open WebUI 仍可用 |

## Phase 4 (M9-M14): AG-UI / CopilotKit + A2UI

| | Detail |
|---|---|
| **Entry criteria** | A2UI ≥ v1.0 GA OR Phase 3 完成 6 個月後 (取較晚) |
| **Exit criteria** | 全 15 BU + AG-UI events |
| **Migration tasks** | backend AG-UI emitter;A2UI generative widgets;BU-A CopilotKit 試點;15 BU rollout |
| **Rollback plan** | LibreChat 仍可用 |
