# mask-kernel Backlog (Claude Code dispatch list)

> Each item is sized for one Claude Code session.
> Format: `- [ ] [P1|P2|P3] <title> — <skill> — <related spec>`

## P1 — Production hardening (Phase 1)

- [ ] [P1] Add Langfuse OTel exporter to supervisor — skill: `avoiding-pitfalls` — spec: `docs/architecture/70-observability-strategy.md`
- [ ] [P1] Wire AsyncPostgresSaver retry-on-disconnect — skill: `hitl-approval-flow` — spec: `specs/mask-kernel/api-contracts.md`
- [ ] [P1] CI grep gate for banned imports — see `src/shared/audit.py`
- [ ] [P1] Trajectory iframe: cross-tab session isolation — skill: `trajectory-iframe`
- [ ] [P1] E2E test: PROJ-123 12-step scenario — spec: `specs/001-poc-end-to-end/spec.md`
- [ ] [P1] AgentCard Ed25519 signing in CI — skill: `a2a-sub-agent`
- [ ] [P1] Postgres RLS policy tests — `docs/architecture/80-security-multi-tenant.md`
- [ ] [P1] Disaster recovery: Postgres backup + restore drill

## P2 — BU expansion (Phase 2)

- [ ] [P2] Scaffold `bu_b_agent` (Confluence + JIRA Service Desk) — skill: `a2a-sub-agent`
- [ ] [P2] AgentCard registry (Postgres-backed) — RFC: `docs/rfc/RFC-002`
- [ ] [P2] Cross-BU A2A handoff E2E test
- [ ] [P2] Reflector middleware: write-op double-check for JIRA mutations — skill: `handoff-tool`
- [ ] [P2] Cross-BU shared memory block PoC — RFC: `docs/rfc/RFC-003`

## P3 — Frontend migration (Phase 3 prep)

- [ ] [P3] LibreChat plugin spike — `docs/architecture/20-frontend-roadmap.md`
- [ ] [P3] Assistant-UI BU portal PoC

## P4 — Future (Phase 4)

- [ ] [P4] AG-UI events emitter (parallel to existing trajectory events)
- [ ] [P4] A2UI v0.9 generative widgets PoC

## Done (✅)

- [x] PoC: 3 sub-agents (Jira/Wiki/Build) + supervisor + Pipe + iframe (skeleton in `src/`)
- [x] Docker Compose full stack
- [x] All 8 ADRs accepted (`docs/decisions/`)
- [x] 3 RFCs drafted (`docs/rfc/`)
- [x] CLAUDE.md + memory/constitution.md + 6 skills

## Suggested order for Claude Code first session

1. Verify env: `docker compose -f src/docker-compose.yml config`
2. Pick the first unchecked P1: **Add Langfuse OTel exporter to supervisor**
3. Read the relevant skill + spec before touching code
4. Implement, write tests, run `python -m src.shared.audit`
5. Commit + advance to next P1
