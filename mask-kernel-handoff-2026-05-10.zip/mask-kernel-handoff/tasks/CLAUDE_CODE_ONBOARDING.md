# Claude Code Onboarding Prompt

當 Colin 把這份 repo 給 Claude Code 接手時,請貼以下內容作為第一條訊息:

---

```text
You are joining the mask-kernel project as the AI development partner.
Before writing any code, complete this onboarding sequence:

1. Read /memory to confirm the loaded memory files include:
   - ./CLAUDE.md (root)
   - ./memory/constitution.md (via @import)
   - ./.claude/rules/streaming-rules.md and a2a-protocol.md (path-scoped)

2. List all skills with /skills. Confirm you can see:
   a2a-sub-agent, handoff-tool, pipe-event-translation,
   hitl-approval-flow, trajectory-iframe, avoiding-pitfalls.

3. Read in order (do NOT skip):
   - memory/constitution.md (9 immutable articles)
   - docs/architecture/00-overview.md (system mental model)
   - specs/mask-kernel/architecture.md (English spec of record)
   - specs/mask-kernel/sub-agent-spec.md (interface contract)
   - specs/001-poc-end-to-end/spec.md → plan.md → tasks.md

4. Open tasks/backlog.md. Identify the first P1 item that is NOT marked done.

5. Before touching any file, state back to me:
   (a) which P1 task you will tackle,
   (b) which skill you will invoke,
   (c) which spec section governs the change,
   (d) which files in src/ you expect to modify,
   (e) which test will validate the change.

6. Wait for my "go" before writing code.

Hard rules you MUST never violate (from constitution.md):
- Never import langgraph_supervisor or langgraph_swarm.
- Never emit delta.tool_calls — render <details type="tool_calls"> markdown.
- Never call get_stream_writer() inside an async tool —
  use adispatch_custom_event.
- Every Pipe response MUST end with yield finish_reason: stop.
- Never bump LangChain/LangGraph/a2a-sdk versions without an ADR.
- Never use RouteDecision (LLM + structured output + if/else routing).
- Never hardcode AIDE Gateway URL — read from env.

When unsure, prefer reading specs/ and docs/decisions/ over guessing.
The Chinese files under docs/architecture/, docs/decisions/, docs/rfc/
are human-team decision artifacts; they are authoritative but English
specs/ are the machine-readable source of truth for implementation.

Begin onboarding.
```

---

## 給內部團隊的閱讀路徑

見 `INDEX.md`。

## 一鍵打包指令

```bash
# 在父目錄
tar --exclude='**/__pycache__' \
    --exclude='**/.pytest_cache' \
    --exclude='**/.venv' \
    --exclude='**/*.pyc' \
    -czvf mask-kernel-handoff-$(date +%Y-%m-%d).tar.gz \
    mask-kernel-handoff/

# 或 zip
zip -r mask-kernel-handoff-$(date +%Y-%m-%d).zip mask-kernel-handoff/ \
    -x '*/__pycache__/*' '*/.pytest_cache/*' '*/.venv/*' '*.pyc'
```
