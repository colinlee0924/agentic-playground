# Testing Plan: 三層測試金字塔

## Layer 1: Unit tests (src/tests/unit/)

涵蓋:
- Tool 函式 (search_jira, get_wiki_page, ...)
- handoff_tools 工廠函式
- event_translator (絕對不能含 delta.tool_calls)
- a2a_extensions metadata builder
- agent_card_signer (sign + verify round-trip)

執行:
```bash
pytest src/tests/unit/ -v
```

## Layer 2: Contract tests (src/tests/contract/)

涵蓋:
- 每個 sub-agent 都符合 `specs/mask-kernel/sub-agent-spec.md`
- AgentCard 含必要欄位與凍結 URI
- Trajectory event schema 符合 `specs/001-poc-end-to-end/contracts/trajectory-event.schema.json`
- Handoff message schema 符合 `specs/001-poc-end-to-end/contracts/handoff-message.schema.json`

執行:
```bash
pytest src/tests/contract/ -v
```

## Layer 3: E2E tests (src/tests/e2e/)

涵蓋:
- PROJ-123 12-step scenario (`test_proj123_scenario.py`)
- HITL kill -9 後恢復 (`test_hitl_resume.py`)
- HITL websocket 斷線後恢復 (`test_hitl_websocket_drop.py`)
- 跨 BU handoff (`test_cross_bu_handoff.py`)
- Trajectory iframe multi-tab 隔離 (`test_iframe_isolation.py`)

執行:
```bash
docker compose up -d   # 必須先啟動完整 stack
pytest src/tests/e2e/ -v
```

## Anti-pattern audit (CI gate)

```bash
python -m src.shared.audit
```

如有任何 anti-pattern 觸發,CI 失敗。

## SLO regression tests

每週執行,在 staging 跑 100 個典型 query,記錄:
- p50 / p95 / p99 latency
- token usage per BU
- HITL approval rate

結果寫入 Langfuse dashboard。
