# mask-kernel Constitution

> Articles below are **immutable principles**. Any deviation requires a new
> ADR that explicitly supersedes the relevant article.

## Article I — Air-gap First

All components MUST run without external network egress. No SaaS dependencies.
Container images MUST be mirrored to internal registry before deployment.

## Article II — Multi-Tenant by Construction

Every artifact MUST carry `tenant_id` and `bu_id`. No shared mutable state
across BUs without an explicit cross-BU shared memory block (RFC-003).
Postgres rows MUST include tenant column; Redis keys MUST include tenant
prefix.

## Article III — Streaming Contract

Tool calls render as markdown `<details type="tool_calls">` blocks.
`finish_reason: stop` MUST terminate every Pipe response.
Never emit `delta.tool_calls` chunks to Open WebUI.

## Article IV — Observability is Mandatory

Every node, tool, and handoff MUST emit a trajectory event AND a Langfuse
span. Trace IDs MUST propagate across BU boundaries via A2A `Message.metadata`.

## Article V — Locked Versions

LangChain 1.2.x, LangGraph 1.1.x, a2a-sdk 1.0.2 are FROZEN. Bumping requires
ADR. The A2A protocol version (v1.0.0) is also frozen at the spec level.

## Article VI — Custom URIs are Frozen

`urn:m-corp:masksdk:trajectory:v1` and `urn:m-corp:mask-kernel:handoff:v1`
MUST NOT be renamed. New extensions get new URIs (e.g., `:v2`).

## Article VII — Anti-Patterns are Banned

The list in `docs/architecture/90-anti-patterns.md` is enforced by CI grep
gates. The following imports MUST fail CI:

```
langgraph_supervisor
langgraph_swarm
```

The following emit patterns MUST fail CI:

```
delta\.tool_calls
get_stream_writer.*async
```

## Article VIII — HITL is Persistent

Every HITL approval MUST survive process restart. The combination of
`AsyncPostgresSaver` + Redis queue is the ONLY approved persistence mechanism.
Long-poll, in-memory queues, and websocket-only callbacks are FORBIDDEN.

## Article IX — Sub-agent Boundaries

Sub-agents within the same BU communicate via `Command(graph=Command.PARENT)`.
Sub-agents across BUs communicate via `a2a-sdk` `agent.send_message`.
Direct module imports across BU boundaries are FORBIDDEN.
