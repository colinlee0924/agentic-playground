---
status: "accepted"
date: 2026-05-10
decision-makers: [Colin (Tech Lead), AI Task Force Architecture WG]
consulted: [Platform SRE, Security Office, BU-A representative]
informed: [全 15 BU 代表, JIRA × AI Task Force]
---
# 採用 sub-agent-as-tool pattern,棄用 langgraph-supervisor

## Context and Problem Statement

mask-kernel 需要一個 supervisor 協調多個 sub-agent (Jira / Wiki / Build Status)。
LangGraph 生態提供三種主流 pattern:`langgraph-supervisor` 套件、`langgraph-swarm`、
以及原生 `create_agent` + tool 模式。本決策需選定其一作為 BU 內部 supervisor 的實作基礎。

## Decision Drivers

* 需與 LangChain 1.2.x `create_agent` 完全相容
* 需支援 BU 內 `Command(goto, graph=Command.PARENT)`
* 需可觀測 (Langfuse trace, trajectory tree)
* 需可長期維護 (避免採用 deprecated 或 untested 套件)
* 需與 a2a-sdk v1.0.2 協議無縫橋接

## Considered Options

* **A. `langgraph-supervisor` 官方套件** — 現成 supervisor builder
* **B. `langgraph-swarm`** — 去中心化 swarm 模式
* **C. sub-agent-as-tool** — supervisor 用 `create_agent` + 自訂 handoff tool

## Decision Outcome

Chosen option: **C. sub-agent-as-tool**,because A 已被 LangChain 團隊 soft-deprecate,
B 對 LangChain v1 `create_agent` 官方明確標 "untested";C 為 LangChain 官方 multi-agent
guide 在 2026 採用的範例,並能直接套 TodoListMiddleware、Reflector、Plan-Execute-Replan
三種 pattern (見 ADR-0004)。

### Consequences

* Good, 因為 **與 LangChain 官方文件對齊**,未來升級成本低。
* Good, 因為 **handoff tool 可序列化為 JSON**,容易在 Langfuse 觀測。
* Good, 因為 **可疊加 middleware** 而不需 fork 套件。
* Bad, 因為 **需自寫 handoff tool 樣板**,初期實作成本略高 (約 2 人天)。
* Bad, 因為 **需自行管理 Command.PARENT 邏輯**,容易誤用 (已在 `.claude/rules/` 加防呆)。

### Confirmation

實作完成後驗證:
1. `pytest src/tests/e2e/test_proj123_scenario.py` 通過 12 步流程
2. Langfuse 可看到 supervisor → sub-agent → tool 三層 span
3. `grep -r "langgraph_supervisor\|langgraph_swarm" src/` 回傳空 (CI 強制)

## Pros and Cons of the Options

### A. langgraph-supervisor 套件
* Good, 樣板少,5 行程式即可起 supervisor
* Bad, 已被 soft-deprecated
* Bad, 與 TodoListMiddleware 整合需 monkey-patch

### B. langgraph-swarm
* Good, 適合對等多 agent 協作
* Bad, 對 LangChain v1 `create_agent` 官方標 untested
* Bad, 與我們的「supervisor 集中管控 trajectory」需求不符

### C. sub-agent-as-tool ✅
* Good, LangChain 官方 2026 multi-agent guide 採此 pattern
* Good, 與 a2a-sdk 橋接最自然
* Good, 可疊三種 supervisor middleware
* Neutral, 需自寫 5-10 行 handoff tool boilerplate
* Bad, 初期文件不如 langgraph-supervisor 套件完整

## More Information

- 上游證據:LangChain v1 multi-agent guide (2026-Q1 release notes)
- 相關文件:`docs/architecture/30-multi-agent-architecture.md`、
  `specs/mask-kernel/sub-agent-spec.md`、`.claude/skills/a2a-sub-agent/SKILL.md`
- 後續決策:本 ADR 為 ADR-0002 的前提
- 重審觸發條件:LangChain ≥ 2.0 release 或 LangGraph 推出新官方 supervisor abstraction 時
