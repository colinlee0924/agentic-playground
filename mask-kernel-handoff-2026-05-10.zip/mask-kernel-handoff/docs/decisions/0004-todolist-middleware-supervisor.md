---
status: "accepted"
date: 2026-05-10
decision-makers: [Colin, AI Task Force]
informed: [全 BU]
---
# TodoListMiddleware 為 supervisor 主軸

## Context and Problem Statement

LangChain v1 提供多種 supervisor middleware (TodoList、Reflector、
Plan-Execute-Replan、ReAct...)。哪一種應作為 mask-kernel 的預設?

## Decision Drivers

* 任務多步驟時需有計畫骨架
* 寫操作需把關
* 巨型分析需結構化
* Trajectory iframe 需顯示 progress

## Considered Options

* **A. ReAct (zero-shot)**
* **B. Plan-Execute-Replan only**
* **C. TodoList only**
* **D. 三層疊加 — TodoList 永遠開啟,Reflector / Plan-Execute 條件觸發** (主提案)

## Decision Outcome

Chosen option: **D. 三層疊加**,因為單一 pattern 在不同情境會失準。
詳細策略見 `docs/architecture/40-supervisor-patterns.md`。

### Consequences

* Good, 涵蓋所有任務複雜度
* Good, Reflector 自動把關寫操作
* Bad, middleware 組合配置複雜 (透過 skill 緩解)

### Confirmation

1. 簡單查詢 (PROJ-123 進度) 不啟動 Plan-Execute (token 不浪費)
2. 寫操作前 Reflector 觸發 HITL approval
3. 巨型分析 (5+ 步) 啟動 Plan-Execute-Replan loop

## More Information

- `docs/architecture/40-supervisor-patterns.md`
- `src/supervisor/middleware.py`
