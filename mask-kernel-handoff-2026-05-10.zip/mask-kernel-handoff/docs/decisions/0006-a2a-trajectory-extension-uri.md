---
status: "accepted"
date: 2026-05-10
decision-makers: [Colin, AI Task Force]
consulted: [Security Office]
informed: [全 BU]
---
# 自訂 A2A Trajectory + Handoff Extension URI

## Context and Problem Statement

A2A 協議支援 extension URI,讓自訂事件能在標準訊息上承載。
mask-kernel 需要兩種 extension:trajectory event 與 handoff metadata。
URI 命名如何選?

## Decision Drivers

* 跨 BU 跨 a2a-server 一致
* 不與其他組織衝突
* 可版本化 (e.g., :v1, :v2)
* 對齊 Linux Foundation A2A spec

## Considered Options

* **A. 用既有 a2a-extensions repo 的 URI**
* **B. 自訂 m-corp 命名空間** (主提案)
* **C. 不用 extension,塞進 metadata**

## Decision Outcome

Chosen option: **B. 自訂 URI**:
- `urn:m-corp:masksdk:trajectory:v1`
- `urn:m-corp:mask-kernel:handoff:v1`

A 的 a2a-extensions v0.x 仍 unstable;C 缺乏標準化好處。

### Consequences

* Good, 標準化、可被 a2a-inspector 工具識別
* Good, 版本化清晰
* Good, 不衝突 (m-corp 為公司 namespace)
* Bad, 需向 Linux Foundation A2A WG 註冊 (Phase 2 任務)

### Confirmation

1. 兩個 URI 在 `specs/mask-kernel/a2a-extensions/` 有完整 spec
2. CI 檢查 AgentCard 有列出 URI
3. Linux Foundation A2A WG 註冊跟進中 (RFC-001 Phase 2)

## More Information

- `specs/mask-kernel/a2a-extensions/trajectory-v1.md`
- `specs/mask-kernel/a2a-extensions/handoff-v1.md`
- 憲法 Article VI (URI 凍結)
