---
status: "accepted"
date: 2026-05-10
decision-makers: [Colin, AI Task Force]
informed: [全 BU]
---
# 棄用 RouteDecision pattern,改 handoff tool

## Context and Problem Statement

Coding-Crashkurse 早期 A2A 教學示範了「LLM with structured output → if/else
routing」的 RouteDecision pattern。在 mask-kernel 應否採用?

## Decision Drivers

* 與 LangChain v1 middleware 模式一致性
* Trajectory 結構化 (debug 友善)
* 擴充性 (新增 routing 不需改核心)
* Token 效率

## Considered Options

* **A. RouteDecision** (LLM + Pydantic + if/else)
* **B. handoff tool** (Command + tool call)

## Decision Outcome

Chosen option: **B. handoff tool**,因為:
- A 在 LangChain v1 已過時
- A 一次只能處理一個 routing,擴展性差
- A 沒有 trajectory 結構,debug 困難
- B 與 ADR-0001 sub-agent-as-tool 一致

### Consequences

* Good, 與 LangChain v1 對齊
* Good, trajectory 結構清晰
* Good, 加新 BU 只需加新 tool,不改核心
* Bad, 對熟悉 RouteDecision 的開發者需重新學習 (透過 skill 緩解)

### Confirmation

1. CI grep gate `class RouteDecision\b` 為空
2. `.claude/skills/avoiding-pitfalls/` 列入清單
3. README 標明此 pattern 已棄用

## More Information

- `docs/architecture/90-anti-patterns.md` 反模式 #3
- `.claude/skills/handoff-tool/SKILL.md` (替代方案)
- 重審觸發:LangChain 出新 routing primitive 時
