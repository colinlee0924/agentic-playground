---
status: "accepted"
date: 2026-05-10
decision-makers: [Colin, AI Task Force]
consulted: [SRE, Security]
informed: [全 BU 代表]
---
# BU 內 Command + 跨 BU A2A 雙層架構

## Context and Problem Statement

mask-kernel 服務 9000 user × 15 BU,需在「同 BU 內 sub-agent 協作」與「跨 BU
工作交付」兩種場景間取得平衡。前者需低延遲、共享 state;後者需多租戶隔離、
獨立 deploy。如何在同一 SDK 統一兩者?

## Decision Drivers

* 同 BU 內延遲 < 1ms (LangGraph in-memory)
* 跨 BU 多租戶完全隔離 (Postgres RLS + Redis prefix)
* 跨 BU 可獨立 deploy / scale / version
* 與 a2a-sdk v1.0.2 對齊
* 觀察性 (trace_id 跨 BU 連通)

## Considered Options

* **A. 全部走 a2a-sdk** (BU 內也走 A2A)
* **B. 全部走 LangGraph subgraph** (跨 BU 直接 import)
* **C. 雙層 — BU 內 Command,跨 BU A2A** (主提案)

## Decision Outcome

Chosen option: **C. 雙層**,because A 在 BU 內延遲過高 (HTTP serialize),
B 違反多租戶隔離 (constitution Article II)。C 取兩者所長。

### Consequences

* Good, BU 內延遲低 (Command in-memory)
* Good, 跨 BU 可獨立 release
* Good, A2A protocol 提供跨 BU 標準介面
* Bad, 開發者需理解兩種 handoff 機制 (透過 skill 與 rule 緩解)
* Bad, 跨 BU trace 需手動 propagate trace_id

### Confirmation

1. `pytest src/tests/e2e/test_cross_bu_handoff.py` 通過
2. Langfuse 跨 BU trace 能完整連起來
3. BU-A 與 BU-B 可獨立 `docker compose up` 並互通

## Pros and Cons of the Options

### A. 全 A2A
* Good, 介面統一
* Bad, BU 內延遲過高
* Bad, BU 內無法共享 LangGraph state

### B. 全 subgraph
* Good, 完全 in-memory
* Bad, 違反多租戶隔離
* Bad, 無法獨立 deploy

### C. 雙層 ✅
* Good, 最佳平衡
* Bad, 學習曲線略陡

## More Information

- `docs/architecture/30-multi-agent-architecture.md`
- `.claude/skills/handoff-tool/SKILL.md`
- `.claude/skills/a2a-sub-agent/SKILL.md`
