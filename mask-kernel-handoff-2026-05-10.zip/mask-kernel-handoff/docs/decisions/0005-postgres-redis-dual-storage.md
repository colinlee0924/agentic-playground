---
status: "accepted"
date: 2026-05-10
decision-makers: [Colin, SRE]
informed: [全 BU]
---
# Postgres + Redis 雙存儲層

## Context and Problem Statement

mask-kernel 需要 (1) 長期持久化 checkpoint、(2) 即時 trajectory pub/sub、
(3) HITL queue 三類存儲。用同一個 store 還是分開?

## Decision Drivers

* Checkpoint 需強一致性、長保留 (compliance 7 年)
* Trajectory pub/sub 需 sub-second 延遲
* HITL queue 需能跨 process 恢復

## Considered Options

* **A. 全 Postgres** (LISTEN/NOTIFY 做 pub/sub)
* **B. 全 Redis** (含 RDB 持久化)
* **C. Postgres (持久) + Redis (即時)** (主提案)

## Decision Outcome

Chosen option: **C**,因為:
- A 的 LISTEN/NOTIFY 在 9000 user 規模延遲不可控
- B 的 RDB 不滿足 7 年保留 + RLS 多租戶
- C 各取所長:Postgres 做 source of truth,Redis 做即時通道

### Consequences

* Good, 各組件職責清晰
* Good, Postgres RLS 滿足合規
* Good, Redis 滿足即時性
* Bad, 維護兩套基礎設施

### Confirmation

1. Checkpoint 7 年保留可驗證
2. Trajectory pub/sub p95 延遲 < 100ms
3. HITL kill -9 後可從 Postgres + Redis 恢復

## More Information

- `docs/architecture/10-tech-stack.md`
- `docs/architecture/70-observability-strategy.md`
- ADR-0007 (HITL 雙保險)
