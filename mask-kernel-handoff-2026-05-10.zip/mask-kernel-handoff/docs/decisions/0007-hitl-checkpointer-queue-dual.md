---
status: "accepted"
date: 2026-05-10
decision-makers: [Colin, AI Task Force, SRE]
informed: [全 BU]
---
# HITL = Postgres checkpoint + Redis queue 雙保險

## Context and Problem Statement

HITL approval 需在使用者離線、process restart、跨 BU handoff 等情況下
不丟失。純 LangGraph `interrupt` + websocket 在以上情境會失敗。如何設計?

## Decision Drivers

* 9000 user 並發,記憶體佇列不可行
* Process restart 不能丟失 pending approval
* 跨 BU handoff 時 HITL 仍能正確路由
* websocket 斷線可恢復

## Considered Options

* **A. 純 `__event_call__`** (in-memory)
* **B. 純 Redis queue** (沒 LangGraph thread state)
* **C. `__event_call__` + Postgres checkpoint + Redis queue 雙保險** (主提案)

## Decision Outcome

Chosen option: **C**,因為 A B 各有失敗模式,雙保險可從任一邊恢復。

### Consequences

* Good, 任何故障 (process kill / websocket 斷 / 跨 BU 失聯) 都可恢復
* Good, 結合 LangGraph thread + Redis 持久化
* Bad, 實作複雜度高 (透過 skill 標準化緩解)

### Confirmation

1. `pytest src/tests/e2e/test_hitl_resume.py` (kill -9 後可恢復)
2. `pytest src/tests/e2e/test_hitl_websocket_drop.py` (斷線後可重連恢復)
3. `pytest src/tests/e2e/test_hitl_cross_bu.py` (跨 BU HITL 路由正確)

## Pros and Cons

### A. 純 __event_call__
* Good, 簡單
* Bad, restart 即丟失

### B. 純 Redis
* Good, 跨 process 持久
* Bad, 沒 LangGraph thread state,resume 困難

### C. 雙保險 ✅
* Good, 任意一邊故障可從另一邊恢復
* Bad, 實作複雜

## More Information

- `.claude/skills/hitl-approval-flow/SKILL.md`
- 憲法 Article VIII
- `src/supervisor/handoff_tools.py` (request_human_approval tool)
