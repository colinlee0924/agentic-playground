---
status: "accepted"
date: 2026-05-10
decision-makers: [Colin, AI Task Force]
consulted: [Frontend WG, IT Ops]
informed: [全 BU]
---
# Open WebUI Pipe + embeds iframe 為短期前端

## Context and Problem Statement

mask-kernel 需要前端介面。內部已部署 Open WebUI,但有 multi-tab cross-talk
與 30-retry bug 等已知問題。短期 (3-6 個月) 是否繼續用 Open WebUI?如何
規避其限制?

## Decision Drivers

* IT 既有部署、人員熟悉
* 上線時程要求 < 3 個月
* 必須支援 trajectory 視覺化 + HITL approval
* 需可平滑遷移到中期方案 (LibreChat + Assistant-UI)

## Considered Options

* **A. 自建 React 前端** — 完全客製
* **B. LibreChat 直接上** — 跳過 Open WebUI
* **C. Open WebUI Pipe + embeds iframe (短期)** — 主提案

## Decision Outcome

Chosen option: **C. Open WebUI Pipe + iframe**,因為:
- A 工程量過大,9000 user 規模需專職前端團隊,當前無此資源
- B 不熟悉,需 IT 重新評估部署流程
- C 利用既有 Open WebUI 部署,僅補 Pipe + iframe 即可上線
- iframe 解決 multi-tab 隔離問題;markdown details 解決 30-retry

### Consequences

* Good, 上線時程可控
* Good, 與既有 IT 部署相容
* Bad, multi-tab 仍有部分限制 (主訊息層面)
* Bad, 客製化能力有限,需在 6 個月內遷移

### Confirmation

1. `docker compose up` + Open WebUI 可載入 mask-kernel pipe
2. 30-retry bug 不再出現
3. Trajectory iframe 在 multi-tab 不互相干擾

## Pros and Cons of the Options

### A. 自建 React
* Good, 完全客製
* Bad, 工程量大
* Bad, 維護成本高

### B. LibreChat 直接上
* Good, 比 Open WebUI 更彈性
* Bad, IT 重新部署評估時間長
* Bad, 跳過 Open WebUI 導致過渡期管理複雜

### C. Open WebUI Pipe + iframe ✅
* Good, 最快上線
* Good, IT 友善
* Bad, 6 個月後需遷移

## More Information

- `docs/architecture/20-frontend-roadmap.md`
- `docs/architecture/50-streaming-architecture.md`
- `.claude/skills/pipe-event-translation/SKILL.md`
- `.claude/skills/trajectory-iframe/SKILL.md`
- 重審觸發:多 tab 問題進一步惡化 OR 9000 user 拓展時 Pipe 性能不足
