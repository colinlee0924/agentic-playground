# 多代理架構:BU 內 Command + 跨 BU A2A

## 雙層架構總覽

```
┌─────────────────────────────────────────────────────────────────┐
│                         BU-A LangGraph                          │
│  ┌──────────────┐                                               │
│  │  Supervisor  │  ←─── TodoListMiddleware                      │
│  │              │       ReflectorMiddleware (寫操作)            │
│  │              │       PlanExecuteReplan (>5 步)               │
│  └──────┬───────┘                                               │
│         │ Command(goto, graph=Command.PARENT)                   │
│         ▼                                                       │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │ jira_agent   │  │ wiki_agent   │  │ build_agent  │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             │ a2a-sdk send_message
                             │ (Trajectory + Handoff Extensions)
                             │
┌────────────────────────────┼────────────────────────────────────┐
│                         BU-B LangGraph                          │
│         (相同結構,獨立 Postgres schema 與 Redis namespace)     │
└─────────────────────────────────────────────────────────────────┘
```

## 為何雙層?

| 場景 | 內層 (BU 內) | 外層 (跨 BU) |
|---|---|---|
| 通訊機制 | LangGraph `Command(graph=Command.PARENT)` | a2a-sdk `agent.send_message` |
| 序列化 | 無 (in-memory) | JSON over HTTP |
| 延遲 | <1ms | 10-100ms |
| 多租戶隔離 | 同 BU 共用 state | 完全隔離,獨立 AgentCard |
| Trace 一致性 | LangGraph thread_id | A2A `trace_id` propagation |
| 適用範圍 | 同一工作流的 sub-agent 協作 | 跨 BU 知識查詢 / 工作交付 |

## Sub-agent-as-tool pattern (ADR-0001)

**反模式**: 用 deprecated 的 `langgraph-supervisor` 套件
**選用**: supervisor `create_agent` + 自訂 handoff tool

```python
# src/supervisor/handoff_tools.py
def make_handoff_tool(target_agent: str, *, bu_id: str):
    @tool(name=f"handoff_to_{target_agent}")
    async def _handoff(reason: str) -> Command:
        await adispatch_custom_event("trajectory.handoff", {
            "target": target_agent, "bu_id": bu_id, "reason": reason
        })
        return Command(goto=target_agent, graph=Command.PARENT)
    return _handoff
```

每個 sub-agent 是一個 LangGraph node。Supervisor 透過 tool 呼叫它們,
在 trajectory 上以 edge 連接。

## 跨 BU A2A 流程

```
BU-A supervisor      A2A network        BU-B supervisor
     │                    │                   │
     │ a2a_client.send_message               │
     ├───────────────────►│                   │
     │  {trace_id, tenant, bu_id, payload}   │
     │                    ├──────────────────►│
     │                    │  (signed AgentCard verify)
     │                    │                   │
     │                    │  ◄ ─ ─ stream ─ ─ ┤
     │  ◄─ stream events ─┤                   │
     │  (trajectory updates)                  │
     │                    │                   │
     │  ◄────────────────────────────────────┤
     │       final result + audit trail       │
```

關鍵:
- **trace_id 必傳遞**:Langfuse span 跨 BU 連起來
- **tenant_id + bu_id 必傳遞**:多租戶隔離
- **AgentCard 必驗證 Ed25519 簽章**:防偽

## Supervisor pattern 三層 (ADR-0004)

| Pattern | 觸發條件 | 範例情境 |
|---|---|---|
| **TodoListMiddleware** (主軸) | 永遠開啟 | 任何多步驟任務 |
| **ReflectorMiddleware** (附加) | 寫操作前 | JIRA add_comment、Wiki update |
| **Plan-Execute-Replan** (附加) | 步驟 > 5 | 跨 BU 大型分析、root cause 分析 |

三者疊加範例:
```python
supervisor = create_agent(
    model=llm,
    tools=[handoff_to_jira, handoff_to_wiki, handoff_to_build, ...],
    middleware=[
        TodoListMiddleware(),        # 永遠開啟
        ReflectorMiddleware(         # 偵測寫操作
            triggers=["jira.add_comment", "wiki.update_page"]
        ),
        PlanExecuteReplanMiddleware( # 步驟多時啟動
            min_steps_to_trigger=5
        ),
    ],
    checkpointer=AsyncPostgresSaver.from_conn_string(...),
)
```

## 不選的替代方案

| 替代方案 | 不選原因 |
|---|---|
| `langgraph-supervisor` 套件 | 已 soft-deprecated |
| `langgraph-swarm` | 與 LangChain v1 標 untested |
| 純 a2a-sdk (BU 內也走 A2A) | 序列化開銷過大,trace 不一致 |
| 純 LangGraph (跨 BU 直接 import) | 違反多租戶隔離原則 (Article II) |
| RouteDecision (LLM + structured output + if/else) | 已過時 (見 ADR-0008) |

## 相關 ADR / Spec

- ADR-0001: sub-agent-as-tool
- ADR-0002: BU 內 Command + 跨 BU A2A
- ADR-0004: Supervisor pattern 三層
- `specs/mask-kernel/sub-agent-spec.md`
- `specs/mask-kernel/supervisor-spec.md`
