# 端到端 Streaming 鏈路 (12 道關卡)

## 全圖

```
[1] User input → Open WebUI
                      │
[2] WebUI Pipe Function 接管 chat completion
                      │
[3] Pipe 把訊息轉 LangChain message format
                      │
[4] supervisor.astream_events(version="v2") 啟動
                      │
[5] LangGraph 內部產生 events:
    - on_chain_start (node)
    - on_chat_model_stream (token)
    - on_tool_start / on_tool_end
    - custom events (trajectory.*, supervisor.reflection)
                      │
[6] Pipe 的 event_translator.py 即時翻譯:
    - token  → yield {"choices":[{"delta":{"content":...}}]}
    - tool   → markdown <details type="tool_calls">
    - traj   → __event_emitter__("status") + Redis pub/sub
    - intr   → __event_call__({"type":"input"})
                      │
[7] HITL 中斷時:
    - Postgres checkpoint 自動寫入
    - Redis queue 雙保險
    - 等使用者透過 iframe form 回應
                      │
[8] resume 後 LangGraph 從 checkpoint 繼續
                      │
[9] Trajectory relay 持續推 events 到 Redis pub/sub
                      │
[10] iframe (trajectory_tree.html) SSE 訂閱
     → Cytoscape graph 增量更新
                      │
[11] 完成時 yield {"choices":[{"delta":{},"finish_reason":"stop"}]}
                      │
[12] Open WebUI 顯示完整訊息 + iframe 顯示完整 trajectory
```

## 關卡 1-4: 輸入處理

使用者透過 Open WebUI 輸入 → Pipe Function 攔截 chat completion 請求 →
轉成 LangChain `HumanMessage` 列表 → 呼叫 supervisor 的 `astream_events(version="v2")`。

**關鍵**:用 `astream_events` 而非 `astream`,前者提供細粒度 callback events
(節點開始/結束、模型串流、工具呼叫),後者只給高層 state diff。

## 關卡 5-6: Event 翻譯

LangGraph 產出的 events 必須翻譯成 Open WebUI 能消費的格式。
**致命錯誤**:emit `delta.tool_calls` 會觸發 30-retry bug (issue #23066)。

正確做法:tool call 用 markdown:
```markdown
<details type="tool_calls" data-tool="search_jira" data-status="running">
<summary>🔧 search_jira</summary>
```json
{"args": {"jql": "project = PROJ"}, "result": null}
```
</details>
```

完成後 close 並更新 result:
```markdown
<details type="tool_calls" data-tool="search_jira" data-status="done">
<summary>🔧 search_jira ✓</summary>
```json
{"args": {...}, "result": [...]}
```
</details>
```

## 關卡 7-8: HITL (人類在迴路)

當 LangGraph 節點呼叫 `interrupt(...)` 時:

1. LangGraph 自動寫 Postgres checkpoint (`AsyncPostgresSaver`)
2. Pipe 偵測到 `__interrupt__` event,呼叫 `__event_call__({"type":"input", ...})`
3. **同時**把待審核項目 LPUSH 到 Redis `hitl:approvals:<tenant>:<thread>`
4. 等使用者透過 iframe form 回應
5. 收到回應後,`graph.astream(Command(resume=...), config={...})` 繼續

**為何雙保險**:
- 純 `__event_call__` 在 websocket 斷線時會丟失
- 純 Redis queue 沒有 LangGraph 內建的 thread state
- 兩者疊加可以從任意一邊恢復

## 關卡 9-10: Trajectory Relay 與 iframe

```
LangGraph adispatch_custom_event("trajectory.tool.call", {...})
         │
         ▼
src/trajectory_relay/relay.py 訂閱 events
         │
         ▼
Redis publish:  trajectory:<thread_id>
         │
         ▼
src/artifacts/trajectory_tree.html (iframe)
SSE 連線:  GET /trajectory/<thread_id>/stream
         │
         ▼
Cytoscape.js incremental update
```

**為何用 iframe 而非主訊息渲染**:
- Open WebUI 的主訊息有 multi-tab cross-talk 問題
- iframe 可獨立 sandbox,有獨立 SSE 連線
- 多 tab 各自只訂閱自己的 thread_id 通道,完全隔離

## 關卡 11-12: 終止

**強制要求**:
```python
# 永遠以這個結尾
yield {"choices": [{"delta": {}, "finish_reason": "stop"}]}
```

**錯誤行為**:
- 結尾是 `finish_reason: "tool_calls"` → UI 卡住等執行 (但其實已經做完)
- 沒有 finish_reason → UI 永遠 streaming
- 結尾 emit 額外 `delta.tool_calls` → 30-retry bug

## Anti-pattern 速查

| 症狀 | 病因 | 修正 |
|---|---|---|
| Pipe 被 call 30 次 | emit `delta.tool_calls` | 改 markdown details |
| UI 永遠 streaming | 缺 `finish_reason: stop` | 結尾 yield |
| Tool call 不顯示 | 用 native tool_calls 但前端不渲染 | 改 markdown details |
| Trajectory iframe 空白 | 沒 dispatch custom event | 加 `adispatch_custom_event` |
| Multi-tab 互串 | 用主訊息渲染 trajectory | 改 iframe + per-thread Redis channel |
| HITL 重啟後失效 | 純 in-memory queue | Postgres checkpoint + Redis 雙保險 |

## 相關 ADR / Spec / Skill

- ADR-0003: Open WebUI Pipe + iframe
- ADR-0007: HITL 雙保險
- `.claude/skills/pipe-event-translation/SKILL.md`
- `.claude/skills/trajectory-iframe/SKILL.md`
- `.claude/skills/hitl-approval-flow/SKILL.md`
- `src/pipe/event_translator.py`
- `src/trajectory_relay/relay.py`
