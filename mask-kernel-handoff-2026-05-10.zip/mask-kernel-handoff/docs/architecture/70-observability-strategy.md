# Observability 策略

## 三層觀察框架

```
[ Layer 1: Real-time UI ]   trajectory iframe (Cytoscape)
        │
[ Layer 2: Trace + Span ]   Langfuse (self-hosted) + OTel
        │
[ Layer 3: Audit + Compliance ]   Postgres event log (7 years)
```

## 為何選 Langfuse 而非 Phoenix

| 面向 | Langfuse | Phoenix |
|---|---|---|
| Air-gap 自架 | ✅ Docker | ✅ Docker |
| OTel 相容 | ✅ 完整 | ⚠️ 部分 |
| LangChain 內建整合 | ✅ `langfuse-langchain` | ✅ |
| SOC2 / 安全認證 | ✅ Type II | ⚠️ 較少 |
| Multi-tenant | ✅ project + tag | ⚠️ 弱 |
| 開發活躍度 | ✅ 2026 | ✅ |

**結論**:Langfuse 在 air-gap + 多租戶 + 合規三軸均勝出。

## Trace 傳遞 (Trace ID Propagation)

跨 BU A2A 呼叫時,**強制傳 trace_id**:

```python
# 跨 BU 發訊息
await a2a_client.send_message(
    target_agent_card,
    message,
    metadata={
        "trace_id": trace_id,            # ← 必填
        "tenant_id": tenant_id,
        "bu_id": "BU-A",
    },
)
```

接收端的 sub-agent executor 從 metadata 抽 trace_id,bind 到 langfuse span:

```python
# A2A executor
async def execute(self, ctx, queue):
    trace_id = ctx.message.metadata.get("trace_id")
    with langfuse.trace(id=trace_id, name="bu-b-handle"):
        ...
```

## 必觀察的事件 (constitution Article IV)

每個以下事件 MUST 同時 emit trajectory event AND Langfuse span:

| 事件 | trajectory event | Langfuse span name |
|---|---|---|
| Node 進入 | `trajectory.node.start` | `node:<name>` |
| Node 結束 | `trajectory.node.end` | (close above) |
| Tool 呼叫 | `trajectory.tool.call` | `tool:<name>` |
| Tool 結果 | `trajectory.tool.result` | (close above) |
| Handoff | `trajectory.handoff` | `handoff:<from>:<to>` |
| Reflection | `supervisor.reflection` | `reflection:<tool>` |
| Interrupt | `interrupt.start` | `hitl:<approval_type>` |
| Resume | `interrupt.resume` | (close above) |

## SLO 與告警

| SLO | 目標 | 監控指標 | 告警 |
|---|---|---|---|
| Pipe 首 token | p95 < 2s | Langfuse `time_to_first_token` | PagerDuty |
| Sub-agent 平均延遲 | p95 < 5s per agent | Span duration | Slack |
| 跨 BU A2A 成功率 | > 99% | A2A response code | PagerDuty |
| HITL 流程不丟失 | 100% | Postgres checkpoint count = trajectory.interrupt count | PagerDuty |

## CI 階段的可觀察性檢查

```bash
# 每個新 sub-agent 必須通過此檢查
pytest src/tests/contract/test_observability_conformance.py
```

該測試會檢查:
1. 所有 LangGraph node 是否 emit trajectory event
2. 所有 cross-BU call 是否傳 trace_id
3. 所有 HITL 是否有 Postgres checkpoint + Redis queue 雙寫

## 相關 ADR / Spec

- 憲法 Article IV
- `src/shared/observability.py` (Langfuse + OTel hooks)
- `specs/mask-kernel/api-contracts.md` (Trace ID propagation 章節)
