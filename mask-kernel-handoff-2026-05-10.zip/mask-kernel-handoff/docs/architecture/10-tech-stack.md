# 技術棧鎖版本決策

## 鎖版本一覽

| 元件 | 版本 | 鎖版本理由 | 升級觸發條件 |
|---|---|---|---|
| Python | 3.12.x | 與 LangChain v1 相容性最佳 | Python EOL |
| LangChain | **1.2.x** | v1 主推,`create_agent` 穩定 | LangChain 2.0 release |
| LangGraph | **1.1.x** | `Command.PARENT` 與 `interrupt` 穩定 | LangGraph 2.0 release |
| a2a-sdk | **1.0.2** | A2A v1.0.0 spec 對齊 (LF 2026-03 釋出) | A2A v1.1 spec |
| Langfuse | self-hosted 2026-Q1 | OSS、air-gap 可行、取代 Phoenix | 重大 schema 改動 |
| Postgres | 16.x | `AsyncPostgresSaver` 需 ≥14 | Postgres EOL |
| Redis | 7.x | Stream + pub/sub 完整 | 重大 ABI 改動 |
| Open WebUI | latest stable | Pipe Function API 穩定 | 計畫切 LibreChat 時 |

## 為何鎖這四個元件?

LangChain / LangGraph / a2a-sdk / A2A protocol 是 mask-kernel 的「**核心契約層**」,
任何升級都會觸動以下其中一項:

- AgentCard schema (a2a-sdk)
- `Command(goto, graph)` semantics (LangGraph)
- `create_agent` middleware API (LangChain)
- A2A wire protocol (`message/send`, `message/stream`)

任一升級都需經 ADR 評審,因為涉及 9000 user × 15 BU 的相容性風險。

## 自架元件理由

- **Postgres**: HITL checkpoint 需強一致性與長期保存,SQLite 不可行
- **Redis**: trajectory pub/sub 需 sub-second 延遲,Postgres LISTEN/NOTIFY 規模不足
- **Langfuse**: air-gap 必須自架;選 Langfuse 而非 Phoenix 因 SOC2、OTel 完整
- **AIDE Gateway**: 公司既有 IT 服務,提供 per-user JWT,所有 LLM 呼叫經此

## 不選的替代方案

- **OpenAI Agents SDK**: 與 LangGraph 雙棧維護成本過高
- **Microsoft Agent Framework**: A2A 整合較淺,生態不熟
- **Google ADK**: Python SDK 規模不及 LangChain,但其三層 memory 設計值得借鑑 (見 60-shared-state-strategy.md)
- **CrewAI**: hierarchical 模式 issue #4783 委派不穩

## 升級工作流

```
新版本可用
   ↓
建立 ADR 草案 (建議模板: 0001-sub-agent-as-tool.md)
   ↓
跑 src/tests/migration/test_<component>_<old>_to_<new>.py
   ↓
評審 + 投票
   ↓
更新 requirements.txt + CLAUDE.md + 本文件
   ↓
PoC 環境驗證 1 週
   ↓
Phase 1 BU 灰度 2 週
   ↓
全 15 BU rollout
```

詳見 `tasks/migration-plan.md`。
