# 已驗證反模式清單

## 為何維護此清單

每個反模式都是「曾經有人提案 + 經過評估 + 確認不適用」的結果。
保留證據與替代方案,讓未來的工程師不重蹈覆轍。

## 反模式 #1: 使用 langgraph-supervisor 套件

**證據**: LangChain 官方 README 已標 "soft-deprecated",建議改用
`create_agent` 直接寫 supervisor。

**為何不適合**:
- 該套件未持續更新以對齊 LangChain v1
- 整合 TodoListMiddleware 等 v1 middleware 困難
- 升級風險高

**替代**: ADR-0001 採 sub-agent-as-tool pattern

**CI 檢查**:
```bash
grep -rE "from langgraph_supervisor" src/ && exit 1
```

---

## 反模式 #2: 使用 langgraph-swarm 套件

**證據**: 官方文件對 LangChain v1 `create_agent` 標 "untested"

**為何不適合**:
- 與 v1 API 相容性未驗證
- swarm 的 peer-to-peer 模式不適合 mask-kernel 的中央 supervisor 場景

**替代**: 用 supervisor + handoff tool (ADR-0001)

**CI 檢查**:
```bash
grep -rE "from langgraph_swarm" src/ && exit 1
```

---

## 反模式 #3: RouteDecision (LLM with structured output → if/else routing)

**證據**: 此 pattern 來自 Coding-Crashkurse 的 A2A 教學,在 production 多
agent 場景已過時 (見 ADR-0008)。

**為何不適合**:
- LLM 一次只能處理一個 routing 決策,擴展性差
- 無 trajectory 結構,debug 困難
- 與 LangChain v1 middleware 模式不一致

**替代**: handoff tool (ADR-0001) + Command(goto, graph=PARENT)

**CI 檢查**:
```bash
grep -rE "class RouteDecision\b" src/ && exit 1
```

---

## 反模式 #4: emit `delta.tool_calls` chunk

**證據**: Open WebUI issues #23066 / #23118 (30-retry bug)

**為何不適合**:
- Open WebUI 把 `delta.tool_calls` 當作 native function call,會嘗試重新執行
- 觸發無限循環直到 `CHAT_RESPONSE_MAX_TOOL_CALL_RETRIES` (預設 30)

**替代**: markdown `<details type="tool_calls">` 渲染

**CI 檢查**:
```bash
grep -rE "delta\.tool_calls" src/pipe/ && exit 1
```

---

## 反模式 #5: async tool 內呼叫 get_stream_writer()

**證據**: LangGraph issue #6447 — 在 async context 有 race condition,
可能丟失 events 或 deadlock。

**為何不適合**:
- `get_stream_writer()` 在 async generator 內無法可靠取得當前 writer
- 多並發 tool 時可能拿到錯誤的 writer

**替代**: `from langchain_core.callbacks import adispatch_custom_event`

**CI 檢查**:
```bash
grep -rE "get_stream_writer\(.*async" src/ && exit 1
```

---

## 反模式 #6: 缺 finish_reason: stop 終止

**證據**: Open WebUI issue #20196 (UI hangs streaming)

**為何不適合**: UI 永遠認為還在 streaming,使用者看到旋轉游標不停。

**替代**:
```python
# Pipe Function 結尾必須:
yield {"choices": [{"delta": {}, "finish_reason": "stop"}]}
```

**CI 檢查**: AST 分析 (見 `src/shared/audit.py`)

---

## 反模式 #7: 跨 BU 直接 import 模組

**證據**: 違反憲法 Article II (multi-tenant by construction) 與
Article IX (sub-agent boundaries)。

**為何不適合**:
- 跨 BU 共用程式碼會造成 release coupling
- 無法獨立 deploy / scale 各 BU
- 多租戶隔離失效

**替代**: 跨 BU 用 a2a-sdk send_message + AgentCard 發布

**CI 檢查**:
```bash
# BU-A 不可以 import BU-B 的 agent
grep -rE "from src\.agents\.bu_b" src/agents/bu_a/ && exit 1
```

---

## 反模式 #8: CrewAI hierarchical mode

**證據**: CrewAI issue #4783 — manager agent 無法穩定委派給 worker

**為何不適合**:
- manager 的 routing 決策依賴 LLM 的 chain-of-thought,不可靠
- 無 trajectory 結構
- 不支援 `interrupt` HITL

**替代**: 不使用 CrewAI;mask-kernel 採 LangGraph supervisor

---

## 反模式 #9: 純 in-memory HITL 佇列

**證據**: 違反憲法 Article VIII (HITL is persistent)

**為何不適合**:
- Process restart 後 pending approvals 全部丟失
- 9000 user 並發,記憶體佇列無法擴充

**替代**: ADR-0007 雙保險 (Postgres checkpoint + Redis queue)

---

## 反模式 #10: 硬編 AIDE Gateway URL

**證據**: 多環境 (dev / staging / prod) 切換需要

**為何不適合**:
- 環境切換困難
- 安全:URL 出現在 git history

**替代**: `os.environ["AIDE_GATEWAY_URL"]`

**CI 檢查**:
```bash
grep -rE "https?://aide\." src/ | grep -v "os\.environ\|Settings\." && exit 1
```

---

## 反模式對照表 (快速查詢)

| # | 模式 | 嚴重性 | CI 自動擋 |
|---|---|---|---|
| 1 | langgraph-supervisor | 高 | ✅ |
| 2 | langgraph-swarm | 高 | ✅ |
| 3 | RouteDecision | 中 | ✅ |
| 4 | delta.tool_calls | 高 | ✅ |
| 5 | async + get_stream_writer | 高 | ✅ |
| 6 | 缺 finish_reason: stop | 高 | ⚠️ AST |
| 7 | 跨 BU import | 高 | ✅ |
| 8 | CrewAI hierarchical | 中 | (不引入) |
| 9 | in-memory HITL | 高 | ⚠️ 人工 review |
| 10 | 硬編 URL | 中 | ✅ |

## 相關文件

- 憲法 Article VII
- `.claude/skills/avoiding-pitfalls/SKILL.md`
- `src/shared/audit.py` (CI grep gate runner)
