# mask-kernel 系統一頁總覽

## 三層心智模型

```
┌─────────────────────────────────────────────────────────────┐
│  前端層  Open WebUI (now) → LibreChat (mid) → AG-UI (long)   │
├─────────────────────────────────────────────────────────────┤
│  協調層  Supervisor: TodoList + Reflector + Plan-Execute     │
│         BU 內: Command.PARENT  |  跨 BU: a2a-sdk send_message │
├─────────────────────────────────────────────────────────────┤
│  代理層  Jira / Wiki / Build / ... 每個 sub-agent 自帶       │
│         AgentCard + Trajectory Extension + Handoff Extension │
├─────────────────────────────────────────────────────────────┤
│  基礎層  Postgres (checkpoint) + Redis (relay/queue) +       │
│         Langfuse (trace) + AIDE Gateway (per-user JWT)       │
└─────────────────────────────────────────────────────────────┘
```

## 核心架構不變式 (對應 ADR)

1. **雙層路由** (ADR-0002): BU 內 `Command(goto, graph=Command.PARENT)`,跨 BU 用 a2a-sdk
2. **Sub-agent-as-tool** (ADR-0001): supervisor 擁有 graph,sub-agent 透過 tool 呼叫
3. **Supervisor pattern 三層** (ADR-0004): TodoList 為主,寫操作疊 Reflector,巨型分析疊 Plan-Execute-Replan
4. **Streaming 契約** (ADR-0003): tool call 渲染為 markdown details,絕不 emit `delta.tool_calls`
5. **HITL 雙保險** (ADR-0007): `__event_call__` + Postgres checkpoint + Redis queue
6. **凍結 URI** (ADR-0006): `urn:m-corp:masksdk:trajectory:v1`、`urn:m-corp:mask-kernel:handoff:v1`

## 規模與環境

- **服務對象**: ~9000 工程師 × 15 BU (M 公司內部)
- **環境**: air-gapped 內網,無外部網路 egress
- **基礎設施**: 全自架 — Postgres / Redis / Langfuse / AIDE Gateway
- **測試環境**: docker compose up 即可在筆電完整跑通

## 為何不選 X (常見問題)

| 為什麼不用 X? | 原因 (對應反模式) |
|---|---|
| `langgraph-supervisor` | 上游 soft-deprecated (見 ADR-0001) |
| `langgraph-swarm` | 與 LangChain v1 `create_agent` 標 untested |
| `RouteDecision` (LLM + if/else) | production multi-agent 場景已過時 (ADR-0008) |
| CrewAI hierarchical | 委派失敗 (issue #4783),manager 無法穩定路由 |
| 直接 emit `delta.tool_calls` | 觸發 Open WebUI 30-retry bug (issue #23066) |

完整圖見 `architecture-diagram.svg` (待補)。各層對應 ADR:0003 / 0004 / 0001-0002 / 0005-0007。
