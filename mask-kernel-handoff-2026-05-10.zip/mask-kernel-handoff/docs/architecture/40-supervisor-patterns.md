# Supervisor Pattern 三層策略

## 為何「三層疊加」而非「擇一」

不同任務複雜度需要不同 pattern。如果只用一種,會在某些情境失準:

- **只用 TodoList**: 寫操作沒人把關,易誤觸 destructive ops
- **只用 Reflector**: 步驟多時無計畫骨架,LLM 易迷失
- **只用 Plan-Execute-Replan**: 簡單查詢被過度規劃,token 浪費

mask-kernel 採「**TodoList 永遠開啟,Reflector / Plan-Execute 條件啟動**」混合策略。

## 三層細節

### Layer 1: TodoListMiddleware (永遠開啟)

LangGraph 標準 middleware,管理 `state.todos: list[TodoItem]`。
LLM 在每次決策前看到當前 todo list,決策後可呼叫 `update_todos` tool 更新。

**作用**:
- 給 LLM 步驟骨架,避免「想到哪做到哪」
- Trajectory iframe 可顯示 progress bar
- 失敗時可從 checkpoint resume,todo 狀態保留

**不適合**:無 (永遠開啟)

### Layer 2: ReflectorMiddleware (寫操作觸發)

在偵測到寫操作 tool 被選中時,**先暫停**並呼叫一次「reflection LLM」:
- 列出此操作的 side-effect
- 詢問是否真的要執行
- 若是 destructive (delete / overwrite),自動觸發 HITL approval

**觸發條件**:tool name 在 `triggers=[...]` 列表中,例如:
```python
ReflectorMiddleware(triggers=[
    "jira.add_comment",
    "jira.update_status",
    "wiki.update_page",
    "wiki.delete_page",
    "build.trigger_pipeline",
])
```

**不適合**:純查詢 (search_jira, get_wiki_page) — 會增加 latency 無收益

### Layer 3: PlanExecuteReplan (步驟多觸發)

當 todo list 預計步驟 > N (預設 5) 時啟用 Plan-Execute-Replan loop:

```
Plan      → LLM 產出完整 plan
  ↓
Execute   → 跑下一步
  ↓
Replan    → 評估結果,更新或保留 plan
  ↓
(loop until done)
```

**觸發條件**:`TodoListMiddleware` 預估 todo 數 ≥ `min_steps_to_trigger`

**不適合**:單步查詢、多輪對話的微互動

## 完整組合範例

```python
# src/supervisor/middleware.py
from langgraph.prebuilt import create_react_agent
from langchain_core.callbacks import adispatch_custom_event

supervisor = create_agent(
    model=llm,
    tools=[
        handoff_to_jira, handoff_to_wiki, handoff_to_build,
        request_human_approval,  # used by Reflector when triggers fire
    ],
    middleware=[
        # Layer 1: 永遠開啟
        TodoListMiddleware(),

        # Layer 2: 寫操作疊加
        ReflectorMiddleware(
            triggers=[
                "handoff_to_jira",  # 因為 jira agent 內可能寫
                "handoff_to_wiki",
            ],
            reflection_llm=llm,
            on_reflect=lambda spec: adispatch_custom_event(
                "supervisor.reflection",
                {"spec": spec},
            ),
        ),

        # Layer 3: 巨型分析疊加
        PlanExecuteReplanMiddleware(
            min_steps_to_trigger=5,
            replan_after_each_step=True,
        ),
    ],
    checkpointer=AsyncPostgresSaver.from_conn_string(DATABASE_URL),
)
```

## 對比矩陣

| 任務 | 只 TodoList | + Reflector | + Plan-Execute |
|---|---|---|---|
| 「PROJ-123 進度?」 | ✅ 1 步即完 | ✅ (無寫,Reflector noop) | ❌ 過度規劃 |
| 「在 PROJ-123 加註解 X」 | ⚠️ 直接寫,風險 | ✅ Reflector 攔下 + HITL | ⚠️ 過度規劃 |
| 「分析 5 個 BU 過去 3 月 root cause」 | ❌ 步驟散亂 | ⚠️ 仍可能迷失 | ✅ 結構化執行 |
| 「Wiki 寫一份新 SOP 並通知 5 個 owner」 | ❌ 易漏步驟 | ✅ 寫操作把關 | ✅ 結構化規劃 |

## 不選的替代方案

| 替代 | 不選原因 |
|---|---|
| ReAct (zero-shot) | 寫操作沒把關,且無計畫骨架 |
| 純 Plan-Execute | 簡單查詢過度規劃 |
| Self-Reflection only | 沒有寫操作觸發機制,效果不可預期 |
| Tree of Thoughts | 計算成本過高,9000 user 不可行 |

## 相關 ADR / Spec

- ADR-0004: TodoListMiddleware 為 supervisor 主軸
- `specs/mask-kernel/supervisor-spec.md`
- `src/supervisor/middleware.py`
