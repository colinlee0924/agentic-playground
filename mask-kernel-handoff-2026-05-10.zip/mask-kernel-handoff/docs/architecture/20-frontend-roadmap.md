# 前端路線圖:Open WebUI → LibreChat → AG-UI

## 三段路線總覽

```
Phase 1 (M0-M5): Open WebUI Pipe + embeds iframe       (短期,正在進行)
        │
        ▼
Phase 2 (M5-M9): LibreChat + Assistant-UI BU 入口      (中期)
        │
        ▼
Phase 3 (M9-M14): AG-UI/CopilotKit + A2UI v0.9 GenUI   (長期)
```

## Phase 1: Open WebUI (短期 3-6 個月)

**為何選 Open WebUI**:已部署、IT 熟悉、Pipe Function 容易整合 LangChain。

**已知限制**:
- Multi-tab cross-talk:同一 session 多個 tab 會收到對方訊息 (透過 embeds iframe 隔離規避)
- 30-retry bug:emit `delta.tool_calls` 會無限重試 (改用 markdown details)
- AsyncGenerator hang:UI 卡 streaming 中 (見 issue #20196)
- 無 BU 級客製能力

**因應策略**:
- Trajectory tree → embeds iframe (見 ADR-0003)
- HITL → `__event_call__` + Postgres checkpoint + Redis queue 雙保險 (見 ADR-0007)
- Tool call → markdown `<details type="tool_calls">` (見 ADR-0003)

## Phase 2: LibreChat + Assistant-UI (中期)

**為何切換**:
- LibreChat 提供更豐富的 conversation forking、artifact 管理
- Assistant-UI 提供 BU 客製化頁面 (e.g. mask 製造特定的 wafer 視覺化)
- 解決 multi-tab cross-talk 根本問題

**遷移策略**:
- A2A endpoint 不變 (LangGraph supervisor 對前端解耦)
- Pipe Function 改寫為 LibreChat plugin
- 新 BU 直接上 Assistant-UI

## Phase 3: AG-UI / CopilotKit + A2UI (長期)

**為何最終目標**:
- AG-UI 是 backend 事件出口的事實標準 (CopilotKit 主導)
- A2UI v0.9 提供 generative UI 的標準 schema
- 真正的「前端不綁定」架構 (backend 出 events,任何前端可消費)

**前置條件**:
- A2UI 至少 v1.0 GA (目前 v0.9 為 draft,仍有 breaking change 風險)
- 內部前端團隊有 React 經驗 (目前以後端為主)

**實作路徑**:
- backend 補上 AG-UI events emitter (與既有 trajectory event 並存)
- 新 generative widget 走 A2UI schema
- Phase 4 完成後,Open WebUI 與 LibreChat 並存,以使用者偏好為主

## 三前端能力對比

| 能力 | Open WebUI Pipe | LibreChat | AG-UI/CopilotKit |
|---|---|---|---|
| BU 客製化 | ❌ 無 | ⚠️ 有限 | ✅ 完整 |
| Trajectory 視覺化 | ⚠️ embeds iframe | ✅ 原生 artifact | ✅ React 元件 |
| Multi-tab 隔離 | ❌ 需 iframe 規避 | ✅ 原生 | ✅ 原生 |
| HITL 流暢度 | ⚠️ `__event_call__` | ✅ form 元件 | ✅ React form |
| Generative UI | ❌ 無 | ⚠️ 有限 | ✅ A2UI 完整 |
| 開發成本 | 低 | 中 | 高 |
| Air-gap 友善 | ✅ | ✅ | ⚠️ 需自架 CopilotKit Cloud |

## 不會走的路線

- **完全自建前端**: 維護成本過高,9000 user 規模需專職前端團隊
- **直接跳 Phase 3**: A2UI v0.9 仍 draft,風險過高
- **保留 Open WebUI 永久**: multi-tab + 客製化天花板無解
