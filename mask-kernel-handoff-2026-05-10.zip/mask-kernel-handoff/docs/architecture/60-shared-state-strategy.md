# Shared State 策略 (借鑑四大來源)

## 目標

mask-kernel 需要在 BU 內 / 跨 BU / 跨 session 三個層次處理共享狀態,
但不發明輪子。我們**借鑑**業界四大來源,組合出 mask-kernel 自己的策略。

## 借鑑來源

### 1. Google ADK 三層 memory

ADK 把 memory 分成 short-term (session)、long-term (memory store)、
artifact (binary)。mask-kernel 沿用此分層思路:

| 層級 | mask-kernel 對應 | 儲存 |
|---|---|---|
| Short-term | LangGraph state + thread_id | in-memory + Postgres checkpoint |
| Long-term | shared memory block (RFC-003) | Postgres `memory_blocks` table |
| Artifact | trajectory snapshot, tool result blob | Postgres `artifacts` + S3 (可選) |

### 2. Letta shared memory block

Letta 提出「**memory block**」概念:多個 agent 共享同一個 block,
任一 agent 寫入,其他可即時讀。我們在 RFC-003 提案類似機制:

```python
# RFC-003 (proposal)
class SharedMemoryBlock:
    block_id: str               # e.g., "mask-design-spec-PROJ-123"
    tenant_id: str
    bu_ids: list[str]           # 哪些 BU 可讀寫
    content: str                # markdown
    version: int                # 樂觀鎖
    last_modified_by: str       # agent name
```

跨 BU 場景下,supervisor A 寫入 block,supervisor B 在下次互動時可讀。

### 3. Microsoft Agent Framework Magentic ledger

MAF 的 Magentic agent 在每次 tool call 之後寫一筆「ledger entry」,
形成 audit trail。mask-kernel 的 trajectory event 借鑑此設計:
**每個 event 都進 Postgres,可永久 replay**。

### 4. Olejniczak State Extension (a2a-extensions)

Olejniczak 在 a2a-extensions 提案了 state extension URI,
讓 a2a-sdk message 可帶任意 state delta。mask-kernel 不採用此擴充
(因為 v0.x 仍 unstable),但**沿用「URI namespacing」思路**設計
自己的 trajectory + handoff extension URI。

## mask-kernel 的整合策略

```
┌─────────────────────────────────────────────────────────────┐
│  Tier 1: BU 內 LangGraph state (TypedDict + checkpointer)    │
│           - thread_id 隔離                                    │
│           - 在 BU 內所有 sub-agent 共享                       │
└─────────────────────────────────────────────────────────────┘
                              ↕
┌─────────────────────────────────────────────────────────────┐
│  Tier 2: 跨 BU shared memory block (RFC-003 提案中)         │
│           - block_id namespace                               │
│           - 樂觀鎖 + 衝突解決                                 │
│           - 跨 BU 寫入需 Reflector 把關                       │
└─────────────────────────────────────────────────────────────┘
                              ↕
┌─────────────────────────────────────────────────────────────┐
│  Tier 3: 全域長期 trace + audit (Langfuse + Postgres)        │
│           - trace_id propagation                              │
│           - Magentic-style ledger                             │
│           - 7 年保留 (compliance)                             │
└─────────────────────────────────────────────────────────────┘
```

## 為何不直接採用任何一個來源

| 來源 | 不直接採用原因 |
|---|---|
| ADK | Python SDK 不如 LangChain 成熟 |
| Letta | LLM-OS 架構與我們的 supervisor 模式不一致 |
| MAF | A2A 整合較淺,生態不熟 |
| Olejniczak State Extension | a2a-extensions v0.x 仍 unstable |

但**借鑑**比**全盤採用**更務實:每個來源各取一點精華,組成 mask-kernel
自己的 strategy。

## 風險與緩解

| 風險 | 緩解 |
|---|---|
| 跨 BU 寫入衝突 | 樂觀鎖 + 寫操作觸發 Reflector + HITL |
| Memory block 失控膨脹 | 定期 GC + size quota per BU |
| Trace 跨 BU 不一致 | trace_id 強制 propagate,CI grep gate 檢查 |

## 相關 RFC / Spec

- RFC-003: 跨 BU shared memory block 機制 (借鑑 Letta)
- ADR-0007: HITL 雙保險 (寫入把關)
- `specs/mask-kernel/api-contracts.md` (memory block API,RFC-003 通過後加)
