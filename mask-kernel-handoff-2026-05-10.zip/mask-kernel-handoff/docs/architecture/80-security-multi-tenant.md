# 安全與多租戶策略

## 三層隔離模型

```
[ Network ]    Air-gapped intranet, no external egress
                       │
[ Auth ]       AIDE Gateway per-user JWT (rotating, ≤ 8h TTL)
                       │
[ Tenant ]     tenant_id + bu_id 強制隔離 (RLS in Postgres,
               key prefix in Redis, namespace in Langfuse)
```

## AIDE Gateway 與 JWT

每個 LLM 呼叫經 AIDE Gateway,Gateway 驗證 per-user JWT 並轉發到內部模型。
mask-kernel **絕不直接呼叫外部 LLM provider**。

```python
# src/shared/llm.py
async def call_llm(prompt: str, *, jwt: str) -> str:
    headers = {"Authorization": f"Bearer {jwt}"}
    async with httpx.AsyncClient(
        base_url=os.environ["AIDE_GATEWAY_URL"],
        timeout=30,
    ) as client:
        return await client.post("/v1/chat/completions", ...)
```

JWT 從 Open WebUI session cookie 取得,在 Pipe Function 內傳遞給 LangGraph
作為 `RunnableConfig.configurable.jwt`,所有 sub-agent 沿用同一 JWT。

## Multi-Tenant 隔離

### Postgres Row-Level Security

每張表加 `tenant_id` 與 `bu_id` 欄位,啟用 RLS:

```sql
ALTER TABLE checkpoints ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON checkpoints
  USING (tenant_id = current_setting('app.tenant_id')::uuid);
```

每個 connection 設定 `app.tenant_id`:

```python
async with engine.begin() as conn:
    await conn.execute(text(
        "SET app.tenant_id = :tid"
    ), {"tid": str(tenant_id)})
    # 所有後續查詢自動加 tenant filter
```

### Redis key prefix

所有 Redis key 用 `<tenant_id>:<bu_id>:<resource>` 格式:

```
trajectory:tenant-x:bu-a:thread-123:events
hitl:tenant-x:bu-a:approvals
agent_card:tenant-x:bu-a:jira_agent
```

### Langfuse project + tag

每個 BU 一個 Langfuse project,所有 trace tag `tenant_id` + `bu_id`。
跨 BU trace 用 `trace_id` 連接,但歸屬於發起者的 project。

## AgentCard 簽章

每個 sub-agent 的 `agent_card.json` MUST Ed25519 簽章:

```python
# src/shared/agent_card_signer.py
import nacl.signing
def sign_card(card_dict: dict, key_path: str) -> dict:
    key = nacl.signing.SigningKey(open(key_path, "rb").read())
    canonical = json.dumps(card_dict, sort_keys=True, separators=(",", ":"))
    sig = key.sign(canonical.encode()).signature.hex()
    return {**card_dict, "signature": sig}
```

接收端驗證:

```python
def verify_card(card_dict: dict, public_key_path: str) -> bool:
    sig = bytes.fromhex(card_dict["signature"])
    body = {k: v for k, v in card_dict.items() if k != "signature"}
    canonical = json.dumps(body, sort_keys=True, separators=(",", ":"))
    verify_key = nacl.signing.VerifyKey(open(public_key_path, "rb").read())
    try:
        verify_key.verify(canonical.encode(), sig)
        return True
    except nacl.exceptions.BadSignatureError:
        return False
```

## 跨 BU 授權矩陣

```
[Caller BU] → [Target BU]: Allowed?

從 BU 自己的 AgentCard 看 allowed_callers:
{
  "name": "build_agent",
  "tenant_id": "...",
  "bu_id": "BU-B",
  "allowed_callers": [
    {"bu_id": "BU-A", "ops": ["read"]},
    {"bu_id": "BU-C", "ops": ["read", "trigger"]}
  ]
}

a2a-sdk executor 在處理 incoming message 時檢查 caller 的 bu_id。
```

## 必須通過的安全 CI gate

```bash
# 1. 沒有硬編 secret
grep -rE "api_key\s*=\s*['\"][a-zA-Z0-9]{20,}" src/ && exit 1

# 2. 所有 agent_card.json 有 signature 欄位
find src/agents -name "agent_card.json" -exec \
  jq -e '.signature' {} \; > /dev/null

# 3. 所有 db query 有 tenant filter (簡易檢查)
grep -rE "SELECT.*FROM (checkpoints|memory_blocks)" src/ | \
  grep -v "WHERE.*tenant_id" && exit 1

# 4. AIDE Gateway URL 不硬編
grep -rE "https?://aide\." src/ | grep -v "os\.environ\|Settings\." && exit 1
```

## 風險清單

| 風險 | 機率 | 衝擊 | 緩解 |
|---|---|---|---|
| JWT 洩漏 | 低 | 高 | 短 TTL + rotation + Langfuse 異常 trace 偵測 |
| 跨 BU 資料外洩 | 低 | 高 | RLS + agent_card allowed_callers + audit log |
| AgentCard 偽造 | 極低 | 高 | Ed25519 簽章 + CI 檢查 |
| Postgres RLS 設定錯誤 | 中 | 高 | `tests/security/test_rls.py` 強制覆蓋率 |

## 相關 ADR

- 憲法 Article I (air-gap)、II (multi-tenant)
- `specs/mask-kernel/api-contracts.md` (auth section)
- `src/shared/agent_card_signer.py`
