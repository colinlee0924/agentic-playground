# RFC-001: 從 PoC 升級到 production 的分階段路線

- **作者**: Colin
- **狀態**: Draft (open for comments)
- **建立日期**: 2026-05-10
- **相關 ADR**: 0001 ~ 0008
- **討論截止**: 2026-06-01

## Summary

提出 mask-kernel 從目前單 BU PoC,逐步擴展至 15 BU × 9000 user 的
四階段路線圖,涵蓋 14 個月。

## Motivation

PoC 已驗證 12 步端到端流程 (PROJ-123 + mask-design-spec)。下一步需回答:
何時擴第二 BU?何時切 LibreChat?何時導入 AG-UI?如何避免 big-bang rollout?

## 四階段路線

### Phase 1 (M0~M2): 單 BU production hardening

**Entry**: PoC 12 步流程通過
**Exit**: BU-A 上線、SLO 達標、disaster recovery 演練通過

**任務**:
- Langfuse OTel exporter 完整接入
- Postgres backup + restore 演練
- Redis cluster (3 nodes)
- AsyncPostgresSaver retry-on-disconnect
- E2E test suite 覆蓋率 > 80%
- CI grep gate 全綠
- BU-A 100 user 灰度

**Rollback plan**: 切回手工 JIRA 流程,Pipe 暫停

### Phase 2 (M2~M5): 第 2-3 BU 擴展 + AgentCard discovery

**Entry**: Phase 1 SLO 連續 30 天達標
**Exit**: 3 BU 上線、跨 BU handoff 驗證

**任務**:
- AgentCard registry (Postgres-backed,見 RFC-002)
- BU-B + BU-C 各自 a2a-server
- Reflector middleware (寫操作把關)
- 跨 BU trace_id propagation 完整
- 向 Linux Foundation A2A WG 註冊自訂 URI

**Rollback plan**: 新 BU 暫時 fallback 到 BU-A 集中處理

### Phase 3 (M5~M9): 切 LibreChat + Assistant-UI

**Entry**: 3 BU 穩定運行,使用者反饋 Open WebUI 客製化不足
**Exit**: LibreChat 上線、Open WebUI 進入維護模式

**任務**:
- LibreChat 部署 (IT 評估 + 部署 1.5 月)
- Pipe Function → LibreChat plugin 改寫
- Assistant-UI BU portal PoC (BU-A 試點)
- 雙前端並行 1 個月,使用者主動切換
- 12 BU rollout

**Rollback plan**: 兩前端並存 1 個月,Open WebUI 仍可用

### Phase 4 (M9~M14): AG-UI / CopilotKit + A2UI v0.9

**Entry**: A2UI ≥ v1.0 GA OR Phase 3 完成 6 個月後 (取較晚)
**Exit**: 全 15 BU + AG-UI events 可被任意前端消費

**任務**:
- backend 補上 AG-UI events emitter (與既有 trajectory event 並存)
- A2UI generative widgets 實作
- BU-A 試點 CopilotKit React 前端
- 全 BU rollout

**Rollback plan**: 仍可使用 LibreChat (Phase 3 產物)

## Drawbacks

- 4 階段需 14 個月,期間維護兩套前端 (Phase 3 transitional)
- A2UI v0.9 為 draft 標準,Phase 4 有重做風險

## Rationale and alternatives

- **Big-bang rollout**: 風險過高,9000 user 不容失敗
- **跳 Phase 3 直接 Phase 4**: A2UI 仍 draft,前端團隊 React 經驗不足
- **永遠停在 Phase 1**: BU 客製化天花板與 Open WebUI multi-tab 限制無解

## Prior art

- Spotify 多 squad multi-agent rollout (2025)
- Netflix Maestro 階段化導入 (2024)
- LinkedIn Job Coach (LangGraph 大規模 production)

## Unresolved questions

- [ ] Phase 2 的 AgentCard registry 是 etcd 還是 Postgres? (RFC-002 待定)
- [ ] Phase 4 的 A2UI 是否等 v1.0 GA?
- [ ] 是否需要在 Phase 2 補上 Assistant-UI 試點 BU?

## Future possibilities

- Phase 5: 開放部分 sub-agent 給合作廠商 (需 ADR-0006 trajectory extension 強化)
