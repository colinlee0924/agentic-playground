# RFC-002: BU Agent Registry 與 AgentCard Discovery

- **作者**: Colin
- **狀態**: Draft
- **建立日期**: 2026-05-10
- **相關 ADR**: 0002, 0006

## Summary

設計跨 BU AgentCard 註冊與發現機制。9000 user × 15 BU 規模下,
agent 不能硬編 URL,必須有 service discovery。

## Motivation

當前 PoC 的跨 BU 呼叫硬編 URL,不可擴展。每加一個 BU agent 需:
- 通知所有其他 BU 更新 config
- 重新部署
- 維護 stale 連結

## 提案

提供 `mask-kernel-registry` 服務,提供:
1. AgentCard 註冊 API
2. AgentCard 發現 API (按 BU、能力、版本過濾)
3. 健康檢查 (定期 ping `/.well-known/agent.json`)
4. 版本管理 (一個 agent 可同時註冊多版本)

## API 草案

```http
POST /registry/agents
  body: {agent_card_json}
  → 201 + registry_id

GET /registry/agents?bu=BU-A&capability=trajectory:v1
  → 200 + [agent_card_1, ...]

DELETE /registry/agents/<registry_id>
  → 204
```

## Storage

| 選項 | Pros | Cons |
|---|---|---|
| etcd | 強一致、分散式 | 需多套基礎設施 |
| Postgres | 已有部署 | 寫入瓶頸 |
| Consul | service discovery 完整 | 學習成本 |

**初步偏好**: Postgres (與 ADR-0005 一致),寫入頻率低 (新 BU 加入時)。

## Unresolved questions

- [ ] Registry 高可用?單點? master-master?
- [ ] Agent 健康度 SLO?
- [ ] 跨 region 部署?(M 公司目前單 region)

## 預期實作

Phase 2 起。
