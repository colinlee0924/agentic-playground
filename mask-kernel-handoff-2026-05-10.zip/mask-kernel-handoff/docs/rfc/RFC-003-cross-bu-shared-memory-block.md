# RFC-003: 跨 BU Shared Memory Block 機制

- **作者**: Colin
- **狀態**: Draft
- **建立日期**: 2026-05-10
- **相關**: `docs/architecture/60-shared-state-strategy.md`

## Summary

借鑑 Letta 的 memory block 概念,在 mask-kernel 加入跨 BU 共享記憶塊,
讓 BU-A 寫入的內容,BU-B 在下次互動時可讀。

## Motivation

當前跨 BU 通訊只有 a2a-sdk send_message (request-response)。但某些情境
需要「持續共享狀態」:
- 一個 mask design spec 多個 BU 都會引用
- 一個 incident 多個 BU 同時調查
- 一個 customer ticket 跨 BU handoff 多次

每次都序列化整個 state 過於昂貴。

## 提案

新增 `shared_memory_blocks` Postgres table:

```sql
CREATE TABLE shared_memory_blocks (
  block_id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL,
  bu_ids TEXT[] NOT NULL,         -- 哪些 BU 可讀寫
  content JSONB NOT NULL,
  version INTEGER NOT NULL DEFAULT 1,  -- 樂觀鎖
  last_modified_by TEXT,
  last_modified_at TIMESTAMPTZ DEFAULT NOW()
);
```

API:

```python
# src/shared/memory_blocks.py
async def get_block(block_id) -> Block: ...
async def create_block(tenant_id, bu_ids, content) -> Block: ...
async def update_block(block_id, content, version) -> Block:  # 樂觀鎖
    ...
async def list_blocks(tenant_id, bu_id) -> list[Block]: ...
```

## 寫入衝突解決

樂觀鎖:呼叫 update 時必須帶當前 version,版本不符則 raise `ConflictError`,
caller 自行處理 (retry / merge)。

## 安全

- `bu_ids` 限制誰可讀寫
- 寫入觸發 ReflectorMiddleware (見 ADR-0004)
- 大寫入 (>10KB) 觸發 HITL approval

## Unresolved questions

- [ ] 是否需要 GC?保留多久?
- [ ] 是否需要 history 版本追溯 (像 git)?
- [ ] 跨 region 同步?

## 預期實作

Phase 2 後期評估,Phase 3 試點。
