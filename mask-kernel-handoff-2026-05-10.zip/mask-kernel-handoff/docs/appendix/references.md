# 引用清單

## 官方文件

- LangChain v1 Multi-Agent Guide: https://docs.langchain.com/oss/python/langchain/multi-agent/
- LangGraph 1.1.x Docs: https://langchain-ai.github.io/langgraph/
- a2a-sdk 1.0.2: https://github.com/a2aproject/a2a-python
- A2A Protocol v1.0.0 (Linux Foundation, 2026-03): https://a2a-protocol.org/
- Anthropic Memory v2.1.59: https://code.claude.com/docs/en/memory
- Anthropic Skills (skill-creator): https://code.claude.com/docs/en/skills
- MADR 4.0: https://adr.github.io/madr/
- GitHub spec-kit (SDD layout): https://github.com/github/spec-kit
- Open WebUI Docs: https://docs.openwebui.com/

## GitHub Issues 引用

- Open WebUI #23066, #23118 — `delta.tool_calls` 30-retry bug
- Open WebUI #20196 — AsyncGenerator hang
- LangGraph #6447 — async tool get_stream_writer race condition
- CrewAI #4783 — hierarchical manager 委派失敗
- a2a-sdk migrations: https://github.com/a2aproject/a2a-python/blob/main/docs/migrations/v1_0/README.md

## 借鑑的設計

- **Google ADK 三層 memory**: https://google.github.io/adk-docs/sessions/state/
- **Letta Shared Memory Block**: https://docs.letta.com/guides/agents/multi-agent-shared-memory
- **Microsoft Agent Framework Magentic**: https://learn.microsoft.com/en-us/agent-framework/workflows/orchestrations/magentic
- **Olejniczak A2A State Extension**: https://medium.com/google-cloud/using-a2a-extensions-for-injecting-session-state-into-adk-agents-exposed-as-a2a-servers-77b8ac05df1f

## Production 案例參考

- LinkedIn Hiring Assistant (LangGraph + supervisor): https://blog.langchain.com/customers-linkedin/
- Klarna AI Assistant: https://www.langchain.com/customers/klarna
- Uber QueryGPT: https://www.uber.com/blog/query-gpt/

## 棄用的參考

- Coding-Crashkurse A2A-LangGraph: https://github.com/Coding-Crashkurse/A2A-LangGraph
  (RouteDecision pattern,僅供歷史參考)

## 內部相關文件

- AIDE Gateway Internal Docs (M 公司內部 wiki)
- M 公司 Air-gap Compliance Policy
