# 過往討論精華摘要

## 一、技術選型結論

- **鎖版本**: LangChain 1.2.x / LangGraph 1.1.x / a2a-sdk 1.0.2
  (A2A v1.0.0,Linux Foundation 2026-03 釋出)
- **自架基礎設施**: Postgres / Redis / Langfuse (取代 Phoenix)
- **Gateway**: AIDE per-user JWT bearer token
- **環境**: air-gapped 內網,9000 user × 15 BU

## 二、架構共識

1. **Sub-agent-as-tool** (棄用 langgraph-supervisor / swarm)
2. **BU 內 Command + 跨 BU A2A** 雙層
3. **Supervisor pattern 三層**: TodoList 為主,寫操作疊 Reflector,
   巨型分析疊 Plan-Execute-Replan
4. **Open WebUI embeds iframe** 渲染 trajectory tree (避 multi-tab cross-talk)
5. **HITL 雙保險**: `__event_call__` + Postgres checkpoint + Redis
6. **Tool call streaming** 用 markdown `<details>`,絕不 emit `delta.tool_calls`
7. **Pipe 結尾必 `yield finish_reason: stop`**
8. **自訂 URI 已凍結**:
   - `urn:m-corp:masksdk:trajectory:v1`
   - `urn:m-corp:mask-kernel:handoff:v1`
9. **借鑑來源**: Google ADK 三層 memory + Letta shared block + MAF Magentic
   ledger + Olejniczak State Extension

## 三、已驗證反模式

- `langgraph-supervisor` (deprecated)
- `langgraph-swarm` (untested vs v1)
- `RouteDecision` (LLM + structured output + if/else)
- `delta.tool_calls` emit (issue #23066/#23118)
- async tool 內 `get_stream_writer` (issue #6447)
- Coding-Crashkurse RouteDecision pattern
- CrewAI hierarchical mode (issue #4783)

## 四、產出物盤點

- **Demo code**: 3 sub-agents (Jira/Wiki/Build) + supervisor + Pipe + relay + 2 iframe
- **Docker Compose** 完整檔案 (一鍵 `docker compose up`)
- **12 步端到端流程** (PROJ-123 + mask-design-spec 場景)
- **AG-UI 16 event 對應實作矩陣**
- **三前端能力差距矩陣** (Open WebUI / LibreChat / CopilotKit React)
- **Handoff 三模式對比矩陣**
- **三種 supervisor pattern 對比** (Todo / Reflector / Plan-Execute)
- **多代理生態全景對比** (LangGraph / OpenAI Agents / MAF / Google ADK /
  A2A native / CrewAI / AutoGen / Pydantic AI / Letta / Mastra)

## 五、外部對齊事項

- 自訂 trajectory URI 需向 Linux Foundation A2A WG 註冊 (RFC-001 Phase 2)
- A2UI v0.9 為 draft,Phase 4 風險點

## 六、四階段路線圖

| Phase | 月份 | 目標 |
|---|---|---|
| 1 | M0-M2 | 單 BU production hardening |
| 2 | M2-M5 | 第 2-3 BU 擴展 + Registry |
| 3 | M5-M9 | LibreChat + Assistant-UI |
| 4 | M9-M14 | AG-UI / CopilotKit + A2UI |

詳見 `docs/rfc/RFC-001-poc-to-production-roadmap.md`。
