# 文件索引與閱讀順序

## 第一階段:理解全貌 (約 1 小時)

1. `README.md` — 入口
2. `docs/appendix/conversation-summary.md` — 過往討論精華
3. `docs/architecture/00-overview.md` — 系統一頁總覽
4. `GLOSSARY.md` — 中英術語對照

## 第二階段:架構決策評審 (3-4 小時,團隊會議用)

5. `docs/architecture/10-tech-stack.md` ~ `90-anti-patterns.md` (依序閱讀)
6. `docs/decisions/0001` ~ `0008` (MADR 4.0,可逐案投票)
7. `docs/rfc/RFC-001` ~ `RFC-003` (尚在討論中)

## 第三階段:工程實作 (跟著 PoC 跑)

8. `specs/mask-kernel/architecture.md` — 英文 spec 定稿
9. `specs/001-poc-end-to-end/spec.md` → `plan.md` → `tasks.md`
10. `src/` 全部 (`docker compose up` 可跑)
11. `tasks/backlog.md` — Claude Code dispatch list

## 第四階段:長期維運

12. `docs/architecture/70-observability-strategy.md`
13. `docs/architecture/80-security-multi-tenant.md`
14. `tasks/migration-plan.md`

## 跨層引用地圖 (Cross-layer reference map)

```
ADR-0001 (sub-agent-as-tool)
  └─ docs/architecture/30-multi-agent-architecture.md
       └─ specs/mask-kernel/sub-agent-spec.md
            └─ .claude/skills/a2a-sub-agent/SKILL.md
                 └─ src/agents/jira_agent/agent.py

ADR-0007 (HITL dual-storage)
  └─ docs/architecture/50-streaming-architecture.md
       └─ specs/mask-kernel/api-contracts.md
            └─ .claude/skills/hitl-approval-flow/SKILL.md
                 └─ src/supervisor/handoff_tools.py
                 └─ src/artifacts/hitl_form.html

ADR-0008 (棄用 RouteDecision)
  └─ docs/architecture/90-anti-patterns.md
       └─ .claude/skills/avoiding-pitfalls/SKILL.md
            └─ CI grep gate (memory/constitution.md Article VII)
```

## 給 Claude Code 的最短路徑

```
CLAUDE.md → memory/constitution.md → .claude/skills/*
  → specs/001-poc-end-to-end/spec.md → plan.md → tasks.md
  → tasks/backlog.md (挑 P1)
  → 觸發對應 SKILL → 修改 src/ → docker compose up + pytest
```
