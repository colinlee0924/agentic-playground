"""Handoff tools for mask-kernel supervisor.

Sanity check 1: This module is the ONLY place where
                Command(graph=Command.PARENT) is allowed.
Sanity check 2: Cross-BU handoff MUST go through src.shared.a2a_extensions,
                not here.
Sanity check 3: Every handoff tool MUST emit a `trajectory.handoff` event
                BEFORE returning Command.

References:
    - docs/decisions/0001-sub-agent-as-tool.md
    - docs/decisions/0002-bu-internal-command-cross-bu-a2a.md
    - .claude/skills/handoff-tool/SKILL.md
"""
from __future__ import annotations

from typing import Annotated

from langchain_core.callbacks import adispatch_custom_event
from langchain_core.tools import tool
from langgraph.types import Command


def make_handoff_tool(target_agent: str, *, bu_id: str):
    """Factory: returns a Command-based handoff tool for a same-BU sub-agent.

    Sanity check: target_agent MUST exist as a node in the supervisor graph.
    """

    @tool(
        name=f"handoff_to_{target_agent}",
        description=f"Hand off control to {target_agent} within {bu_id}.",
    )
    async def _handoff(reason: Annotated[str, "Why this handoff happens"]) -> Command:
        # Emit BEFORE Command return; after return the event won't fire.
        await adispatch_custom_event(
            "trajectory.handoff",
            {"target": target_agent, "bu_id": bu_id, "reason": reason},
        )
        return Command(goto=target_agent, graph=Command.PARENT)

    return _handoff


@tool
async def request_human_approval(
    action: Annotated[str, "Description of the action requiring approval"],
    payload: Annotated[dict, "Action payload"],
) -> dict:
    """Pause execution for human approval. Used by ReflectorMiddleware.

    NOTE: actual interrupt happens via langgraph.types.interrupt() inside
    the calling node, not here. This tool returns the approval spec.
    """
    return {"requires_approval": True, "action": action, "payload": payload}
