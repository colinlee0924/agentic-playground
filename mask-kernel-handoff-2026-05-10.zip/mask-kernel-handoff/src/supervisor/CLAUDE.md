# Supervisor module — Claude Code memory

This module owns the LangGraph compiled graph. It is the **only** place where
`Command(goto=..., graph=Command.PARENT)` is permitted.

## Files

- `graph.py` — entry point; builds `StateGraph` and compiles with `AsyncPostgresSaver`.
- `middleware.py` — TodoListMiddleware + Reflector + Plan-Execute-Replan.
- `handoff_tools.py` — Command-based handoff tools to same-BU sub-agents.
- `app.py` — FastAPI exposing `/v1/chat/completions` for Open WebUI Pipe.

## Rules

1. Sub-agent invocation: **tool call only**. Never instantiate a sub-agent's
   compiled graph directly from supervisor.
2. Cross-BU handoff: emit a2a-sdk message; do not import another BU's agent module.
3. Every node MUST emit `trajectory.node.start` and `trajectory.node.end`.

## Related skills

- `.claude/skills/handoff-tool/SKILL.md`
- `.claude/skills/avoiding-pitfalls/SKILL.md`
