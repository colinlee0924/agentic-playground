"""Supervisor LangGraph builder.

Sanity check: this is the ONLY place that compiles the top-level supervisor.
Sub-agent compiled graphs live in their own modules and are wired via
handoff tools, not direct imports of compiled graphs.

References:
    - specs/mask-kernel/supervisor-spec.md
"""
from __future__ import annotations

import os
from typing import Any, TypedDict

from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.graph import StateGraph

from src.supervisor.handoff_tools import make_handoff_tool, request_human_approval
from src.supervisor.middleware import (
    PlanExecuteReplanMiddleware,
    ReflectorMiddleware,
    TodoListMiddleware,
)


class SupervisorState(TypedDict, total=False):
    messages: list[Any]
    todos: list[dict]
    tenant_id: str
    bu_id: str
    trace_id: str
    handoff_history: list[dict]
    pending_approvals: list[dict]
    mode: str


async def build_supervisor():
    """Build and compile the supervisor graph.

    Returns the compiled graph. Caller is responsible for invoking
    `await checkpointer.setup()` if running first time.
    """
    handoff_to_jira = make_handoff_tool("jira_agent", bu_id="BU-A")
    handoff_to_wiki = make_handoff_tool("wiki_agent", bu_id="BU-A")
    handoff_to_build = make_handoff_tool("build_agent", bu_id="BU-A")

    # Wire middleware (TodoList always on, others conditional)
    middleware = [
        TodoListMiddleware(),
        ReflectorMiddleware(
            triggers=["handoff_to_jira", "handoff_to_wiki"],
        ),
        PlanExecuteReplanMiddleware(min_steps_to_trigger=5),
    ]

    builder = StateGraph(SupervisorState)
    # In real impl: add_node, add_edge, etc. This skeleton is illustrative.

    db_url = os.environ["DATABASE_URL"]
    checkpointer = AsyncPostgresSaver.from_conn_string(db_url)
    graph = builder.compile(checkpointer=checkpointer)

    # Attach middleware (mock attachment; real impl varies by LangChain version)
    graph._middleware = middleware
    graph._tools = [handoff_to_jira, handoff_to_wiki, handoff_to_build, request_human_approval]
    return graph
