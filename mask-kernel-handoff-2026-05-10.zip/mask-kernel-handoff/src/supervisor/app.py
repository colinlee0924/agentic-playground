"""FastAPI app exposing /v1/chat/completions for Open WebUI Pipe.

Sanity check: this endpoint MUST emit OpenAI-compatible streaming chunks.
Sanity check: the final chunk MUST have finish_reason: "stop".
"""
from __future__ import annotations

import json
from typing import AsyncIterator

from fastapi import FastAPI, Request
from sse_starlette.sse import EventSourceResponse

from src.supervisor.graph import build_supervisor

app = FastAPI(title="mask-kernel supervisor")
_graph = None


@app.on_event("startup")
async def _startup() -> None:
    global _graph
    _graph = await build_supervisor()


async def _stream(req_body: dict) -> AsyncIterator[str]:
    # Skeleton: in real impl, call _graph.astream_events(version="v2")
    # and translate to OpenAI chunks.
    yield json.dumps({"choices": [{"delta": {"role": "assistant"}}]})
    yield json.dumps({"choices": [{"delta": {"content": "Skeleton response"}}]})
    # MANDATORY final chunk
    yield json.dumps({"choices": [{"delta": {}, "finish_reason": "stop"}]})


@app.post("/v1/chat/completions")
async def chat_completions(req: Request):
    body = await req.json()
    return EventSourceResponse(_stream(body))


@app.get("/.well-known/agent.json")
async def agent_card():
    # Stub. Real impl loads signed AgentCard from src/agents/<name>/agent_card.json
    return {"name": "mask-kernel-supervisor", "version": "0.1.0"}
