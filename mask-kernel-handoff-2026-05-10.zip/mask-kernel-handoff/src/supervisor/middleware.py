"""Supervisor middleware: TodoList + Reflector + Plan-Execute-Replan.

Sanity check: TodoListMiddleware is ALWAYS on. The other two are conditional.
References:
    - docs/architecture/40-supervisor-patterns.md
    - docs/decisions/0004-todolist-middleware-supervisor.md
"""
from __future__ import annotations

from typing import Any

from langchain_core.callbacks import adispatch_custom_event


class TodoListMiddleware:
    """Manages state.todos for multi-step tasks.

    Mock implementation. Real version uses LangChain v1's middleware API.
    """

    async def before_model(self, state: dict[str, Any]) -> dict[str, Any]:
        if "todos" not in state:
            state["todos"] = []
        return state


class ReflectorMiddleware:
    """Pauses before write operations and routes through HITL approval.

    Args:
        triggers: tool names that trigger reflection
        reflection_llm: optional dedicated reflection model
    """

    def __init__(self, triggers: list[str], reflection_llm: Any = None) -> None:
        self.triggers = set(triggers)
        self.reflection_llm = reflection_llm

    async def before_tool(self, tool_name: str, args: dict) -> dict:
        if tool_name not in self.triggers:
            return args
        await adispatch_custom_event(
            "supervisor.reflection",
            {"tool": tool_name, "args": args},
        )
        # In real implementation, may call interrupt() here.
        return args


class PlanExecuteReplanMiddleware:
    """Enables Plan-Execute-Replan loop when todo count exceeds threshold."""

    def __init__(self, min_steps_to_trigger: int = 5) -> None:
        self.min_steps_to_trigger = min_steps_to_trigger

    async def before_model(self, state: dict[str, Any]) -> dict[str, Any]:
        if len(state.get("todos", [])) >= self.min_steps_to_trigger:
            state["mode"] = "plan-execute-replan"
        return state
