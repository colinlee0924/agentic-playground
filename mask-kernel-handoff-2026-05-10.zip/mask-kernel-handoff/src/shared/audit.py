"""CI grep gate runner.

Sanity check: this script's checks must match docs/architecture/90-anti-patterns.md.
"""
from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

CHECKS = [
    ("langgraph-supervisor import", r"from langgraph_supervisor", "src/"),
    ("langgraph-swarm import", r"from langgraph_swarm", "src/"),
    ("delta.tool_calls in pipe", r"delta\.tool_calls", "src/pipe/"),
    ("get_stream_writer in async", r"get_stream_writer\(.*async", "src/"),
    ("RouteDecision class", r"class RouteDecision\b", "src/"),
    ("hardcoded AIDE URL", r"https?://aide\.", "src/"),
]


def run() -> int:
    failures = []
    for name, pattern, path in CHECKS:
        try:
            result = subprocess.run(
                ["grep", "-rE", pattern, path],
                capture_output=True,
                text=True,
            )
            if result.stdout.strip():
                # Allow noqa override
                lines = [l for l in result.stdout.splitlines() if "noqa: pitfall" not in l]
                if lines:
                    failures.append((name, lines))
        except FileNotFoundError:
            pass
    if failures:
        for name, lines in failures:
            print(f"❌ {name}:")
            for line in lines:
                print(f"  {line}")
        return 1
    print("✅ All anti-pattern checks passed")
    return 0


if __name__ == "__main__":
    sys.exit(run())
