"""Ed25519 signer for AgentCard.

Sanity check: every agent_card.json in src/agents/* MUST be signed before
serving on /.well-known/agent.json.
"""
from __future__ import annotations

import json
from pathlib import Path

import nacl.signing


def sign_card(card: dict, key_path: str | Path) -> dict:
    """Sign canonical JSON of card. Returns card with `signature` field."""
    key = nacl.signing.SigningKey(Path(key_path).read_bytes())
    body = {k: v for k, v in card.items() if k != "signature"}
    canonical = json.dumps(body, sort_keys=True, separators=(",", ":"))
    sig = key.sign(canonical.encode()).signature.hex()
    return {**body, "signature": sig}


def verify_card(card: dict, public_key_path: str | Path) -> bool:
    """Verify Ed25519 signature on AgentCard."""
    sig = bytes.fromhex(card["signature"])
    body = {k: v for k, v in card.items() if k != "signature"}
    canonical = json.dumps(body, sort_keys=True, separators=(",", ":"))
    verify_key = nacl.signing.VerifyKey(Path(public_key_path).read_bytes())
    try:
        verify_key.verify(canonical.encode(), sig)
        return True
    except nacl.exceptions.BadSignatureError:
        return False
