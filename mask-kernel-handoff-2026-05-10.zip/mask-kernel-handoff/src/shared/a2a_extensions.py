"""A2A custom extension helpers.

Frozen URIs (constitution Article VI):
    - urn:m-corp:masksdk:trajectory:v1
    - urn:m-corp:mask-kernel:handoff:v1
"""
from __future__ import annotations

from typing import Any

TRAJECTORY_URI = "urn:m-corp:masksdk:trajectory:v1"
HANDOFF_URI = "urn:m-corp:mask-kernel:handoff:v1"


def build_trajectory_metadata(
    trace_id: str,
    parent_span_id: str | None,
    events: list[dict[str, Any]],
) -> dict[str, Any]:
    return {
        TRAJECTORY_URI: {
            "trace_id": trace_id,
            "parent_span_id": parent_span_id,
            "events": events,
        }
    }


def build_handoff_metadata(
    from_agent: str,
    to_agent: str,
    intent: str,
    task: dict[str, Any],
    return_path: dict[str, Any] | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "from_agent": from_agent,
        "to_agent": to_agent,
        "intent": intent,
        "task": task,
    }
    if return_path:
        payload["return_path"] = return_path
    return {HANDOFF_URI: payload}
