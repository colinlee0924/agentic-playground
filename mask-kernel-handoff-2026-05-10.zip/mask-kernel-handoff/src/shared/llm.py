"""LLM client wrapper that always goes through AIDE Gateway.

Sanity check: NEVER hardcode the AIDE URL; read from env.
Sanity check: every call carries a per-user JWT bearer.
"""
from __future__ import annotations

import os

import httpx


async def call_aide_chat(
    messages: list[dict],
    *,
    jwt: str,
    model: str = "default",
    timeout: float = 30.0,
) -> dict:
    """Call AIDE Gateway chat completion endpoint."""
    base = os.environ["AIDE_GATEWAY_URL"]
    async with httpx.AsyncClient(base_url=base, timeout=timeout) as client:
        r = await client.post(
            "/v1/chat/completions",
            headers={"Authorization": f"Bearer {jwt}"},
            json={"model": model, "messages": messages},
        )
        r.raise_for_status()
        return r.json()
