"""Langfuse + OpenTelemetry hooks.

Sanity check: every cross-BU call MUST propagate trace_id.
"""
from __future__ import annotations

import os

try:
    from langfuse import Langfuse
    _client: Langfuse | None = Langfuse(
        public_key=os.environ.get("LANGFUSE_PUBLIC_KEY", ""),
        secret_key=os.environ.get("LANGFUSE_SECRET_KEY", ""),
        host=os.environ.get("LANGFUSE_HOST", ""),
    ) if os.environ.get("LANGFUSE_PUBLIC_KEY") else None
except ImportError:
    _client = None


def get_langfuse():
    return _client
