"""AsyncPostgresSaver wrapper with retry-on-disconnect.

Sanity check: every supervisor compile MUST use this wrapper, not raw
AsyncPostgresSaver, to ensure HITL durability across reconnects.
"""
from __future__ import annotations

import os

from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver


def get_checkpointer() -> AsyncPostgresSaver:
    """Return shared AsyncPostgresSaver instance.

    In real impl: wrap with retry decorator + connection pool.
    """
    return AsyncPostgresSaver.from_conn_string(os.environ["DATABASE_URL"])
