"""Shared utilities (checkpointer, observability, signing)."""
