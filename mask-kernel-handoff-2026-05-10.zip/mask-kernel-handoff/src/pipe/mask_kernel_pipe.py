"""Open WebUI Pipe Function for mask-kernel.

Sanity check: this Pipe MUST yield finish_reason: stop at the end.
Sanity check: this Pipe MUST NOT emit delta.tool_calls.
Sanity check: HITL flows go through __event_call__ AND Redis queue.

References:
    - specs/mask-kernel/pipe-spec.md
    - .claude/skills/pipe-event-translation/SKILL.md
    - .claude/skills/hitl-approval-flow/SKILL.md
"""
from __future__ import annotations

import os
from typing import Any, AsyncGenerator, Callable

import httpx
from pydantic import BaseModel

from src.pipe.event_translator import (
    make_final_chunk,
    make_token_chunk,
    render_handoff,
    render_tool_call_close,
    render_tool_call_open,
)


class Pipe:
    class Valves(BaseModel):
        SUPERVISOR_URL: str = os.environ.get(
            "SUPERVISOR_URL", "http://mask-kernel-supervisor:8000"
        )

    def __init__(self) -> None:
        self.valves = self.Valves()

    async def pipe(
        self,
        body: dict,
        __user__: dict,
        __event_emitter__: Callable[..., Any],
        __event_call__: Callable[..., Any],
    ) -> AsyncGenerator[dict, None]:
        """Main Pipe entry point.

        Skeleton: in real impl, opens SSE to supervisor, translates events.
        """
        # 1. Initial role announcement
        yield {"choices": [{"delta": {"role": "assistant"}}]}

        # 2. Stream from supervisor (skeleton; real impl uses httpx SSE client)
        async with httpx.AsyncClient(
            base_url=self.valves.SUPERVISOR_URL, timeout=120.0
        ) as client:
            try:
                async with client.stream(
                    "POST", "/v1/chat/completions", json=body
                ) as resp:
                    async for line in resp.aiter_lines():
                        if not line or not line.startswith("data:"):
                            continue
                        # In real impl: parse JSON, translate, yield chunks
                        yield make_token_chunk(line[5:].strip())
            except Exception as e:
                yield make_token_chunk(f"\n[error: {e}]\n")

        # 3. MANDATORY final chunk
        yield make_final_chunk()
