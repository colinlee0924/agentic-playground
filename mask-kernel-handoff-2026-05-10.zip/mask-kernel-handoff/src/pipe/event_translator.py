"""Translate LangGraph / AG-UI events to Open WebUI markdown chunks.

Sanity check: every tool call MUST render as <details type="tool_calls">.
Sanity check: NEVER produce a chunk with delta.tool_calls (30-retry bug).

References:
    - .claude/skills/pipe-event-translation/SKILL.md
    - docs/architecture/50-streaming-architecture.md
"""
from __future__ import annotations

import json
from typing import Any


def render_tool_call_open(tool_name: str, args: dict[str, Any]) -> str:
    """Render the opening of a tool call as collapsible markdown."""
    args_json = json.dumps(args, ensure_ascii=False)
    return (
        f'\n<details type="tool_calls" '
        f'data-tool="{tool_name}" data-status="running">\n'
        f"<summary>🔧 {tool_name}</summary>\n\n"
        f"```json\n{args_json}\n```\n"
    )


def render_tool_call_close(tool_name: str, result: Any) -> str:
    """Render the closing of a tool call with result."""
    result_json = json.dumps(result, ensure_ascii=False, default=str)
    return f"\n```json\n{result_json}\n```\n</details>\n"


def render_handoff(from_node: str, to_node: str, reason: str) -> str:
    """Render a handoff edge as a status line (also pushed to iframe)."""
    return f"\n> ↪ Handoff: **{from_node}** → **{to_node}** ({reason})\n"


def make_token_chunk(content: str) -> dict:
    """Build a streaming chunk for plain token content."""
    return {"choices": [{"delta": {"content": content}}]}


def make_final_chunk() -> dict:
    """Build the MANDATORY final chunk (finish_reason=stop).

    Sanity check: this is the only correct way to end a Pipe response.
    """
    return {"choices": [{"delta": {}, "finish_reason": "stop"}]}
