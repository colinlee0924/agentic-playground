# pipe module — Claude Code memory

This module contains the Open WebUI Pipe Function. The two file-scoped rules
in `.claude/rules/streaming-rules.md` apply automatically here.

## Critical reminders (also in streaming-rules.md)

1. NEVER emit `delta.tool_calls` chunks (Open WebUI #23066/#23118 30-retry bug)
2. ALWAYS terminate with `yield {"choices":[{"delta":{},"finish_reason":"stop"}]}`
3. NEVER call `get_stream_writer()` inside async — use `adispatch_custom_event`
4. Tool calls render as `<details type="tool_calls">` markdown blocks

See `.claude/skills/pipe-event-translation/SKILL.md`.
