"""Open WebUI Pipe Function module."""
