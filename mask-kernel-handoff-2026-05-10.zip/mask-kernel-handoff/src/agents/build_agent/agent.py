"""Build sub-agent definition."""
from __future__ import annotations

from langchain_core.callbacks import adispatch_custom_event

from src.agents.build_agent.tools import get_build_status, list_recent_builds

AGENT_NAME = "build_agent"
BU_ID = "BU-A"


async def build_agent_node(state: dict) -> dict:
    await adispatch_custom_event(
        "trajectory.node.start",
        {"node": AGENT_NAME, "bu_id": BU_ID},
    )
    result = {"messages": state.get("messages", []) + ["[build_agent placeholder]"]}
    await adispatch_custom_event(
        "trajectory.node.end",
        {"node": AGENT_NAME, "bu_id": BU_ID},
    )
    return result


AGENT_TOOLS = [get_build_status, list_recent_builds]
