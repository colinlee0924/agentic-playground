# build_agent — Claude Code memory

Sub-agent that queries CI/CD pipeline status.
See `src/agents/jira_agent/CLAUDE.md` for general rules.
