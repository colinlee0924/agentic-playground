"""Tools for the Build sub-agent."""
from __future__ import annotations

import os
from typing import Annotated

import httpx
from langchain_core.tools import tool


@tool
async def get_build_status(
    pipeline_id: Annotated[str, "CI pipeline identifier"],
) -> dict:
    """Get CI pipeline status by id."""
    async with httpx.AsyncClient(
        base_url=os.environ["AIDE_GATEWAY_URL"], timeout=30.0
    ) as client:
        r = await client.get(f"/ci/pipeline/{pipeline_id}")
        r.raise_for_status()
        return r.json()


@tool
async def list_recent_builds(
    project: Annotated[str, "Project key, e.g. PROJ"],
    limit: Annotated[int, "Max results"] = 10,
) -> list[dict]:
    """List recent CI builds for a project."""
    async with httpx.AsyncClient(
        base_url=os.environ["AIDE_GATEWAY_URL"], timeout=30.0
    ) as client:
        r = await client.get("/ci/builds", params={"project": project, "limit": limit})
        r.raise_for_status()
        return r.json()
