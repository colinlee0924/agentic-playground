"""Wiki sub-agent."""
