"""Wiki sub-agent definition."""
from __future__ import annotations

from langchain_core.callbacks import adispatch_custom_event

from src.agents.wiki_agent.tools import get_wiki_page, search_wiki

AGENT_NAME = "wiki_agent"
BU_ID = "BU-A"


async def wiki_agent_node(state: dict) -> dict:
    await adispatch_custom_event(
        "trajectory.node.start",
        {"node": AGENT_NAME, "bu_id": BU_ID},
    )
    result = {"messages": state.get("messages", []) + ["[wiki_agent placeholder]"]}
    await adispatch_custom_event(
        "trajectory.node.end",
        {"node": AGENT_NAME, "bu_id": BU_ID},
    )
    return result


AGENT_TOOLS = [search_wiki, get_wiki_page]
