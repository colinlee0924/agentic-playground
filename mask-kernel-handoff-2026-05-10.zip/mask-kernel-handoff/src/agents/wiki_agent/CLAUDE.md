# wiki_agent — Claude Code memory

Sub-agent that queries internal Wiki / Confluence.
See `src/agents/jira_agent/CLAUDE.md` for general rules; same patterns apply.
