"""Tools for the Wiki sub-agent."""
from __future__ import annotations

import os
from typing import Annotated

import httpx
from langchain_core.tools import tool


@tool
async def search_wiki(
    query: Annotated[str, "Search query, full text"],
) -> list[dict]:
    """Search internal wiki / confluence."""
    async with httpx.AsyncClient(
        base_url=os.environ["AIDE_GATEWAY_URL"], timeout=30.0
    ) as client:
        r = await client.get("/wiki/search", params={"q": query})
        r.raise_for_status()
        return r.json()


@tool
async def get_wiki_page(
    page_id: Annotated[str, "Wiki page id"],
) -> dict:
    """Get a wiki page by id."""
    async with httpx.AsyncClient(
        base_url=os.environ["AIDE_GATEWAY_URL"], timeout=30.0
    ) as client:
        r = await client.get(f"/wiki/page/{page_id}")
        r.raise_for_status()
        return r.json()
