"""Tools for the Jira sub-agent.

Sanity check: every tool is async; uses httpx; raises on auth failure.
Sanity check: never use `requests` (sync, blocks event loop).
"""
from __future__ import annotations

import os
from typing import Annotated

import httpx
from langchain_core.tools import tool


def _aide_client() -> httpx.AsyncClient:
    base = os.environ["AIDE_GATEWAY_URL"]
    # JWT injected per-request via runnable config; here we create base client.
    return httpx.AsyncClient(base_url=base, timeout=30.0)


@tool
async def search_jira(
    jql: Annotated[str, "JIRA Query Language string"],
    max_results: Annotated[int, "Max results, default 50"] = 50,
) -> dict:
    """Search Jira issues using JQL."""
    async with _aide_client() as client:
        r = await client.get("/jira/search", params={"jql": jql, "max": max_results})
        r.raise_for_status()
        return r.json()


@tool
async def get_jira_issue(
    issue_key: Annotated[str, "Issue key like PROJ-123"],
) -> dict:
    """Get a single Jira issue by key."""
    async with _aide_client() as client:
        r = await client.get(f"/jira/issue/{issue_key}")
        r.raise_for_status()
        return r.json()


@tool
async def add_jira_comment(
    issue_key: Annotated[str, "Issue key"],
    body: Annotated[str, "Comment body in markdown"],
) -> dict:
    """Add a comment to a Jira issue. WRITE OP — triggers Reflector + HITL."""
    async with _aide_client() as client:
        r = await client.post(
            f"/jira/issue/{issue_key}/comment",
            json={"body": body},
        )
        r.raise_for_status()
        return r.json()
