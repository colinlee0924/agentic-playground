"""Jira sub-agent definition.

Sanity check: agent emits trajectory events on every node entry/exit.
Sanity check: agent name is registered as a node in supervisor graph.
"""
from __future__ import annotations

from langchain_core.callbacks import adispatch_custom_event

from src.agents.jira_agent.tools import add_jira_comment, get_jira_issue, search_jira

AGENT_NAME = "jira_agent"
BU_ID = "BU-A"


async def jira_agent_node(state: dict) -> dict:
    """LangGraph node entry for jira_agent.

    Emits trajectory.node.start before work, trajectory.node.end on exit.
    """
    await adispatch_custom_event(
        "trajectory.node.start",
        {"node": AGENT_NAME, "bu_id": BU_ID, "input": state.get("messages", [])[-1:]},
    )

    # In real impl: invoke create_agent compiled graph here.
    # Skeleton: just return state with a placeholder message.
    result = {"messages": state.get("messages", []) + ["[jira_agent placeholder response]"]}

    await adispatch_custom_event(
        "trajectory.node.end",
        {"node": AGENT_NAME, "bu_id": BU_ID, "output_summary": "..."},
    )
    return result


# Tool registry for use by supervisor
AGENT_TOOLS = [search_jira, get_jira_issue, add_jira_comment]
