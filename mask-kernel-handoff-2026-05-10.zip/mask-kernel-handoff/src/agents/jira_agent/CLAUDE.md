# jira_agent — Claude Code memory

Sub-agent that queries and (with HITL approval) mutates JIRA via REST.

## Files

- `agent.py` — LangGraph node compiled with `create_agent` + tools
- `tools.py` — async tool functions calling JIRA REST through AIDE Gateway
- `agent_card.json` — Ed25519-signed A2A AgentCard

## Rules specific to this agent

- All HTTP via `httpx.AsyncClient`, never `requests`
- All JIRA mutations (`add_comment`, `update_status`) MUST go through
  Reflector + HITL approval
- Auth via AIDE Gateway JWT bearer (env: `AIDE_GATEWAY_URL`)

See `.claude/skills/a2a-sub-agent/SKILL.md` for adding new tools.
