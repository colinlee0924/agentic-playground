# mask-kernel src/ — runnable PoC

## Quickstart

```bash
cp .env.example .env       # 填 AIDE Gateway URL 等
docker compose up -d
# 開 http://localhost:3000 (Open WebUI), 選 mask-kernel pipe
```

## Layout

- `agents/` — sub-agents (jira / wiki / build)
- `supervisor/` — LangGraph supervisor + middleware + handoff tools
- `pipe/` — Open WebUI Pipe Function + event translator
- `trajectory_relay/` — Redis pub/sub relay for iframe SSE
- `shared/` — checkpointer, observability, signing utilities
- `artifacts/` — iframe HTML (trajectory_tree, hitl_form)
- `tests/` — unit / contract / e2e

## Run a single agent locally

```bash
python -m src.agents.jira_agent.agent
```

## Run E2E test

```bash
pytest tests/e2e/test_proj123_scenario.py -v
```
