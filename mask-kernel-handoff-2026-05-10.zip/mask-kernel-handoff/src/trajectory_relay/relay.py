"""Trajectory relay implementation.

Sanity check: every event MUST have tenant_id, bu_id, thread_id, trace_id.
Sanity check: channel name pattern: trajectory:<tenant>:<bu>:<thread>
"""
from __future__ import annotations

import json
import os
from typing import Any

import redis.asyncio as redis


_redis: redis.Redis | None = None


async def get_redis() -> redis.Redis:
    global _redis
    if _redis is None:
        _redis = redis.from_url(os.environ["REDIS_URL"], decode_responses=True)
    return _redis


def channel_name(tenant_id: str, bu_id: str, thread_id: str) -> str:
    """Compute Redis pub/sub channel for a (tenant, bu, thread) tuple."""
    return f"trajectory:{tenant_id}:{bu_id}:{thread_id}"


async def publish_event(
    tenant_id: str,
    bu_id: str,
    thread_id: str,
    event: dict[str, Any],
) -> int:
    """Publish a trajectory event to the per-thread channel.

    Returns number of subscribers reached (0 means no iframe is open;
    that's fine, events are best-effort for live UI).
    """
    r = await get_redis()
    return await r.publish(
        channel_name(tenant_id, bu_id, thread_id),
        json.dumps(event, default=str),
    )
