"""FastAPI SSE endpoint for trajectory iframe.

Sanity check: each SSE connection subscribes to ONE thread's channel.
"""
from __future__ import annotations

import asyncio
import os
from typing import AsyncIterator

from fastapi import FastAPI, Header, HTTPException
from sse_starlette.sse import EventSourceResponse

from src.trajectory_relay.relay import channel_name, get_redis

app = FastAPI(title="mask-kernel trajectory relay")


@app.get("/trajectory/{thread_id}/stream")
async def stream_trajectory(
    thread_id: str,
    x_tenant_id: str | None = Header(default=None),
    x_bu_id: str | None = Header(default=None),
):
    """SSE endpoint consumed by trajectory_tree.html iframe."""
    if not x_tenant_id or not x_bu_id:
        raise HTTPException(400, "Missing tenant/bu headers")

    chan = channel_name(x_tenant_id, x_bu_id, thread_id)

    async def gen() -> AsyncIterator[dict]:
        r = await get_redis()
        pubsub = r.pubsub()
        await pubsub.subscribe(chan)
        try:
            async for msg in pubsub.listen():
                if msg.get("type") != "message":
                    continue
                yield {"data": msg["data"], "event": "trajectory"}
        finally:
            await pubsub.unsubscribe(chan)
            await pubsub.aclose()

    return EventSourceResponse(gen())


@app.get("/healthz")
async def healthz():
    return {"ok": True}
