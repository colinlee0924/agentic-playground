"""Trajectory relay: Redis pub/sub bridge between supervisor and iframe."""
