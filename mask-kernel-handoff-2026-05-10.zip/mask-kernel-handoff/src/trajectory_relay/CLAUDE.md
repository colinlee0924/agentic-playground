# trajectory_relay — Claude Code memory

Bridges LangGraph custom events to Redis pub/sub channels consumed by the
trajectory_tree.html iframe via SSE.

## Channel naming (CRITICAL for multi-tab isolation)

```
trajectory:<tenant_id>:<bu_id>:<thread_id>
```

Each iframe instance subscribes to ONE channel. This is the only mechanism
preventing multi-tab cross-talk in Open WebUI.

See `.claude/skills/trajectory-iframe/SKILL.md`.
