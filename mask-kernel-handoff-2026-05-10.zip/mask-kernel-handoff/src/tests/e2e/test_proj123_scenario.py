"""E2E test: PROJ-123 + mask-design-spec scenario (12-step).

Sanity check: this test requires `docker compose up -d` to have run.
"""
from __future__ import annotations

import pytest


@pytest.mark.asyncio
@pytest.mark.skip(reason="Skeleton — implement T13 in tasks.md")
async def test_proj123_scenario() -> None:
    # Steps 1-12: see specs/001-poc-end-to-end/spec.md
    pass
