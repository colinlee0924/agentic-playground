"""Contract test for sub-agent conformance to sub-agent-spec.md."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

AGENT_DIRS = list(Path("src/agents").glob("*_agent"))


@pytest.mark.parametrize("agent_dir", AGENT_DIRS, ids=lambda p: p.name)
def test_agent_card_has_required_fields(agent_dir: Path) -> None:
    card = json.loads((agent_dir / "agent_card.json").read_text())
    for field in ("name", "version", "bu_id", "extensions", "auth", "signature"):
        assert field in card, f"missing field: {field}"


@pytest.mark.parametrize("agent_dir", AGENT_DIRS, ids=lambda p: p.name)
def test_agent_card_has_frozen_uris(agent_dir: Path) -> None:
    card = json.loads((agent_dir / "agent_card.json").read_text())
    assert "urn:m-corp:masksdk:trajectory:v1" in card["extensions"]
    assert "urn:m-corp:mask-kernel:handoff:v1" in card["extensions"]
