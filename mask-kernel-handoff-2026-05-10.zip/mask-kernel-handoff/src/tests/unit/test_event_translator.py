"""Unit tests for event_translator.py — verify NO delta.tool_calls."""
from __future__ import annotations

from src.pipe.event_translator import (
    make_final_chunk,
    make_token_chunk,
    render_tool_call_close,
    render_tool_call_open,
)


def test_final_chunk_has_finish_reason_stop() -> None:
    chunk = make_final_chunk()
    assert chunk["choices"][0]["finish_reason"] == "stop"


def test_token_chunk_no_tool_calls_field() -> None:
    chunk = make_token_chunk("hello")
    assert "tool_calls" not in chunk["choices"][0]["delta"]


def test_tool_call_renders_as_details() -> None:
    md = render_tool_call_open("search_jira", {"jql": "PROJ"})
    assert '<details type="tool_calls"' in md
    assert "delta.tool_calls" not in md


def test_tool_call_close_includes_result() -> None:
    md = render_tool_call_close("search_jira", {"hits": 3})
    assert "</details>" in md
