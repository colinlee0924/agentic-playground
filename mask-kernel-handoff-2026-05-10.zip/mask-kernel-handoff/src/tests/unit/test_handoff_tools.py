"""Unit tests for handoff_tools.py."""
from __future__ import annotations

import pytest

from src.supervisor.handoff_tools import make_handoff_tool


def test_make_handoff_tool_naming() -> None:
    tool = make_handoff_tool("jira_agent", bu_id="BU-A")
    assert tool.name == "handoff_to_jira_agent"


def test_make_handoff_tool_description_mentions_bu() -> None:
    tool = make_handoff_tool("jira_agent", bu_id="BU-A")
    assert "BU-A" in tool.description
