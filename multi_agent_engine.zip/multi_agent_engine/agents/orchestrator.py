"""
agents/orchestrator.py - Orchestrator Agent
使用 LangGraph + PostgreSQL Checkpointer 實現的主要協調者

職責：
1. 理解使用者請求
2. 決定路由到哪個 Worker Agent
3. 彙整結果回覆使用者
4. 發送狀態更新到 SSE 串流
5. 維護多輪對話歷史 (PostgreSQL Checkpointer)
"""
from typing import AsyncGenerator, Dict, Any, List, Literal, Optional
from dataclasses import dataclass
from contextlib import asynccontextmanager
import asyncio
import logging

from langchain_core.messages import HumanMessage, AIMessage, SystemMessage, BaseMessage
from langgraph.graph import StateGraph, MessagesState, START, END
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver

from agents.jira_agent import JiraAgent
from config import settings

logger = logging.getLogger(__name__)

# Orchestrator 的系統提示詞
ORCHESTRATOR_SYSTEM_PROMPT = """你是 M公司 的 AI 助手協調者（Orchestrator）。

你的職責是：
1. 理解使用者的請求
2. 判斷需要哪個專業 Agent 來處理
3. 將任務委派給適當的 Agent
4. 彙整結果，用清晰的中文回覆使用者

可用的專業 Agents：
- **Jira Agent**: 處理 Jira 相關任務，包括：
  - 查詢 tickets（搜尋、篩選、取得詳情）
  - 建立新 ticket
  - 更新 ticket 狀態
  - 查詢專案資訊

- **FAQ Agent**: 回答公司內部常見問題（開發中）

路由規則：
- 如果使用者詢問 Jira、ticket、issue、bug、任務、專案進度相關 → 使用 Jira Agent
- 如果使用者詢問公司政策、流程、常見問題 → 使用 FAQ Agent（目前不可用，請告知使用者）
- 如果不確定或是一般對話 → 直接回覆

回覆風格：
- 使用繁體中文
- 簡潔但完整
- 如果有 ticket 資訊，請用結構化方式呈現
"""


class OrchestratorAgent:
    """
    Orchestrator Agent - 主要協調者
    
    使用 PostgreSQL Checkpointer 維護對話狀態，支援多輪對話
    """
    
    def __init__(self):
        self.jira_agent = JiraAgent()
        self.llm = self._create_llm()
        self._checkpointer: Optional[AsyncPostgresSaver] = None
        self._graph = None
        logger.info("Orchestrator Agent 初始化完成")
    
    def _create_llm(self):
        """根據配置建立 LLM 實例"""
        if settings.LLM_PROVIDER == "openai":
            from langchain_openai import ChatOpenAI
            return ChatOpenAI(
                model=settings.OPENAI_MODEL,
                api_key=settings.OPENAI_API_KEY,
                streaming=True
            )
        elif settings.LLM_PROVIDER == "azure":
            from langchain_openai import AzureChatOpenAI
            return AzureChatOpenAI(
                azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
                api_key=settings.AZURE_OPENAI_API_KEY,
                deployment_name=settings.AZURE_OPENAI_DEPLOYMENT,
                streaming=True
            )
        elif settings.LLM_PROVIDER == "ollama":
            from langchain_ollama import ChatOllama
            return ChatOllama(
                base_url=settings.OLLAMA_BASE_URL,
                model=settings.OLLAMA_MODEL
            )
        else:
            raise ValueError(f"不支援的 LLM Provider: {settings.LLM_PROVIDER}")
    
    async def _get_checkpointer(self) -> AsyncPostgresSaver:
        """取得或建立 PostgreSQL Checkpointer (async singleton)"""
        if self._checkpointer is None:
            conn_string = settings.postgres_connection_string
            self._checkpointer = AsyncPostgresSaver.from_conn_string(conn_string)
            # 初始化 schema (建立必要的 tables)
            await self._checkpointer.setup()
            logger.info(f"PostgreSQL Checkpointer 已連接: {settings.POSTGRES_HOST}:{settings.POSTGRES_PORT}/{settings.POSTGRES_DB}")
        return self._checkpointer
    
    async def _get_graph(self):
        """取得已編譯的 graph (with checkpointer)"""
        if self._graph is None:
            checkpointer = await self._get_checkpointer()
            self._graph = self._build_graph().compile(checkpointer=checkpointer)
        return self._graph
    
    def _build_graph(self) -> StateGraph:
        """建構 LangGraph 工作流程"""
        
        # 定義狀態
        class OrchestratorState(MessagesState):
            """Orchestrator 狀態"""
            route: str = ""  # 路由決策
            jira_result: str = ""  # Jira Agent 結果
            faq_result: str = ""  # FAQ Agent 結果
        
        # 路由決策節點
        def router_node(state: OrchestratorState) -> Dict:
            """分析請求並決定路由"""
            messages = state["messages"]
            last_message = messages[-1].content.lower() if messages else ""
            
            # 簡單關鍵字路由（Production 可用 LLM 做更智能的路由）
            jira_keywords = ["jira", "ticket", "issue", "bug", "task", "任務", "工單", "專案", "sprint"]
            faq_keywords = ["faq", "常見問題", "政策", "流程", "怎麼申請", "規定"]
            
            if any(kw in last_message for kw in jira_keywords):
                return {"route": "jira"}
            elif any(kw in last_message for kw in faq_keywords):
                return {"route": "faq"}
            else:
                return {"route": "direct"}
        
        # Jira Agent 節點
        async def jira_node(state: OrchestratorState) -> Dict:
            """呼叫 Jira Agent"""
            messages = state["messages"]
            query = messages[-1].content if messages else ""
            
            result = await self.jira_agent.run(query)
            return {"jira_result": result}
        
        # FAQ Agent 節點（預留）
        async def faq_node(state: OrchestratorState) -> Dict:
            """呼叫 FAQ Agent（目前未實作）"""
            return {"faq_result": "FAQ Agent 目前正在開發中，請稍後再試。"}
        
        # 最終回覆節點
        async def respond_node(state: OrchestratorState) -> Dict:
            """生成最終回覆"""
            route = state.get("route", "direct")
            jira_result = state.get("jira_result", "")
            faq_result = state.get("faq_result", "")
            
            # 組合上下文
            context = ""
            if jira_result:
                context += f"\n\nJira Agent 結果：\n{jira_result}"
            if faq_result:
                context += f"\n\nFAQ Agent 結果：\n{faq_result}"
            
            # 使用 LLM 生成回覆
            messages = [
                SystemMessage(content=ORCHESTRATOR_SYSTEM_PROMPT),
                *state["messages"],
            ]
            
            if context:
                messages.append(SystemMessage(content=f"根據以下資訊回覆使用者：{context}"))
            
            response = await self.llm.ainvoke(messages)
            
            return {"messages": [response]}
        
        # 路由決策函數
        def route_decision(state: OrchestratorState) -> str:
            route = state.get("route", "direct")
            if route == "jira":
                return "jira_agent"
            elif route == "faq":
                return "faq_agent"
            else:
                return "respond"
        
        # 建構 Graph
        builder = StateGraph(OrchestratorState)
        
        # 添加節點
        builder.add_node("router", router_node)
        builder.add_node("jira_agent", jira_node)
        builder.add_node("faq_agent", faq_node)
        builder.add_node("respond", respond_node)
        
        # 添加邊
        builder.add_edge(START, "router")
        builder.add_conditional_edges("router", route_decision, {
            "jira_agent": "jira_agent",
            "faq_agent": "faq_agent",
            "respond": "respond"
        })
        builder.add_edge("jira_agent", "respond")
        builder.add_edge("faq_agent", "respond")
        builder.add_edge("respond", END)
        
        return builder
    
    def _convert_messages(self, messages: List[Dict]) -> List[BaseMessage]:
        """將 dict 格式的 messages 轉換為 LangChain BaseMessage"""
        lc_messages = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            
            if role == "user" or role == "human":
                lc_messages.append(HumanMessage(content=content))
            elif role == "assistant" or role == "ai":
                lc_messages.append(AIMessage(content=content))
            elif role == "system":
                lc_messages.append(SystemMessage(content=content))
        
        return lc_messages
    
    async def run(
        self, 
        message: str = None,
        messages: List[Dict] = None,
        conversation_id: str = None
    ) -> Dict[str, Any]:
        """
        執行（非串流模式）
        
        Args:
            message: 單一訊息（向後相容）
            messages: 完整對話歷史（Open WebUI 格式）
            conversation_id: 對話 ID (thread_id for checkpointer)
        """
        graph = await self._get_graph()
        
        # 處理輸入
        if messages:
            lc_messages = self._convert_messages(messages)
        elif message:
            lc_messages = [HumanMessage(content=message)]
        else:
            raise ValueError("必須提供 message 或 messages")
        
        # 配置 checkpointer
        config = {"configurable": {"thread_id": conversation_id or "default"}}
        
        # 執行
        result = await graph.ainvoke(
            {"messages": lc_messages},
            config=config
        )
        
        return {
            "response": result["messages"][-1].content,
            "trace": []
        }
    
    async def stream(
        self, 
        message: str = None,
        messages: List[Dict] = None,
        conversation_id: str = None
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        串流執行 - 產生軌跡事件和 token 串流
        
        Args:
            message: 單一訊息（向後相容）
            messages: 完整對話歷史（Open WebUI 格式）
            conversation_id: 對話 ID (thread_id for checkpointer)
        
        事件類型：
        - {"type": "trajectory", "event": "...", "detail": "...", ...} - 思考過程（給用戶看）
        - {"type": "token", "content": "..."} - LLM 輸出串流
        - {"type": "done", ...} - 完成
        - {"type": "error", ...} - 錯誤
        """
        # 處理輸入
        if messages:
            lc_messages = self._convert_messages(messages)
            last_content = messages[-1].get("content", "") if messages else ""
        elif message:
            lc_messages = [HumanMessage(content=message)]
            last_content = message
        else:
            yield {"type": "error", "message": "必須提供 message 或 messages"}
            return
        
        # === 軌跡事件：開始思考 ===
        yield {
            "type": "trajectory",
            "event": "thinking",
            "detail": "正在分析您的問題..."
        }
        
        # 路由決策
        last_message_lower = last_content.lower()
        jira_keywords = ["jira", "ticket", "issue", "bug", "task", "任務", "工單", "專案", "sprint"]
        faq_keywords = ["faq", "常見問題", "政策", "流程", "怎麼申請", "規定"]
        
        if any(kw in last_message_lower for kw in jira_keywords):
            # === 軌跡事件：路由決策 ===
            yield {
                "type": "trajectory",
                "event": "routing",
                "detail": "判斷需要使用 Jira Agent 來處理",
                "data": {"route": "jira"}
            }
            
            # === 軌跡事件：Agent 開始 ===
            yield {
                "type": "trajectory",
                "event": "agent_start",
                "agent": "Jira Agent",
                "detail": "呼叫 Jira Agent 查詢資料..."
            }
            
            # 執行 Jira Agent 並串流軌跡事件
            jira_result = None
            async for event in self.jira_agent.stream(last_content):
                event_type = event.get("type")
                
                if event_type == "tool_start":
                    # === 軌跡事件：工具開始 ===
                    yield {
                        "type": "trajectory",
                        "event": "tool_start",
                        "agent": "Jira Agent",
                        "tool": event.get("tool"),
                        "detail": f"使用 {event.get('tool')} 工具...",
                        "data": event.get("data")
                    }
                elif event_type == "tool_end":
                    # === 軌跡事件：工具完成 ===
                    yield {
                        "type": "trajectory",
                        "event": "tool_end",
                        "agent": "Jira Agent",
                        "tool": event.get("tool"),
                        "detail": f"{event.get('tool')} 執行完成",
                        "data": event.get("data")
                    }
                elif event_type == "result":
                    jira_result = event.get("content")
                # 其他事件可以繼續傳遞
            
            # 如果沒有從 stream 拿到結果，執行 run
            if jira_result is None:
                jira_result = await self.jira_agent.run(last_content)
            
            # === 軌跡事件：Agent 完成 ===
            yield {
                "type": "trajectory",
                "event": "agent_end",
                "agent": "Jira Agent",
                "detail": "Jira Agent 查詢完成"
            }
            
            # === 軌跡事件：整合回覆 ===
            yield {
                "type": "trajectory",
                "event": "synthesizing",
                "detail": "整理回覆中..."
            }
            
            # 使用 LLM 串流生成回覆
            response_messages = [
                SystemMessage(content=ORCHESTRATOR_SYSTEM_PROMPT),
                *lc_messages,
                SystemMessage(content=f"根據 Jira Agent 的查詢結果回覆使用者：\n{jira_result}")
            ]
            
            async for chunk in self.llm.astream(response_messages):
                if chunk.content:
                    yield {
                        "type": "token",
                        "content": chunk.content
                    }
        
        elif any(kw in last_message_lower for kw in faq_keywords):
            # === 軌跡事件：路由到 FAQ ===
            yield {
                "type": "trajectory",
                "event": "routing",
                "detail": "判斷需要使用 FAQ Agent 來處理",
                "data": {"route": "faq"}
            }
            
            yield {
                "type": "trajectory",
                "event": "agent_start",
                "agent": "FAQ Agent",
                "detail": "FAQ Agent 目前開發中..."
            }
            
            # FAQ Agent 尚未實作
            yield {
                "type": "token",
                "content": "抱歉，FAQ Agent 目前正在開發中，請稍後再試。如有其他問題，歡迎詢問！"
            }
        
        else:
            # === 軌跡事件：直接回覆 ===
            yield {
                "type": "trajectory",
                "event": "routing",
                "detail": "直接由 AI 助手回覆",
                "data": {"route": "direct"}
            }
            
            yield {
                "type": "trajectory",
                "event": "synthesizing",
                "detail": "生成回覆中..."
            }
            
            response_messages = [
                SystemMessage(content=ORCHESTRATOR_SYSTEM_PROMPT),
                *lc_messages
            ]
            
            async for chunk in self.llm.astream(response_messages):
                if chunk.content:
                    yield {
                        "type": "token",
                        "content": chunk.content
                    }
        
        # === 完成事件 ===
        yield {
            "type": "done",
            "conversation_id": conversation_id
        }
    
    async def get_conversation_history(self, conversation_id: str) -> List[Dict]:
        """
        從 Checkpointer 取得對話歷史
        
        Args:
            conversation_id: 對話 ID
        
        Returns:
            對話歷史 messages 列表
        """
        graph = await self._get_graph()
        config = {"configurable": {"thread_id": conversation_id}}
        
        try:
            state = await graph.aget_state(config)
            if state and state.values:
                messages = state.values.get("messages", [])
                return [
                    {
                        "role": "user" if isinstance(m, HumanMessage) else "assistant",
                        "content": m.content
                    }
                    for m in messages
                ]
        except Exception as e:
            logger.warning(f"取得對話歷史失敗: {e}")
        
        return []
    
    async def close(self):
        """關閉連線"""
        if self._checkpointer:
            # AsyncPostgresSaver 會自動管理連線
            self._checkpointer = None
            self._graph = None
