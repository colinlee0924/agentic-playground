# Multi-Agent Engine API 介面規格
## 給前端同事的串接文件

> 版本: v0.1.0-prototype
> 更新日期: 2024/12/08
> 後端負責人: Colin

---

## 📡 基本資訊

- **Base URL**: `http://localhost:8000` (開發環境)
- **Content-Type**: `application/json`
- **串流格式**: Server-Sent Events (SSE)

---

## 🔌 端點說明

### 1. 聊天 API（核心）

#### `POST /api/chat`

發送訊息給 Multi-Agent 系統。

**Request Body:**
```typescript
interface ChatRequest {
  message: string;           // 使用者訊息（必填）
  conversation_id?: string;  // 對話 ID，用於多輪對話（選填）
  stream?: boolean;          // 是否使用 SSE 串流，預設 true
}
```

**Response (stream=false):**
```typescript
interface ChatResponse {
  conversation_id: string;
  message: string;           // 完整回應
  agent: string;             // 回應的 Agent
  execution_trace?: AgentStatusUpdate[];  // 執行軌跡
}
```

**Response (stream=true):**
SSE 串流，事件格式如下：

---

### 2. SSE 事件格式

#### Event: `status` - Agent 狀態更新

```typescript
interface AgentStatusUpdate {
  type: "status";
  agent: string;      // "Orchestrator" | "JiraAgent" | "FAQAgent"
  status: "idle" | "thinking" | "using_tool" | "completed" | "error";
  tool?: string;      // 正在使用的工具，例如 "search_jira_tickets"
  detail?: string;    // 額外說明
  timestamp: string;  // ISO 8601 格式
}
```

**範例：**
```
event: status
data: {"type":"status","agent":"JiraAgent","status":"using_tool","tool":"search_jira_tickets","detail":"搜尋 Jira tickets...","timestamp":"2024-12-08T10:30:00.000Z"}
```

**前端顯示建議：**
```
🔄 Jira Agent 正在使用 search_jira_tickets...
```

---

#### Event: `token` - LLM 回應串流

```typescript
interface TokenChunk {
  type: "token";
  agent: string;      // 產生 token 的 Agent
  content: string;    // Token 內容（通常是 1-2 個字）
  timestamp: string;
}
```

**範例：**
```
event: token
data: {"type":"token","agent":"Orchestrator","content":"根據","timestamp":"2024-12-08T10:30:01.000Z"}

event: token
data: {"type":"token","agent":"Orchestrator","content":"查詢","timestamp":"2024-12-08T10:30:01.050Z"}

event: token
data: {"type":"token","agent":"Orchestrator","content":"結果","timestamp":"2024-12-08T10:30:01.100Z"}
```

**前端處理：** 累加 content 顯示打字機效果

---

#### Event: `tool_result` - 工具執行結果（選用）

```typescript
interface ToolResult {
  type: "tool_result";
  agent: string;
  tool: string;
  result_preview: string;  // 結果預覽（截斷至 200 字元）
}
```

**前端處理：** 可選擇是否顯示給使用者

---

#### Event: `done` - 完成

```typescript
interface DoneEvent {
  conversation_id: string;
  message: string;              // 完整回應
  trace: AgentStatusUpdate[];   // 完整執行軌跡
}
```

**前端處理：** 標記串流結束，可保存 trace 供展開查看

---

#### Event: `error` - 錯誤

```typescript
interface ErrorEvent {
  type: "error";
  message: string;
  detail?: string;
}
```

**前端處理：** 顯示錯誤訊息

---

### 3. 其他端點

#### `GET /api/agents`
列出可用的 Agents

```typescript
interface AgentsResponse {
  agents: {
    id: string;
    name: string;
    description: string;
    status: "active" | "coming_soon" | "disabled";
  }[];
}
```

#### `GET /health`
健康檢查

```typescript
interface HealthResponse {
  status: "healthy" | "unhealthy";
  service: string;
  timestamp: string;
}
```

---

## 💻 前端整合範例

### React Hook 範例

```typescript
// hooks/useAgentChat.ts
import { useState, useCallback } from 'react';
import { fetchEventSource } from '@microsoft/fetch-event-source';

interface AgentStatus {
  agent: string;
  status: string;
  tool?: string;
  detail?: string;
}

export function useAgentChat() {
  const [response, setResponse] = useState('');
  const [currentStatus, setCurrentStatus] = useState<AgentStatus | null>(null);
  const [trace, setTrace] = useState<AgentStatus[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const sendMessage = useCallback(async (message: string, conversationId?: string) => {
    setIsLoading(true);
    setResponse('');
    setTrace([]);
    setError(null);

    try {
      await fetchEventSource('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          message, 
          conversation_id: conversationId,
          stream: true 
        }),
        
        onmessage(event) {
          const data = JSON.parse(event.data);
          
          switch (event.event) {
            case 'status':
              setCurrentStatus({
                agent: data.agent,
                status: data.status,
                tool: data.tool,
                detail: data.detail
              });
              setTrace(prev => [...prev, data]);
              break;
              
            case 'token':
              setResponse(prev => prev + data.content);
              break;
              
            case 'done':
              setCurrentStatus(null);
              break;
              
            case 'error':
              setError(data.message);
              break;
          }
        },
        
        onclose() {
          setIsLoading(false);
          setCurrentStatus(null);
        },
        
        onerror(err) {
          setError('連線錯誤');
          setIsLoading(false);
          throw err;
        }
      });
    } catch (err) {
      setError('發送失敗');
      setIsLoading(false);
    }
  }, []);

  return {
    response,
    currentStatus,
    trace,
    isLoading,
    error,
    sendMessage
  };
}
```

### 元件範例

```tsx
// components/ChatInterface.tsx
import { useAgentChat } from '../hooks/useAgentChat';

function ChatInterface() {
  const { response, currentStatus, trace, isLoading, error, sendMessage } = useAgentChat();
  const [input, setInput] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      sendMessage(input);
      setInput('');
    }
  };

  return (
    <div className="chat-container">
      {/* 狀態顯示 */}
      {currentStatus && (
        <div className="status-bar">
          <span className="pulse" />
          <span>{currentStatus.agent}</span>
          {currentStatus.tool && (
            <>
              <span>正在使用</span>
              <code>{currentStatus.tool}</code>
            </>
          )}
          {currentStatus.detail && (
            <span className="detail">{currentStatus.detail}</span>
          )}
        </div>
      )}

      {/* 回應區域 */}
      <div className="response">
        {response || (isLoading && '思考中...')}
      </div>

      {/* 執行軌跡（可摺疊） */}
      {trace.length > 0 && (
        <details className="trace">
          <summary>執行軌跡 ({trace.length} 步)</summary>
          <ol>
            {trace.map((step, i) => (
              <li key={i}>
                {step.agent} - {step.status}
                {step.tool && ` (${step.tool})`}
              </li>
            ))}
          </ol>
        </details>
      )}

      {/* 錯誤顯示 */}
      {error && <div className="error">{error}</div>}

      {/* 輸入區域 */}
      <form onSubmit={handleSubmit}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="輸入訊息..."
          disabled={isLoading}
        />
        <button type="submit" disabled={isLoading}>
          發送
        </button>
      </form>
    </div>
  );
}
```

---

## 📅 串接時程

| 日期 | 里程碑 | 狀態 |
|------|--------|------|
| 12/8 (一) | API 骨架完成，可測試 | 🟢 完成 |
| 12/9 (二) | 前後端首次串接 | 🔵 進行中 |
| 12/10 (三) | SSE 串流穩定 | ⏳ 待進行 |
| 12/12 (五) | Prototype 交付 | ⏳ 待進行 |

---

## 🐛 問題回報

有任何問題請聯繫 Colin 或在 Teams/Slack 群組討論。

```
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "查詢我的 Jira tickets", "stream": false}'
```
