# 企業級 Agentic 框架：建構 Claude Code 風格的 Orchestrator 系統

**LangGraph 是建構企業級 orchestrator-worker 代理系統的首選框架**——適用於你描述的場景：一個公司內部 AI 助手引擎，由單一 orchestrator 協調 Jira Agent、FAQ Agent、Gerrit Agent 等可擴展的 worker agents。根據 **LinkedIn、Uber、Klarna 和 Elastic** 的實際企業部署案例，LangGraph 提供了最經得起考驗的複雜多代理工作流架構，而 CrewAI 則為較簡單的使用場景提供更快速的生產路徑。

關鍵差異在於架構理念：LangGraph 的圖形化狀態機方法可直接對應到具有明確控制流程的 orchestrator-worker 模式，而 CrewAI 基於角色的「Crews」抽象則擅長自主協作，但提供的細粒度控制較少。對於 air-gapped 企業環境，兩個框架都支援透過 Ollama 或 vLLM 進行自託管部署搭配本地 LLM，使其適用於安全的內部助手引擎。

---

## 一、企業級 Orchestrator-Worker 系統的框架比較

Agentic 框架領域已整合為幾個生產就緒的選項，各自對企業部署有不同的優勢。

### LangGraph：複雜企業工作流的領導者

**LangGraph**（21,000 GitHub stars，每月 420 萬 PyPI 下載量）已成為需要明確編排的生產 agentic 系統的事實標準。LinkedIn 的內部 SQL Bot——與你提議的系統架構幾乎相同——展示了 LangGraph 大規模 orchestrator-worker 模式的實力。Klarna 使用 LangGraph 驅動的代理服務 **8,500 萬活躍用戶**，將解決時間縮短了 80%。

該框架使用 `StateGraph` 的圖形化架構提供對代理協調的明確控制，並透過 `langgraph-supervisor-py` 內建支援 supervisor 模式。原生的 PostgreSQL 檢查點功能實現持久化的多輪對話，而 LangSmith 整合則提供企業級可觀測性，具有逐步追蹤視覺化功能。

### CrewAI：最快的投產時間

**CrewAI**（40,400 stars，獲得 Insight Partners 1,800 萬美元 A 輪融資，吳恩達投資）透過基於角色的代理設計提供最直覺的開發者體驗。雙模式架構——用於自主協作的 **Crews** 和用於事件驅動編排的 **Flows**——涵蓋自主和受控兩種使用場景。

CrewAI 聲稱被近半數財富 500 強公司採用，但具體企業部署案例的文件記錄不如 LangGraph 詳盡。2024 年 10 月推出的 **CrewAI AMP Suite** 提供企業控制平面功能，包括即時追蹤和本地部署選項。

### AutoGen：星數最高但前景不明

**Microsoft AutoGen**（51,700 stars——所有框架中最高）於 2025 年 10 月宣布整合進入 **Microsoft Agent Framework**，AutoGen 進入維護模式。組織在為新專案投入 AutoGen 之前應注意這一轉變。Microsoft 建議需要透過 Microsoft Unified Support 獲得企業 SLA 支援的生產工作負載使用 **Semantic Kernel**（23,000 stars，v1.0 GA）。

### 框架決策矩陣

| 評估標準 | LangGraph | CrewAI | AutoGen | Semantic Kernel |
|----------|-----------|--------|---------|-----------------|
| **GitHub Stars** | 21K | 40.4K | 51.7K | 23K |
| **月下載量** | 420 萬 | ~100 萬 | — | — |
| **生產狀態** | ✅ 生產就緒 | ✅ 生產就緒 | ⚠️ 維護模式 | ✅ v1.0 GA |
| **Orchestrator-Worker 原生支援** | ✅ 優秀 (StateGraph) | ✅ 良好 (Crews+Flows) | ✅ 良好 (Teams) | ⚠️ 預覽版 |
| **學習曲線** | 陡峭 | 簡單 | 中等偏難 | 中等 |
| **企業客戶** | LinkedIn, Uber, Klarna, Elastic | 財富 500（聲稱） | Novo Nordisk | 財富 500 |
| **Air-Gapped 支援** | ✅ 自託管企業版 | ✅ 本地部署選項 | ✅ 容器可部署 | ✅ Azure/本地 |
| **多 LLM 支援** | ✅ 所有供應商 | ✅ 透過 LiteLLM | ✅ 所有供應商 | ✅ 所有供應商 |
| **企業可觀測性** | ✅ LangSmith | ✅ AMP 控制平面 | ⚠️ 基本日誌 | ✅ Azure Monitor |
| **Human-in-the-Loop** | ✅ 一級支援 | ✅ 支援 | ✅ 原生支援 | ✅ 支援 |

**建議**：需要細粒度控制的複雜 orchestrator-worker 系統選擇 LangGraph；需要更快原型開發的簡單角色設計選擇 CrewAI；以 Azure 為中心且需要企業 SLA 的 Microsoft 環境選擇 Semantic Kernel。

---

## 二、高星開源專案：多代理系統參考

以下專案實現了適合企業部署的 orchestrator-worker 模式，按星數和生產就緒度組織。

### 第一梯隊：生產就緒框架（40,000+ stars）

| 專案 | Stars | 授權 | 關鍵特性 | 最後更新 |
|------|-------|------|----------|----------|
| **[AutoGPT](https://github.com/Significant-Gravitas/AutoGPT)** | 180,000 | MIT | 低程式碼代理建構器、代理市場、用於自訂代理的 Forge SDK、Agent Protocol 標準 | 2025/12 |
| **[OpenHands](https://github.com/All-Hands-AI/OpenHands)** | 65,000+ | MIT | 通用代理控制器、用於編排的 AgentController、安全 Docker 沙箱執行、GitHub/GitLab/Slack 整合 | 2025/12 |
| **[MetaGPT](https://github.com/FoundationAgents/MetaGPT)** | 59,500 | MIT | SOP 驅動的多代理協作、模擬軟體公司角色（PM、架構師、工程師）、流水線任務分解 | 2025 |
| **[CrewAI](https://github.com/crewAIInc/crewAI)** | 40,400 | MIT | 用於自主團隊的 Crews、用於事件驅動編排的 Flows、階層式流程模式、100+ 工具套件 | 2025/11 |

### 第二梯隊：強勁的企業候選（15,000-40,000 stars）

| 專案 | Stars | 授權 | 關鍵特性 | 最後更新 |
|------|-------|------|----------|----------|
| **[Aider](https://github.com/Aider-AI/aider)** | 38,600 | Apache 2.0 | AI 結對編程、程式碼庫映射、多 LLM 支援、SWE-Bench 頂尖分數 | 2025/08 |
| **[Agno](https://github.com/agno-agi/agno)**（原 Phidata） | 35,300 | MIT | 多代理團隊、**AgentOS Runtime** 生產 FastAPI 應用、MCP 和 A2A 協定支援、聲稱比 LangGraph 快 5000 倍 | 2025/12 |
| **[AutoGen/AG2](https://github.com/microsoft/autogen)** | 36,000 | MIT/Apache | 多代理對話、Supervisor 模式、AutoGen Studio 無程式碼 GUI、.NET 支援 | 2025/12 |
| **[SuperAGI](https://github.com/TransformerOptimus/SuperAGI)** | 16,700 | MIT | 並行代理運行、代理模板、工具套件市場、GUI 介面 | 2024 |

### 最適合企業 Orchestrator-Worker 系統的專案

**OpenHands** 特別值得關注——其 `AgentController` 提供通用編排層，具有用於跨多個代理任務分配的 session 和 EventStream 管理。該專案支援具有細粒度存取控制的自託管部署，適合公司內部 AI 助手。

**Agno 的 AgentOS** 提供了一個引人注目的替代方案，其生產就緒的 FastAPI runtime 和完全在你的雲端運行的控制平面可確保完整的資料隱私。該框架聲稱比 LangGraph 有顯著的性能優勢，但獨立基準測試有限。

---

## 三、Air-Gapped 環境的企業部署

在公司 air-gapped 網路中部署 agentic 系統需要仔細關注 LLM 供應商彈性、套件管理和可觀測性基礎設施。

### Air-Gapped 部署架構

**LangGraph** 提供三個自託管層級：
- **Self-Hosted Lite**（免費）：最多 100 萬節點，本地運行搭配 PostgreSQL 和 Redis
- **Self-Hosted Enterprise**：VPC 內完全控制，需要管理 Postgres、Redis 和使用 `langgraph build -t my-agent:latest` 建構的 Docker 映像
- **BYOC（Bring Your Own Cloud）**：AWS 部署，LangChain 管理控制平面，資料保留在你的 VPC

**CrewAI AOP** 支援使用你偏好的雲端服務進行本地部署。該框架內部使用 LiteLLM，可以配置本地 LLM 端點而無需外部網路呼叫。

### 多 LLM 供應商整合

**LiteLLM** 作為 air-gapped 部署的通用 LLM 閘道器，透過 OpenAI 相容介面支援 100+ 供應商：

```yaml
# litellm_config.yaml 企業多供應商設定
model_list:
  - model_name: bedrock-claude
    litellm_params:
      model: bedrock/anthropic.claude-3-5-sonnet-20240620-v1:0
      aws_region_name: us-east-1
  - model_name: azure-gpt4
    litellm_params:
      model: azure/gpt-4
      api_base: https://your-endpoint.openai.azure.com
  - model_name: local-llama
    litellm_params:
      model: ollama/llama3.2
      api_base: http://localhost:11434
```

Router fallback 配置確保韌性：
```python
router = Router(
    model_list=[...],
    fallbacks=[{"bedrock-claude": ["azure-gpt4", "local-llama"]}],
    num_retries=3
)
```

### Air-Gapped 網路的自託管 LLM 選項

| 方案 | 最適用於 | 性能 | 整合方式 |
|------|----------|------|----------|
| **vLLM** | 生產吞吐量 | 比基準高 2-4 倍吞吐量，PagedAttention 減少 50%+ 記憶體 | OpenAI 相容 API |
| **Ollama** | 開發/測試 | 設定簡單，小型模型可用 CPU | `/v1` 的 OpenAI 相容 |
| **text-generation-inference** | HuggingFace 模型 | 優化推理 | REST API |
| **LocalAI** | 功能豐富的本地部署 | 多種模型格式 | OpenAI 相容 |

**LangGraph + Ollama 整合**：
```python
from langchain_ollama import ChatOllama
llm = ChatOllama(model="llama3.2:latest", base_url="http://localhost:11434")
```

**CrewAI + Ollama 整合**：
```python
from crewai import Agent, LLM
agent = Agent(
    role='Local Expert',
    llm=LLM(model="ollama/llama3.2", base_url="http://localhost:11434"),
    embedder={"provider": "ollama", "config": {"model": "nomic-embed-text"}}
)
```

### 無雲端依賴的生產可觀測性

對於完全 air-gapped 的環境，可用以下方案替代雲端 LangSmith：

- **Langfuse**（開源，MIT 授權）：可自託管的追蹤平台，具有 LangChain 整合
- **OpenTelemetry + Jaeger/Grafana Tempo**：標準的追蹤可觀測性堆疊
- **Arize Phoenix**：漂移檢測和 LLM-as-judge 評分，可自託管

自託管 LangSmith 可供需要在隔離網路中使用 LangChain 原生可觀測性的企業層客戶使用。

---

## 四、可擴展 Worker Agents 的架構模式

推薦的架構遵循 LangGraph 的 **Supervisor Pattern**，提供明確的編排控制，同時實現類似插件的代理可擴展性。

### 核心架構：Supervisor + 動態 Worker 註冊

```
┌─────────────────────────────────────┐
│            使用者介面                │
└──────────────────┬──────────────────┘
                   │
┌──────────────────▼──────────────────┐
│      Orchestrator (Supervisor)       │
│  • 按能力路由請求                     │
│  • 管理對話狀態                       │
│  • 聚合 worker 結果                   │
│  • Human-in-the-loop 審批            │
└──────────────────┬──────────────────┘
                   │
    ┌──────────────┼──────────────┐
    │              │              │
┌───▼───┐    ┌────▼────┐   ┌────▼────┐
│ Jira  │    │   FAQ   │   │ Gerrit  │
│ Agent │    │  Agent  │   │  Agent  │
│[MCP]  │    │  [MCP]  │   │  [MCP]  │
└───────┘    └─────────┘   └─────────┘
```

### 易於擴展的插件架構

可擴展性的關鍵是**標準化的 worker 介面**結合**動態註冊表**：

```python
from abc import ABC, abstractmethod
from typing import List

class WorkerAgentInterface(ABC):
    """所有 worker agents 必須實現的基礎介面"""
    
    @property
    @abstractmethod
    def name(self) -> str:
        """用於代理註冊的唯一識別符"""
        pass
    
    @property
    @abstractmethod
    def description(self) -> str:
        """用於路由決策的描述"""
        pass
    
    @abstractmethod
    def get_capabilities(self) -> List[str]:
        """此代理可處理的任務類型清單"""
        pass
    
    @abstractmethod
    async def invoke(self, state: dict) -> dict:
        """執行代理任務並返回結果"""
        pass

class AgentRegistry:
    """實現動態代理發現的中央註冊表"""
    
    def __init__(self):
        self._agents = {}
        self._capability_map = {}
    
    def register(self, agent: WorkerAgentInterface):
        self._agents[agent.name] = agent
        for capability in agent.get_capabilities():
            self._capability_map.setdefault(capability, []).append(agent.name)
    
    def get_routing_prompt(self) -> str:
        return "\n".join([
            f"- {name}: {agent.description}" 
            for name, agent in self._agents.items()
        ])
```

新增 worker agent 只需要：
1. 實現 `WorkerAgentInterface`
2. 呼叫 `registry.register(new_agent)`
3. Orchestrator 自動在路由決策中包含新代理

### MCP 整合：標準化工具存取

**Model Context Protocol (MCP)** 由 Anthropic 於 2024 年 11 月推出，並被 OpenAI、Google DeepMind 和 Microsoft 採用，提供了將代理連接到外部系統的標準化介面——非常適合企業工具整合。

每個 worker agent 透過 MCP server 連接到其領域：

```python
# 帶有 MCP server 的 Jira Agent
from mcp import ClientSession
from mcp.client.stdio import stdio_client

async def create_jira_agent():
    async with stdio_client(command="npx", args=["jira-mcp-server"]) as session:
        tools = await session.list_tools()
        langchain_tools = [convert_mcp_to_langchain(t) for t in tools]
        
        return create_react_agent(
            model=model,
            tools=langchain_tools,
            name="jira_agent",
            prompt="處理 Jira 操作：建立 issue、搜尋、更新狀態。"
        )
```

MCP 為企業整合提供三種原語：
- **Tools**：代理可呼叫的函數（資料庫查詢、API 呼叫）
- **Resources**：資料來源（檔案、資料庫、知識庫）
- **Prompts**：最佳工具使用的預定義模板

### 多輪企業對話的狀態管理

LangGraph 的檢查點系統實現跨 session 的持久對話狀態：

```python
from langgraph.checkpoint.postgres import PostgresSaver

# 生產環境：PostgreSQL 持久化
checkpointer = PostgresSaver.from_conn_string(
    "postgresql://user:pass@localhost:5432/agents"
)

graph = builder.compile(checkpointer=checkpointer)

# 基於 thread 的對話連續性
config = {"configurable": {"thread_id": f"user_{user_id}_session_{session_id}"}}
result = graph.invoke({"messages": [...]}, config)
```

對於跨代理共享上下文（例如，Jira Agent 建立的 ticket ID 需要被 Gerrit Agent 使用）：

```python
class MultiAgentState(TypedDict):
    messages: List[BaseMessage]
    next: str
    shared_context: dict  # 跨代理資料：current_jira_ticket, code_review_id
```

---

## 五、公司 AI 助手的實施建議

根據研究，以下是建構具有 orchestrator-worker 架構的企業內部 AI 助手的推薦技術堆疊：

### 主要建議：基於 LangGraph 的堆疊

| 元件 | 推薦方案 | 理由 |
|------|----------|------|
| **編排框架** | LangGraph | 最佳 orchestrator-worker 支援，在 LinkedIn/Uber 規模驗證 |
| **LLM 閘道** | LiteLLM（自託管） | Bedrock Claude、Azure OpenAI、本地模型的統一介面 |
| **本地 LLM** | vLLM（生產）/ Ollama（開發） | vLLM 用於吞吐量；Ollama 用於簡易開發 |
| **可觀測性** | Langfuse 或自託管 LangSmith | 開源選項可在 air-gapped 網路運作 |
| **狀態持久化** | PostgreSQL via PostgresSaver | 持久化多輪對話 |
| **工具整合** | 每個領域的 MCP servers | 標準化、可擴展的工具存取 |

### 替代方案：CrewAI 堆疊（更快開發）

如果優先考慮開發速度而非細粒度控制，CrewAI 基於角色的方法可縮短投產時間：

```python
from crewai import Agent, Crew, Task, Flow

jira_agent = Agent(role='Jira 專家', goal='管理 Jira tickets', ...)
faq_agent = Agent(role='FAQ 專家', goal='回答內部問題', ...)
gerrit_agent = Agent(role='Gerrit 專家', goal='處理程式碼審查', ...)

assistant_crew = Crew(
    agents=[jira_agent, faq_agent, gerrit_agent],
    process=Process.hierarchical,  # 自動分配 manager
    manager_llm=ChatOpenAI(model="gpt-4")
)
```

### 關鍵實施原則

1. **從簡單開始**：先建立單一代理原型，只在有明確需求時才新增 workers
2. **介面契約**：定義清晰的 `WorkerAgentInterface`，所有代理都實現此介面以實現熱插拔擴展
3. **狀態隔離**：保持代理狀態分離，只透過 `shared_context` dict 共享必要的上下文
4. **工具文件**：投資清晰的工具描述——代理的效能很大程度取決於對可用能力的理解
5. **優雅降級**：設計 worker agents 失敗時的 fallback 路徑；supervisor 應處理錯誤而不使整個系統崩潰
6. **上下文工程**：控制每個代理看到的資訊，以減少 token 使用並提高路由準確性

---

## 六、總結：技術選型決策樹

```
你的使用場景是什麼？
│
├─► 需要細粒度控制的複雜 orchestrator-worker 系統
│   └─► 選擇 LangGraph
│       • 使用 langgraph-supervisor-py 實現 supervisor 模式
│       • PostgresSaver 用於狀態持久化
│       • Langfuse 或自託管 LangSmith 用於可觀測性
│
├─► 需要快速原型開發的簡單角色協作
│   └─► 選擇 CrewAI
│       • 使用 Crews + hierarchical process
│       • LiteLLM 用於多 LLM 支援
│       • AMP Suite 用於企業控制平面
│
└─► Azure 為中心的 Microsoft 環境 + 需要企業 SLA
    └─► 選擇 Semantic Kernel
        • Azure AI Agent Service 整合
        • Microsoft Unified Support
```

LangGraph 的明確編排、MCP 的標準化工具整合，以及 LiteLLM 的供應商抽象的組合，為企業內部 AI 助手創建了堅實的基礎。這個架構可以隨著新 worker agents（Confluence Agent、ServiceNow Agent 等）的新增而演進，而無需修改核心基礎設施。

對於你在 MediaTek 的 POC（兩週內）和生產版本（一個月內），建議：
1. **POC 階段**：使用 LangGraph + Ollama 本地開發，先實現 Jira Agent 單一 worker
2. **生產階段**：加入 LiteLLM 整合商用 LLM，PostgresSaver 持久化，Langfuse 可觀測性
3. **擴展階段**：按需新增 FAQ Agent、Gerrit Agent，透過 AgentRegistry 動態註冊
