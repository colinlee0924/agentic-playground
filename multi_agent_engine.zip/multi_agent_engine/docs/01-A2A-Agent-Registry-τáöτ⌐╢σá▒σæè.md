# 為 M公司 建構企業級 Agent Registry 與 A2A Protocol 生態系

Google 的 A2A（Agent-to-Agent）Protocol 於 2025 年 4 月發布，目前已獲得包括 Microsoft、SAP、Salesforce 在內的 100+ 企業合作夥伴支持，為 M公司 可擴展的多代理架構提供了堅實的基礎。結合 LangGraph 的**原生 A2A 支援**（在 `langgraph-api>=0.4.21` 中可用），你可以建構一個生產就緒的代理生態系，讓不同部門能夠獨立開發、註冊和部署專業化的 worker agents，並透過標準化介面進行通訊。

關鍵架構洞察：**A2A 處理水平整合**（agent-to-agent 協作），而 **MCP 處理垂直整合**（agent-to-tool 連接）。你的 Jira Agent 內部使用 MCP 連接 Jira API，但對外暴露 A2A 相容介面，讓 orchestrator 可以使用自然語言對話來委派任務。

---

## 一、A2A Protocol 基礎與企業適用性

Agent-to-Agent Protocol 是一個開放標準，使基於不同框架建構的 AI agents 能夠作為**不透明的協作者**進行通訊——共享任務和結果，但不暴露內部狀態、記憶或實作細節。這種不透明性非常適合企業環境，各部門可以貢獻 agents 而無需揭露專有邏輯。

### 核心通訊流程

```
1. Discovery（發現）: Client 從 /.well-known/agent-card.json 獲取 Agent Card
2. Initiate（發起）: Client 透過 message/send 或 message/stream 發送訊息，附帶唯一 Task ID
3. Processing（處理）: Server 處理請求，透過生命週期狀態更新任務狀態
4. Completion（完成）: 任務達到終態（completed/failed/canceled），Artifacts 包含輸出
```

協定使用 **JSON-RPC 2.0 over HTTPS**，支援三種傳輸方式：JSON-RPC（預設）、gRPC 和 REST 風格的 HTTP+JSON。對於長時間運行的任務，Server-Sent Events (SSE) 提供即時串流，push notifications 啟用基於 webhook 的非同步通訊——這對涉及人工審批循環的工作流程至關重要。

### 任務狀態生命週期

```
submitted → working → [input-required ↔ working] → completed/failed/canceled
                   → auth-required（用於獲取次級憑證）
```

### 企業級安全性

企業安全性已內建，認證方案與 **OpenAPI 3.0** 對齊：OAuth 2.0 flows、API keys、HTTP Bearer/Basic、OpenID Connect 和 mutual TLS。Agent Cards 可以使用 JSON Web Signatures (JWS) 進行加密簽名以驗證完整性。`auth-required` 狀態支援任務執行中的動態憑證獲取，支援財務代理需要提升權限進行敏感操作的場景。

---

## 二、A2A vs MCP：架構中的互補協定

| 維度 | MCP (Anthropic) | A2A (Google) |
|------|-----------------|--------------|
| **主要目的** | 連接 agent 到工具/資料來源 | 實現 agent-to-agent 協作 |
| **通訊風格** | Schema 驅動的函數呼叫 | 對話式任務委派 |
| **範例** | `get_jira_ticket(ticket_id='PROJ-123')` | "找出所有分配給 John 的未關閉 tickets" |
| **狀態模型** | 無狀態工具操作 | 有狀態任務生命週期（可達數小時/天） |
| **發現機制** | 透過 MCP server 的工具目錄 | 在 well-known URIs 的 Agent Cards |
| **發布時間** | 2024 年 11 月 | 2025 年 4 月 |
| **採用情況** | OpenAI, Microsoft, Google Gemini, Anthropic | 100+ 合作夥伴，Linux Foundation 治理 |

### 在你的架構中何時使用各協定

- **MCP** 用於每個 worker agent 的內部工具連接：
  - Jira Agent 使用 MCP 呼叫 Jira REST API
  - Gerrit Agent 使用 MCP 查詢 code review 端點
  - FAQ Agent 使用 MCP 搜尋知識庫

- **A2A** 用於 orchestrator-to-worker 通訊：
  - LangGraph orchestrator 使用 A2A 的自然語言任務委派，將「為這個 PR 建立 code review」委派給 Gerrit Agent

**協定可以優雅地共存**。每個部門使用 MCP 建構其 worker agent 的工具存取，然後用 A2A 相容介面包裝。Orchestrator 只說 A2A——它不需要知道 Jira Agent 內部是使用 MCP、直接 API 呼叫還是資料庫查詢。

---

## 三、Agent Card 規格：實現自描述的 Agents

Agent Card 是一個 JSON 中繼資料文件，各部門發布在 `/.well-known/agent-card.json` 來廣告其 agent 的能力。這是你的 agent registry 的基礎。

```json
{
  "protocolVersion": "0.3.0",
  "name": "Jira Agent",
  "description": "為工程工作流建立、查詢和管理 Jira tickets",
  "url": "https://jira-agent.internal.company.com/a2a/v1",
  "version": "2.1.0",
  "provider": {"organization": "Engineering Tools Team"},
  "capabilities": {
    "streaming": true,
    "pushNotifications": true
  },
  "securitySchemes": {
    "internal_oauth": {
      "type": "oauth2",
      "flows": {
        "clientCredentials": {
          "tokenUrl": "https://auth.internal.company.com/token",
          "scopes": {"agents:invoke": "呼叫 agent 能力"}
        }
      }
    }
  },
  "skills": [
    {
      "id": "create-ticket",
      "name": "建立 Jira Ticket",
      "description": "使用指定欄位建立新的 Jira ticket",
      "tags": ["jira", "ticketing", "project-management"],
      "examples": ["建立一個登入頁面當機的 bug ticket", "開一個暗黑模式的 feature request"]
    },
    {
      "id": "query-tickets",
      "name": "查詢 Tickets",
      "description": "使用 JQL 或自然語言搜尋和過濾 Jira tickets",
      "tags": ["jira", "search", "reporting"]
    }
  ]
}
```

### 企業 Registry 的關鍵欄位

| 欄位 | 用途 |
|------|------|
| **skills** | 描述特定能力的陣列，含範例——供 orchestrator 進行語意匹配 |
| **securitySchemes** | 遵循 OpenAPI 3.0 的認證需求 |
| **provider** | 所有權資訊，用於治理和問責 |
| **version** | 語意版本控制，用於生命週期管理 |

---

## 四、建構你的 Agent Registry 平台

Agent Registry 作為系統的 single source of truth，用於 agent 發現、治理和生命週期管理。對於 M公司 的多部門設置，實現**集中式 registry + 聯邦式 agent 部署**。

### 核心 Registry 元件

| 元件 | 用途 |
|------|------|
| **Register** | 接受 Agent Card 提交（自註冊）或從已知 agent URLs 拉取 |
| **Repository** | 儲存所有 Agent Cards 及完整中繼資料，使用 PostgreSQL 或類似方案 |
| **Discovery API** | 按能力、標籤、部門或語意搜尋查詢 agents |
| **Monitor** | 健康檢查、心跳驗證、狀態追蹤 |
| **Access Control** | 組織層級的 RBAC + 上下文敏感的 ABAC |

### 建議的中繼資料 Schema（擴展 A2A Agent Cards）

```json
{
  "agent_card": { /* 標準 A2A Agent Card */ },
  "registry_metadata": {
    "department": "Engineering Tools",
    "owner_team": "platform-infra@company.com",
    "status": "active",
    "created_at": "2025-06-15T10:00:00Z",
    "updated_at": "2025-12-01T14:30:00Z",
    "dependencies": ["auth-service", "jira-api"],
    "sla": {"max_response_time_ms": 5000, "availability_target": "99.5%"},
    "rate_limits": {"requests_per_minute": 100},
    "approval_status": "approved",
    "approved_by": "platform-admin@company.com"
  }
}
```

### 存取控制模型

實現混合 RBAC+ABAC：

- **RBAC 層**：部門角色（agent-developer、agent-admin、platform-admin）具有預定義權限
- **ABAC 層**：上下文敏感規則（例如「財務 agents 只能由具有 finance:read 範圍的使用者在工作時間呼叫」）
- **Just-In-Time 存取**：對於敏感 agents，在呼叫前需要審批工作流程

---

## 五、高價值開源專案參考

### A2A Protocol 實現

| 專案 | Stars | 關鍵特性 | 生產就緒度 |
|------|-------|----------|-----------|
| [a2aproject/A2A](https://github.com/a2aproject/A2A) | **20,900** | 官方規格、Python/Go/JS/Java/.NET SDK | ★★★★★ 參考實現 |
| [themanojdesai/python-a2a](https://github.com/themanojdesai/python-a2a) | **953** | 完整 A2A+MCP 整合、LangChain 支援、內建 registry、視覺化工作流編輯器 | ★★★★ 生產就緒 |
| [a2aproject/a2a-samples](https://github.com/a2aproject/a2a-samples) | 成長中 | 官方範例實現、多語言範例 | ★★★ 學習資源 |

### Agent Registry 專案

| 專案 | Stars | 關鍵特性 | 企業適用性 |
|------|-------|----------|-----------|
| [agentic-community/mcp-gateway-registry](https://github.com/agentic-community/mcp-gateway-registry) | **277** | 統一 A2A + MCP registry、OAuth（Keycloak/Cognito/Entra ID）、語意搜尋、安全掃描、Grafana 儀表板 | ★★★★★ **最佳企業選項** |
| [codegrande/agent-name-service](https://github.com/codegrande/agent-name-service) | 新專案 | OWASP 安全專案、憑證管理、A2A/MCP 發現 | ★★★ 安全導向 |
| [agentregistry-dev/agentregistry](https://github.com/agentregistry-dev/agentregistry) | 新專案 | CLI 工具（arctl）、artifact 管理、驗證 | ★★★ 新興專案 |

### LangGraph 多代理編排

| 專案 | Stars | 關鍵特性 | 相關性 |
|------|-------|----------|--------|
| [langchain-ai/langgraph](https://github.com/langchain-ai/langgraph) | **11,700** | 原生 A2A 支援、有狀態工作流、生產驗證（Klarna、AppFolio、Elastic） | ★★★★★ 你的 orchestrator 選擇 |
| [langchain-ai/langgraph-supervisor-py](https://github.com/langchain-ai/langgraph-supervisor-py) | 官方 | 階層式多代理、中央 supervisor 協調 | ★★★★ 符合你的架構 |
| [langchain-ai/langgraph-swarm-py](https://github.com/langchain-ai/langgraph-swarm-py) | 官方 | 動態 handoffs、點對點協作 | ★★★★ 替代模式 |
| [awslabs/agent-squad](https://github.com/awslabs/agent-squad) | **7,100** | 智慧路由、Python+TypeScript、AWS Bedrock 整合 | ★★★★★ 如果大量使用 AWS |

### M公司 建議的初始技術棧

| 元件 | 建議方案 | 理由 |
|------|----------|------|
| **Orchestrator** | LangGraph with native A2A (langgraph-api>=0.4.21) | 原生 A2A 支援，生產驗證 |
| **Registry** | Fork 並擴展 mcp-gateway-registry | 統一 A2A+MCP 治理 |
| **A2A 函式庫** | python-a2a | 快速 worker agent 開發 |
| **模式參考** | langgraph-supervisor-py | 階層式編排 |

---

## 六、LangGraph 整合架構

LangGraph 透過內建端點提供**原生 A2A 支援**：
- **A2A 端點**：每個部署的 assistant 為 `/a2a/{assistant_id}`
- **Agent Card 發現**：`GET /.well-known/agent-card.json?assistant_id={assistant_id}`

### Supervisor 架構模式：你的 Orchestrator

```python
from langgraph.graph import StateGraph, MessagesState, START, END
from langgraph.pregel.remote import RemoteGraph

# 透過 A2A 連接部門 worker agents
jira_agent = RemoteGraph("jira_agent", url="https://jira-agent.internal.company.com/api")
gerrit_agent = RemoteGraph("gerrit_agent", url="https://gerrit-agent.internal.company.com/api")
faq_agent = RemoteGraph("faq_agent", url="https://faq-agent.internal.company.com/api")

def route_by_capability(state: MessagesState) -> str:
    """基於發現的 agent 能力進行動態路由"""
    query = state["messages"][-1].content.lower()
    
    # 基於能力的路由（或使用 LLM 進行語意匹配）
    if any(kw in query for kw in ["ticket", "jira", "bug", "issue"]):
        return "jira_agent"
    elif any(kw in query for kw in ["code review", "gerrit", "merge", "patch"]):
        return "gerrit_agent"
    elif any(kw in query for kw in ["how to", "what is", "help", "faq"]):
        return "faq_agent"
    return "fallback"

# 建構 orchestrator graph
builder = StateGraph(MessagesState)
builder.add_node("router", router_node)
builder.add_node("jira_agent", jira_agent)
builder.add_node("gerrit_agent", gerrit_agent)
builder.add_node("faq_agent", faq_agent)

builder.add_edge(START, "router")
builder.add_conditional_edges("router", route_by_capability, {
    "jira_agent": "jira_agent",
    "gerrit_agent": "gerrit_agent",
    "faq_agent": "faq_agent",
    "fallback": END
})

orchestrator = builder.compile()
```

### Air-Gapped 部署選項

LangGraph 支援自託管選項：
- **Self-Hosted Enterprise**：完全自託管，使用 PostgreSQL 持久化和 Redis 進行 pub/sub
- 透過內部負載均衡器後的無狀態伺服器實例進行水平擴展
- 內建 checkpointing 實現故障後的任務恢復

---

## 七、決策用比較表

### Agent 通訊協定比較

| 協定 | 焦點 | 傳輸方式 | 發現機制 | 安全性 | 成熟度 | 最適用於 |
|------|------|----------|----------|--------|--------|----------|
| **A2A** | Agent-to-agent | HTTP, JSON-RPC, gRPC | well-known URIs 的 Agent Cards | OAuth 2.0, mTLS, API keys | v0.3.0 (pre-1.0) | 多代理編排 |
| **MCP** | Agent-to-tool | Stdio, HTTP+SSE | 透過 server 的工具目錄 | 使用者同意, OAuth 2.1 | 穩定 | 工具/資料整合 |
| **ACP** | Agent-to-agent | REST | 嵌入式中繼資料 | REST 安全 | 已合併入 A2A | 舊版，遷移到 A2A |
| **ANP** | 去中心化 | P2P | DIDs | 加密 | 新興 | 跨組織、開放生態系 |

### Agent Registry 平台比較

| 平台 | A2A 支援 | MCP 支援 | 認證選項 | 發現方式 | Air-gap Ready | 建議 |
|------|----------|----------|----------|----------|---------------|------|
| **mcp-gateway-registry** | ✅ | ✅ | Keycloak, Cognito, Entra ID | 語意搜尋 | ✅ | **最佳選擇** |
| **自建（A2A Agent Cards + PostgreSQL）** | ✅ | 手動 | 自訂 | 自訂 API | ✅ | 完全控制選項 |
| **python-a2a 內建 registry** | ✅ | ✅ | 基本 | 標籤式 | ✅ | 快速啟動 |
| **LangGraph Platform** | ✅ | Via tools | 內建 | Assistant-based | Cloud/BYOC | 非 air-gapped |

### 開源專案綜合比較

| 專案 | Stars | 類型 | A2A | MCP | 企業功能 | 建議用途 |
|------|-------|------|-----|-----|----------|----------|
| **a2aproject/A2A** | 20.9K | 協定規格 | ✅ | - | 官方 SDK | 參考實現 |
| **mcp-gateway-registry** | 277 | Registry | ✅ | ✅ | OAuth, 監控 | **生產 Registry** |
| **python-a2a** | 953 | SDK | ✅ | ✅ | 內建 registry | Worker Agent 開發 |
| **langgraph** | 11.7K | 編排框架 | ✅ | Via tools | 生產驗證 | **Orchestrator** |
| **langgraph-supervisor-py** | 官方 | 模式 | ✅ | - | 階層式 | 架構參考 |
| **awslabs/agent-squad** | 7.1K | 編排框架 | - | - | AWS 整合 | AWS 環境替代 |

---

## 八、企業採用考量

### A2A 對 M公司 使用案例的優勢

| 優勢 | 說明 |
|------|------|
| **框架無關** | 部門可以使用 LangGraph、CrewAI 或自訂實現建構 agents——全部透過標準 A2A 通訊 |
| **不透明執行** | Agents 不暴露內部 prompts、工具或 LLM 選擇，保護部門 IP |
| **長時間運行任務支援** | 內建任務生命週期管理，具有 human-in-the-loop 能力用於審批工作流程 |
| **企業安全性** | OAuth 2.0 flows 與現有企業身份提供者整合 |
| **強大生態系** | 100+ 合作夥伴包括 Microsoft (Azure AI Foundry)、SAP、Salesforce——降低供應商鎖定風險 |
| **Linux Foundation 治理** | 協定可持續性超越 Google |

### 需要規劃的挑戰

| 挑戰 | 應對策略 |
|------|----------|
| **Pre-1.0 規格** | 在 v1.0 之前預期會有破壞性變更（目標 2025 年底）；在內部介面後抽象協定細節 |
| **HTTP 延遲** | 不適合微秒級響應場景；對你的企業任務自動化使用案例沒問題 |
| **Registry 標準化缺口** | A2A 不規定 registry API——你需要實現自訂發現 |
| **Air-gapped LLM 考量** | Worker agents 需要存取你的自託管 LLMs 或商用 API 端點 |

---

## 九、M公司 實施路線圖

### Phase 1：基礎建設（第 1-4 週）

| 任務 | 交付物 |
|------|--------|
| 部署 LangGraph Platform 自託管 | PostgreSQL + Redis 環境 |
| 實現基本 orchestrator | 2-3 個試點 worker agents（FAQ Agent、簡單 Jira Query Agent） |
| 使用 python-a2a 函式庫 | 快速 A2A 合規 |
| 測試端到端流程 | 與內部 OAuth provider 整合 |

### Phase 2：Registry 平台（第 5-8 週）

| 任務 | 交付物 |
|------|--------|
| Fork 並客製化 mcp-gateway-registry | 內部部署版本 |
| 定義 Agent Card schema 擴展 | M公司 中繼資料需求 |
| 實現審批工作流程 | Agent 註冊流程 |
| 部署 Grafana 儀表板 | Agent 健康監控 |

### Phase 3：部門上線（第 9-16 週）

| 任務 | 交付物 |
|------|--------|
| 建立 SDK/模板 | 供部門建構 A2A 相容 agents |
| 文件化自註冊流程 | 合規要求文件 |
| 上線第一批部門團隊 | Engineering Tools、HR、Finance |
| 實現基於能力的路由 | Orchestrator 使用 registry 查詢 |

### Phase 4：生產強化（第 17-24 週）

| 任務 | 交付物 |
|------|--------|
| 新增語意搜尋 | Registry 的自然語言 agent 發現 |
| 實現速率限制和 SLA 強制執行 | 效能保障 |
| 建構 agent 版本控制和回滾能力 | 變更管理 |
| 建立棄用工作流程 | Agent 生命週期管理 |

---

## 十、總結與建議

### 核心結論

**是的，A2A Protocol 非常適合 M公司 的可擴展 Agent 生態系。** ✅

Google 的 A2A Protocol 為 M公司 的可擴展 agent 生態系提供了設計良好的基礎。**LangGraph 原生 A2A 支援**用於編排、**mcp-gateway-registry**（或自訂 fork）用於 agent 治理、**python-a2a** 用於快速 worker agent 開發的組合，提供了一條通往生產的實用路徑。

### 最重要的架構決策

設計你的 worker agents 以**內部使用 MCP 進行工具存取**，同時**對外暴露 A2A 進行 orchestrator 通訊**。這種分離允許部門獨立演進其內部實現，同時維持標準化的協作介面。

```
┌─────────────────────────────────────────────────────────────┐
│                    User Interface                            │
└──────────────────────────┬──────────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────────┐
│              LangGraph Orchestrator Agent                    │
│         (A2A Client + Dynamic Routing by Registry)          │
└──────────────────────────┬──────────────────────────────────┘
                           │ A2A Protocol
         ┌─────────────────┼─────────────────┐
         │                 │                 │
┌────────▼────────┐ ┌──────▼──────┐ ┌───────▼───────┐
│   Jira Agent    │ │  FAQ Agent  │ │ Gerrit Agent  │
│ ┌─────────────┐ │ │┌───────────┐│ │┌─────────────┐│
│ │ A2A Server  │ │ ││A2A Server ││ ││ A2A Server  ││
│ └──────┬──────┘ │ │└─────┬─────┘│ │└──────┬──────┘│
│        │        │ │      │      │ │       │       │
│ ┌──────▼──────┐ │ │┌─────▼─────┐│ │┌──────▼──────┐│
│ │ MCP Client  │ │ ││MCP Client ││ ││ MCP Client  ││
│ └──────┬──────┘ │ │└─────┬─────┘│ │└──────┬──────┘│
│        │        │ │      │      │ │       │       │
│ ┌──────▼──────┐ │ │┌─────▼─────┐│ │┌──────▼──────┐│
│ │  Jira API   │ │ ││ RAG/KB    ││ ││ Gerrit API  ││
│ └─────────────┘ │ │└───────────┘│ │└─────────────┘│
└─────────────────┘ └─────────────┘ └───────────────┘
         │                 │                 │
         └─────────────────┼─────────────────┘
                           │
              ┌────────────▼────────────┐
              │    Agent Registry       │
              │  (mcp-gateway-registry) │
              │  • Agent Discovery      │
              │  • Health Monitoring    │
              │  • Access Control       │
              └─────────────────────────┘
```

### 風險緩解建議

鑑於 A2A 的 pre-1.0 狀態，在內部介面後抽象協定細節以吸收未來的破壞性變更。Linux Foundation 治理和 100+ 合作夥伴生態系表明 A2A 將成為企業 agent 互操作性的主導標準——現在投資可以讓 M公司 走在前列。

### 快速決策指南

| 問題 | 建議 |
|------|------|
| 要不要採用 A2A？ | ✅ **是**，適合你的多部門可擴展架構 |
| A2A 還是 MCP？ | **兩者都用**：A2A 用於 agent 間通訊，MCP 用於工具整合 |
| 哪個 Registry？ | **mcp-gateway-registry** fork，或自建基於 PostgreSQL |
| 哪個 Orchestrator 框架？ | **LangGraph** with native A2A support |
| 部門如何貢獻 Agent？ | 提供 SDK 模板 + 自註冊流程 + 審批工作流程 |
