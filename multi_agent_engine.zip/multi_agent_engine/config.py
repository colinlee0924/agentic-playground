"""
config.py - 配置管理
"""
from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    """應用程式設定"""
    
    # 應用程式
    APP_NAME: str = "Multi-Agent Engine"
    DEBUG: bool = True
    
    # Phoenix Tracing
    PHOENIX_ENDPOINT: str = "http://localhost:6006/v1/traces"
    PHOENIX_PROJECT_NAME: str = "multi-agent-prototype"
    
    # LLM 設定 (根據你的環境調整)
    LLM_PROVIDER: str = "openai"  # openai, azure, ollama
    OPENAI_API_KEY: Optional[str] = None
    OPENAI_MODEL: str = "gpt-4"
    
    # Azure OpenAI (如果使用)
    AZURE_OPENAI_ENDPOINT: Optional[str] = None
    AZURE_OPENAI_API_KEY: Optional[str] = None
    AZURE_OPENAI_DEPLOYMENT: Optional[str] = None
    
    # Ollama (本地開發)
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_MODEL: str = "llama3.2"
    
    # Jira MCP Server (你已有的)
    JIRA_MCP_SERVER_URL: str = "http://localhost:3000"
    
    # PostgreSQL Database (Checkpointing)
    # 格式: postgresql://user:password@host:port/database
    POSTGRES_HOST: str = "localhost"
    POSTGRES_PORT: int = 5432
    POSTGRES_USER: str = "postgres"
    POSTGRES_PASSWORD: str = "postgres"
    POSTGRES_DB: str = "multi_agent"
    
    @property
    def postgres_connection_string(self) -> str:
        """PostgreSQL 連線字串 (sync)"""
        return f"postgresql://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}@{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
    
    @property
    def postgres_async_connection_string(self) -> str:
        """PostgreSQL 連線字串 (async) - 使用 psycopg"""
        return f"postgresql+psycopg://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}@{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
    
    class Config:
        env_file = ".env"
        extra = "ignore"

settings = Settings()
