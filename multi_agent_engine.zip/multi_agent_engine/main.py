# M公司 Multi-Agent Engine - Prototype Backend
# 檔案結構：
# multi_agent_engine/
# ├── main.py              # FastAPI 入口
# ├── config.py            # 配置
# ├── routers/
# │   ├── chat.py          # 聊天 API + SSE
# │   └── health.py        # 健康檢查
# ├── agents/
# │   ├── orchestrator.py  # Orchestrator Agent
# │   └── jira_agent.py    # Jira Agent (整合你現有的)
# ├── schemas/
# │   └── messages.py      # API Schema
# └── tracing/
#     └── phoenix.py       # Phoenix 整合

"""
main.py - FastAPI 入口點
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import logging

# Tracing 必須在其他 import 之前初始化
from tracing.phoenix import init_tracing
init_tracing()

from routers import chat, health
from config import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """應用程式生命週期管理"""
    logger.info("🚀 Multi-Agent Engine 啟動中...")
    logger.info(f"📊 Phoenix Tracing: {settings.PHOENIX_ENDPOINT}")
    yield
    logger.info("👋 Multi-Agent Engine 關閉")

app = FastAPI(
    title="M公司 Multi-Agent Engine",
    description="Orchestrator + Worker Agents 的後端服務",
    version="0.1.0-prototype",
    lifespan=lifespan
)

# CORS 設定 - 允許前端連接
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Production 請限制
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 註冊路由
app.include_router(health.router, tags=["Health"])
app.include_router(chat.router, prefix="/api", tags=["Chat"])

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
