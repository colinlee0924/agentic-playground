"""
routers/chat.py - 聊天 API + Streaming
支援 Open WebUI Pipe function 整合

Open WebUI 使用 Pipe function 連接後端，
streaming 使用 text/plain 而非 SSE
"""
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse, JSONResponse
from typing import AsyncGenerator, Optional, List
import json
import uuid
import asyncio
from datetime import datetime

from schemas.messages import (
    ChatRequest, ChatResponse, AgentStatusUpdate, 
    TokenChunk, ErrorResponse, AgentStatus,
    TrajectoryEvent, TrajectoryEventType
)
from agents.orchestrator import OrchestratorAgent

router = APIRouter()

# 全域 Orchestrator 實例
orchestrator = OrchestratorAgent()


# ========== Open WebUI 相容端點 ==========

@router.post("/chat")
async def chat(request: ChatRequest):
    """
    聊天端點 - 支援 streaming (Open WebUI 相容)
    
    支援兩種輸入格式：
    1. message: 單一訊息（向後相容）
    2. messages: 完整對話歷史（Open WebUI 格式）
    
    Open WebUI Pipe function 使用範例：
    ```python
    with httpx.Client() as client:
        with client.stream("POST", url, json={"messages": [...], "session_id": "..."}) as resp:
            for chunk in resp.iter_bytes():
                yield chunk.decode("utf-8")
    ```
    """
    conversation_id = request.conversation_id or str(uuid.uuid4())
    
    # 處理輸入格式
    if request.messages:
        # Open WebUI 格式: List[ChatMessage]
        messages = [{"role": m.role.value if hasattr(m.role, 'value') else m.role, "content": m.content} for m in request.messages]
    elif request.message:
        # 單一訊息（向後相容）
        messages = [{"role": "user", "content": request.message}]
    else:
        return JSONResponse(
            status_code=400,
            content={"error": "必須提供 message 或 messages"}
        )
    
    if request.stream:
        return StreamingResponse(
            stream_chat_response(messages, conversation_id),
            media_type="text/plain",  # Open WebUI Pipe 使用 text/plain
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
                "X-Conversation-ID": conversation_id
            }
        )
    else:
        # 非串流模式 - 等待完整結果
        result = await orchestrator.run(messages=messages, conversation_id=conversation_id)
        return ChatResponse(
            conversation_id=conversation_id,
            message=result["response"],
            agent="Orchestrator",
            execution_trace=result.get("trace")
        )


async def stream_chat_response(
    messages: List[dict], 
    conversation_id: str
) -> AsyncGenerator[str, None]:
    """
    Streaming 生成器 - 直接輸出文字（含思考過程）
    
    Open WebUI Pipe function 會逐 chunk 接收並顯示。
    思考過程用 Markdown 格式呈現，讓用戶看到 AI 的執行軌跡。
    
    Args:
        messages: 對話歷史 [{"role": "user", "content": "..."}, ...]
        conversation_id: 對話 ID
    """
    try:
        trajectory_lines = []  # 收集思考過程
        has_started_response = False
        has_yielded = False
        
        # 執行 Orchestrator 並串流結果
        async for event in orchestrator.stream(messages=messages, conversation_id=conversation_id):
            event_type = event.get("type")
            
            if event_type == "trajectory":
                # 收集思考過程事件
                trajectory_event = event.get("event", "")
                detail = event.get("detail", "")
                tool = event.get("tool")
                agent = event.get("agent")
                
                # 根據事件類型選擇 icon
                icon = {
                    "thinking": "🤔",
                    "routing": "🔀",
                    "agent_start": "📋",
                    "agent_end": "✅",
                    "tool_start": "🔧",
                    "tool_end": "✅",
                    "synthesizing": "📝",
                    "reasoning": "💭",
                }.get(trajectory_event, "•")
                
                trajectory_lines.append(f"{icon} {detail}")
            
            elif event_type == "token":
                # 第一個 token 前，先輸出思考過程區塊
                if not has_started_response and trajectory_lines:
                    thinking_block = format_thinking_block(trajectory_lines)
                    yield thinking_block
                    has_started_response = True
                
                # 輸出 token 內容
                content = event.get("content", "")
                if content:
                    yield content
                    has_yielded = True
            
            elif event_type == "done":
                # 完成事件，忽略
                pass
            
            elif event_type == "error":
                error_msg = event.get("message", "未知錯誤")
                yield f"\n❌ 錯誤: {error_msg}"
        
        if not has_yielded:
            yield "抱歉，我無法正確回應您的問題。請嘗試換個方式描述。"
            
    except Exception as e:
        yield f"\n❌ 處理請求時發生錯誤: {str(e)}"


def format_thinking_block(lines: List[str]) -> str:
    """
    格式化思考過程區塊
    
    使用 <details> 標籤（如果 Open WebUI 支援）或 blockquote 格式
    """
    # 方案 A: 使用 <details> 可折疊區塊
    block = "\n<details>\n<summary>💭 思考過程</summary>\n\n"
    for line in lines:
        block += f"- {line}\n"
    block += "\n</details>\n\n"
    
    # 方案 B（備用）: 使用 blockquote
    # block = "\n> 💭 **思考過程**\n>\n"
    # for line in lines:
    #     block += f"> {line}\n"
    # block += "\n---\n\n"
    
    return block


# ========== SSE 端點（給自訂前端使用）==========

@router.post("/chat/events")
async def chat_with_events(request: ChatRequest):
    """
    SSE 串流端點（含完整軌跡事件）
    
    提供 trajectory 事件讓前端展示「思考過程」，類似 ChatGPT/Claude 的展開區塊。
    
    事件類型：
    - trajectory: 執行軌跡（思考、路由、工具呼叫等）
    - token: LLM 輸出串流
    - done: 完成
    - error: 錯誤
    
    範例：
    ```
    event: trajectory
    data: {"event": "thinking", "detail": "正在分析您的問題..."}
    
    event: trajectory  
    data: {"event": "tool_start", "agent": "Jira Agent", "tool": "search_jira_tickets", "detail": "使用 search_jira_tickets 工具..."}
    
    event: token
    data: {"content": "根據"}
    
    event: done
    data: {"conversation_id": "..."}
    ```
    """
    conversation_id = request.conversation_id or str(uuid.uuid4())
    
    # 處理輸入格式
    if request.messages:
        messages = [{"role": m.role.value if hasattr(m.role, 'value') else m.role, "content": m.content} for m in request.messages]
    elif request.message:
        messages = [{"role": "user", "content": request.message}]
    else:
        return JSONResponse(
            status_code=400,
            content={"error": "必須提供 message 或 messages"}
        )
    
    return StreamingResponse(
        stream_events_response(messages, conversation_id),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
            "X-Conversation-ID": conversation_id
        }
    )


async def stream_events_response(
    messages: List[dict],
    conversation_id: str
) -> AsyncGenerator[str, None]:
    """
    SSE 串流生成器 - 包含完整軌跡事件
    
    給支援 SSE 的自訂前端使用，提供詳細的執行軌跡。
    """
    try:
        full_response = ""
        
        async for event in orchestrator.stream(messages=messages, conversation_id=conversation_id):
            event_type = event.get("type")
            
            if event_type == "trajectory":
                # 軌跡事件 - 直接傳送給前端
                yield format_sse_event("trajectory", {
                    "event": event.get("event"),
                    "agent": event.get("agent"),
                    "tool": event.get("tool"),
                    "detail": event.get("detail"),
                    "data": event.get("data")
                })
                
            elif event_type == "token":
                content = event.get("content", "")
                full_response += content
                yield format_sse_event("token", {"content": content})
            
            elif event_type == "done":
                pass  # 由下方統一發送
            
            elif event_type == "error":
                yield format_sse_event("error", {
                    "message": event.get("message", "未知錯誤")
                })
        
        # 發送完成事件
        yield format_sse_event("done", {
            "conversation_id": conversation_id,
            "message": full_response
        })
        
    except Exception as e:
        yield format_sse_event("error", {
            "message": "處理請求時發生錯誤",
            "detail": str(e)
        })


@router.post("/chat/sse")
async def chat_sse(request: ChatRequest):
    """
    SSE 串流端點（舊版，向後相容）
    
    建議使用 /chat/events 端點取得更豐富的軌跡事件
    """
    conversation_id = request.conversation_id or str(uuid.uuid4())
    
    # 處理輸入
    if request.messages:
        messages = [{"role": m.role.value if hasattr(m.role, 'value') else m.role, "content": m.content} for m in request.messages]
    elif request.message:
        messages = [{"role": "user", "content": request.message}]
    else:
        return JSONResponse(
            status_code=400,
            content={"error": "必須提供 message 或 messages"}
        )
    
    return StreamingResponse(
        stream_sse_response(messages, conversation_id),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
            "X-Conversation-ID": conversation_id
        }
    )


async def stream_sse_response(
    messages: List[dict], 
    conversation_id: str
) -> AsyncGenerator[str, None]:
    """
    SSE 串流生成器 - 簡化版（向後相容）
    """
    try:
        full_response = ""
        
        async for event in orchestrator.stream(messages=messages, conversation_id=conversation_id):
            event_type = event.get("type")
            
            if event_type == "trajectory":
                # 轉換為 status 事件（向後相容）
                yield format_sse_event("status", {
                    "agent": event.get("agent", "Orchestrator"),
                    "status": event.get("event"),
                    "detail": event.get("detail")
                })
                
            elif event_type == "token":
                content = event.get("content", "")
                full_response += content
                yield format_sse_event("token", {
                    "agent": "Orchestrator",
                    "content": content
                })
        
        yield format_sse_event("done", {
            "conversation_id": conversation_id,
            "message": full_response
        })
        
    except Exception as e:
        yield format_sse_event("error", {
            "message": "處理請求時發生錯誤",
            "detail": str(e)
        })


def format_sse_event(event_type: str, data: dict) -> str:
    """格式化 SSE 事件"""
    def json_serial(obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        raise TypeError(f"Type {type(obj)} not serializable")
    
    json_data = json.dumps(data, default=json_serial, ensure_ascii=False)
    return f"event: {event_type}\ndata: {json_data}\n\n"


# ========== 其他端點 ==========

@router.get("/conversations/{conversation_id}")
async def get_conversation(conversation_id: str):
    """取得對話歷史（如果有實作 checkpointing）"""
    return {
        "conversation_id": conversation_id,
        "messages": [],
        "status": "not_implemented_yet"
    }


@router.get("/agents")
async def list_agents():
    """列出可用的 Agents（供前端顯示）"""
    return {
        "agents": [
            {
                "id": "orchestrator",
                "name": "Orchestrator",
                "description": "主要協調者，負責理解請求並分派給專業 Agent"
            },
            {
                "id": "jira_agent", 
                "name": "Jira Agent",
                "description": "處理 Jira 相關查詢、建立和更新 tickets",
                "status": "active"
            },
            {
                "id": "faq_agent",
                "name": "FAQ Agent", 
                "description": "回答公司內部常見問題",
                "status": "coming_soon"
            }
        ]
    }
