"""
schemas/messages.py - API 訊息結構定義
"""
from pydantic import BaseModel, Field
from typing import Optional, List, Literal
from datetime import datetime
from enum import Enum

class MessageRole(str, Enum):
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"

class AgentStatus(str, Enum):
    IDLE = "idle"
    THINKING = "thinking"
    USING_TOOL = "using_tool"
    COMPLETED = "completed"
    ERROR = "error"

class TrajectoryEventType(str, Enum):
    """執行軌跡事件類型（給前端展示思考過程）"""
    THINKING = "thinking"           # 開始思考/分析
    ROUTING = "routing"             # 路由決策
    AGENT_START = "agent_start"     # Agent 開始執行
    AGENT_END = "agent_end"         # Agent 執行完成
    TOOL_START = "tool_start"       # 工具開始呼叫
    TOOL_END = "tool_end"           # 工具呼叫完成
    REASONING = "reasoning"         # LLM reasoning 片段
    SYNTHESIZING = "synthesizing"   # 整合回覆中

# ========== Request Schemas ==========

class ChatMessage(BaseModel):
    """單一聊天訊息"""
    role: MessageRole
    content: str
    timestamp: Optional[datetime] = None

class ChatRequest(BaseModel):
    """聊天請求"""
    message: Optional[str] = Field(None, description="使用者訊息（單一訊息，向後相容）")
    messages: Optional[List[ChatMessage]] = Field(None, description="完整對話歷史（Open WebUI 格式）")
    conversation_id: Optional[str] = Field(None, alias="session_id", description="對話 ID，用於多輪對話")
    stream: bool = Field(True, description="是否使用串流")
    
    class Config:
        populate_by_name = True  # 允許用 session_id 或 conversation_id

# ========== Response Schemas ==========

class TrajectoryEvent(BaseModel):
    """
    執行軌跡事件（給前端展示思考過程）
    
    前端可用此事件展示 AI 的「思考過程」，類似 ChatGPT/Claude 的展開區塊
    """
    type: Literal["trajectory"] = "trajectory"
    event: TrajectoryEventType
    agent: Optional[str] = Field(None, description="執行中的 Agent 名稱")
    tool: Optional[str] = Field(None, description="正在使用的工具名稱")
    detail: str = Field(..., description="人類可讀的狀態描述")
    data: Optional[dict] = Field(None, description="額外資料（工具輸入/輸出摘要）")
    timestamp: datetime = Field(default_factory=datetime.now)

class AgentStatusUpdate(BaseModel):
    """Agent 狀態更新（用於 SSE）"""
    type: Literal["status"] = "status"
    agent: str = Field(..., description="Agent 名稱，如 'Orchestrator', 'JiraAgent'")
    status: AgentStatus
    tool: Optional[str] = Field(None, description="正在使用的工具名稱")
    detail: Optional[str] = Field(None, description="額外細節")
    timestamp: datetime = Field(default_factory=datetime.now)

class TokenChunk(BaseModel):
    """LLM Token 串流（用於 SSE）"""
    type: Literal["token"] = "token"
    agent: str
    content: str
    timestamp: datetime = Field(default_factory=datetime.now)

class ChatResponse(BaseModel):
    """完整聊天回應（非串流模式）"""
    conversation_id: str
    message: str
    agent: str = "Orchestrator"
    execution_trace: Optional[List[AgentStatusUpdate]] = None

class ErrorResponse(BaseModel):
    """錯誤回應"""
    type: Literal["error"] = "error"
    message: str
    detail: Optional[str] = None

# ========== SSE Event Types ==========
# 前端需要處理的事件類型：
# - event: trajectory → TrajectoryEvent (思考過程，可展示給用戶)
# - event: status     → AgentStatusUpdate (內部狀態)
# - event: token      → TokenChunk (LLM 輸出串流)
# - event: done       → ChatResponse (最終結果)
# - event: error      → ErrorResponse
