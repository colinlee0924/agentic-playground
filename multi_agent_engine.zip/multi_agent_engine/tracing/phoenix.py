"""
tracing/phoenix.py - Arize Phoenix 可觀測性整合

這個模組負責：
1. 初始化 OpenTelemetry tracing
2. 自動追蹤 LangChain/LangGraph 執行
3. 發送 traces 到自託管的 Phoenix server
"""
import logging
from config import settings

logger = logging.getLogger(__name__)

def init_tracing():
    """
    初始化 Phoenix tracing
    
    必須在 import LangChain/LangGraph 之前呼叫！
    """
    try:
        from phoenix.otel import register
        
        tracer_provider = register(
            project_name=settings.PHOENIX_PROJECT_NAME,
            auto_instrument=True,  # 自動偵測並追蹤 LangChain/LangGraph
            endpoint=settings.PHOENIX_ENDPOINT
        )
        
        logger.info(f"✅ Phoenix tracing 已啟用")
        logger.info(f"   Project: {settings.PHOENIX_PROJECT_NAME}")
        logger.info(f"   Endpoint: {settings.PHOENIX_ENDPOINT}")
        
        return tracer_provider
        
    except ImportError:
        logger.warning("⚠️ Phoenix 未安裝，tracing 已停用")
        logger.warning("   安裝方式: pip install arize-phoenix-otel")
        return None
    except Exception as e:
        logger.error(f"❌ Phoenix tracing 初始化失敗: {e}")
        return None


def get_tracer(name: str = __name__):
    """取得 tracer 實例（用於手動埋點）"""
    try:
        from opentelemetry import trace
        return trace.get_tracer(name)
    except ImportError:
        return None


# ========== 手動埋點輔助函數 ==========

def trace_agent_call(agent_name: str, method: str = "run"):
    """
    Agent 呼叫追蹤裝飾器
    
    使用範例：
    @trace_agent_call("JiraAgent", "search")
    async def search_tickets(query: str):
        ...
    """
    def decorator(func):
        async def wrapper(*args, **kwargs):
            tracer = get_tracer()
            if tracer:
                with tracer.start_as_current_span(f"{agent_name}.{method}") as span:
                    span.set_attribute("agent.name", agent_name)
                    span.set_attribute("agent.method", method)
                    try:
                        result = await func(*args, **kwargs)
                        span.set_attribute("agent.status", "success")
                        return result
                    except Exception as e:
                        span.set_attribute("agent.status", "error")
                        span.set_attribute("agent.error", str(e))
                        raise
            else:
                return await func(*args, **kwargs)
        return wrapper
    return decorator


def trace_tool_call(tool_name: str):
    """
    工具呼叫追蹤裝飾器
    
    使用範例：
    @trace_tool_call("search_jira_tickets")
    async def search_jira_tickets(query: str):
        ...
    """
    def decorator(func):
        async def wrapper(*args, **kwargs):
            tracer = get_tracer()
            if tracer:
                with tracer.start_as_current_span(f"tool.{tool_name}") as span:
                    span.set_attribute("tool.name", tool_name)
                    span.set_attribute("tool.input", str(kwargs)[:500])
                    try:
                        result = await func(*args, **kwargs)
                        span.set_attribute("tool.status", "success")
                        span.set_attribute("tool.output_length", len(str(result)))
                        return result
                    except Exception as e:
                        span.set_attribute("tool.status", "error")
                        span.set_attribute("tool.error", str(e))
                        raise
            else:
                return await func(*args, **kwargs)
        return wrapper
    return decorator


# ========== A2A 跨 Agent 追蹤（未來擴展）==========

def inject_trace_context(headers: dict) -> dict:
    """
    注入 trace context 到 HTTP headers（用於 A2A 通訊）
    
    使用範例：
    headers = inject_trace_context({"Content-Type": "application/json"})
    await session.post(worker_url, headers=headers, ...)
    """
    try:
        from opentelemetry.propagate import inject
        inject(headers)
        return headers
    except ImportError:
        return headers


def extract_trace_context(headers: dict):
    """
    從 HTTP headers 提取 trace context（用於 A2A 通訊）
    
    在 Worker Agent 端使用：
    context = extract_trace_context(request.headers)
    """
    try:
        from opentelemetry.propagate import extract
        return extract(headers)
    except ImportError:
        return None
