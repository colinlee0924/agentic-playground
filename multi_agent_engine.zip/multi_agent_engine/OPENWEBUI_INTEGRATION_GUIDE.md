# Open WebUI + Multi-Agent Engine 整合指南
## 給 Jimmy 的前端串接文件

> 版本: v0.1.0-prototype
> 更新日期: 2024/12/08
> 後端負責人: Colin
> 前端負責人: Jimmy

---

## 🎯 整合架構

```
┌─────────────────────────────────────────────────────────────┐
│                      Open WebUI                              │
│                   (http://localhost:3001)                    │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              Pipe Function                           │   │
│  │         "M公司 AI 助手"                              │   │
│  │                                                      │   │
│  │  • 提取使用者訊息                                    │   │
│  │  • 轉發到 FastAPI 後端                               │   │
│  │  • 串流顯示回應                                      │   │
│  └──────────────────────┬──────────────────────────────┘   │
│                         │                                   │
└─────────────────────────┼───────────────────────────────────┘
                          │ HTTP POST (streaming)
                          ▼
┌─────────────────────────────────────────────────────────────┐
│                 Multi-Agent Engine                           │
│                (http://localhost:8000)                       │
│                                                             │
│  ┌──────────────────┐    ┌──────────────────────────────┐  │
│  │    FastAPI       │───▶│    Orchestrator Agent        │  │
│  │   /api/chat      │    │    (LangGraph)               │  │
│  └──────────────────┘    └──────────────┬───────────────┘  │
│                                         │                   │
│                          ┌──────────────┴──────────────┐   │
│                          ▼                             ▼   │
│                    ┌──────────┐                 ┌──────────┐│
│                    │  Jira    │                 │   FAQ    ││
│                    │  Agent   │                 │  Agent   ││
│                    └──────────┘                 └──────────┘│
└─────────────────────────────────────────────────────────────┘
```

---

## 📋 整合步驟

### Step 1: 確認後端已啟動

```bash
# 1. 啟動 PostgreSQL (對話狀態持久化)
docker run -d --name postgres-multiagent \
  -e POSTGRES_USER=postgres \
  -e POSTGRES_PASSWORD=postgres \
  -e POSTGRES_DB=multi_agent \
  -p 5432:5432 \
  postgres:16

# 2. Colin 的 Multi-Agent Engine
cd multi_agent_engine
pip install -r requirements.txt
python main.py

# 確認服務運行中
curl http://localhost:8000/health
# 應該回傳: {"status": "healthy", ...}
```

### Step 2: 在 Open WebUI 新增 Pipe Function

1. 開啟 Open WebUI: `http://localhost:3001`
2. 點擊右上角頭像 → **Admin Panel**
3. 進入 **Functions** 分頁
4. 點擊 **"+"** 新增 function
5. **複製 `openwebui_pipe_function.py` 的內容貼上**
6. 點擊 **Save**

### Step 3: 使用 M公司 AI 助手

1. 回到聊天頁面
2. 在模型選單中選擇 **"M公司 AI 助手"**
3. 開始對話！

---

## 📁 檔案說明

| 檔案 | 說明 |
|------|------|
| `openwebui_pipe_function.py` | 👈 **Jimmy 要用的！** Open WebUI Pipe Function 程式碼 |
| `main.py` | FastAPI 後端入口 |
| `routers/chat.py` | 聊天 API（支援 text/plain streaming） |

---

## 🔌 API 規格

### POST /api/chat (Open WebUI 相容)

**Request:**
```json
{
  "messages": [
    {"role": "user", "content": "我要查 DEMO 專案的 tickets"},
    {"role": "assistant", "content": "找到 3 個 tickets..."},
    {"role": "user", "content": "第一個的詳細資訊？"}
  ],
  "session_id": "open-webui-chat-id",
  "stream": true
}
```

**Response (stream=true):**
- Content-Type: `text/plain`
- 包含**思考過程區塊** + 實際回覆

**輸出範例（含思考過程）：**
```markdown
<details>
<summary>💭 思考過程</summary>

- 🤔 正在分析您的問題...
- 🔀 判斷需要使用 Jira Agent 來處理
- 📋 呼叫 Jira Agent 查詢資料...
- 🔧 使用 search_jira_tickets 工具...
- ✅ Jira Agent 查詢完成
- 📝 整理回覆中...

</details>

根據查詢，DEMO 專案目前有 3 個 Open 狀態的 tickets...
```

### POST /api/chat/events (SSE 格式，給自訂前端)

提供完整軌跡事件，前端可自行處理展示邏輯。

**SSE 事件格式：**
```
event: trajectory
data: {"event": "thinking", "detail": "正在分析您的問題..."}

event: trajectory
data: {"event": "tool_start", "agent": "Jira Agent", "tool": "search_jira_tickets"}

event: token
data: {"content": "根據"}

event: done
data: {"conversation_id": "...", "message": "完整回覆內容"}
```

**軌跡事件類型：**

| event | 說明 | Icon |
|-------|------|------|
| `thinking` | 開始分析 | 🤔 |
| `routing` | 路由決策 | 🔀 |
| `agent_start` | Agent 開始執行 | 📋 |
| `agent_end` | Agent 執行完成 | ✅ |
| `tool_start` | 工具開始呼叫 | 🔧 |
| `tool_end` | 工具呼叫完成 | ✅ |
| `synthesizing` | 整合回覆中 | 📝 |

---

## 🔄 多輪對話架構

```
┌─────────────────────────────────────────────────────────────┐
│                      Open WebUI                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  內建對話管理 (SQLite)                               │    │
│  │  • 儲存 UI 顯示的所有 messages                       │    │
│  │  • 每次請求傳送完整 messages[] 給後端                │    │
│  └──────────────────────┬──────────────────────────────┘    │
└─────────────────────────┼───────────────────────────────────┘
                          │ POST /api/chat
                          │ { "messages": [...], "session_id": "..." }
                          ▼
┌─────────────────────────────────────────────────────────────┐
│              Multi-Agent Engine (FastAPI)                    │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  PostgreSQL Checkpointer                             │    │
│  │  • 儲存 LangGraph 狀態                               │    │
│  │  • 支援 Agent 中間結果、長期記憶                      │    │
│  │  • thread_id = session_id                           │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Orchestrator Agent                                  │    │
│  │  • 接收完整 messages[] 作為上下文                    │    │
│  │  • 多輪對話理解                                      │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

**為什麼需要兩層？**
- **Open WebUI**: 管理 UI 顯示、使用者互動
- **PostgreSQL Checkpointer**: 管理 Agent 執行狀態、中間結果、跨 session 記憶

---

## 🔧 Pipe Function 設定

在 Open WebUI 的 Pipe 設定中可以調整：

| 參數 | 預設值 | 說明 |
|------|--------|------|
| `FASTAPI_BASE_URL` | `http://127.0.0.1:8000` | 後端 URL |
| `API_PATH` | `/api/chat` | API 端點路徑 |
| `SHOW_THINKING` | `true` | 是否顯示 AI 思考過程（可折疊區塊） |
| `READ_TIMEOUT` | `120.0` | 讀取超時（秒） |

如果後端部署在其他位置，修改 `FASTAPI_BASE_URL` 即可。

---

## 🧪 測試

### 1. 測試後端 API

```bash
# 非串流模式
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "查詢我的 Jira tickets", "stream": false}'

# 串流模式
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "查詢我的 Jira tickets", "stream": true}'
```

### 2. 測試 Open WebUI 整合

1. 在 Open WebUI 選擇 "M公司 AI 助手"
2. 輸入: "幫我查詢 DEMO 專案的 tickets"
3. 應該看到串流回應

---

## 📅 串接時程

| 日期 | 里程碑 | 狀態 |
|------|--------|------|
| 12/8 (一) 晚上 | Colin 完成 FastAPI 後端 | 🔵 進行中 |
| 12/9 (二) 上午 | Colin 交付後端 + Pipe Function | ⏳ 待進行 |
| 12/9 (二) 上午 | Jimmy 將 Pipe Function 加入 Open WebUI | ⏳ 待進行 |
| 12/9 (二) 下午 | **首次串接測試** 🤝 | ⏳ 待進行 |
| 12/10 (三) | 調整 UI 顯示、錯誤處理 | ⏳ 待進行 |
| 12/12 (五) | **Prototype 交付** | ⏳ 待進行 |

---

## ❓ FAQ

### Q: 看到 "無法連接到後端服務" 錯誤？

**A:** 確認 Multi-Agent Engine 已啟動：
```bash
python main.py
```

### Q: 串流沒有即時顯示？

**A:** 檢查 Open WebUI 設定，確保沒有開啟 response buffering。

### Q: 想顯示 Agent 執行狀態（如 "Jira Agent 使用 search 工具..."）？

**A:** 預設已啟用！回覆會包含可折疊的「思考過程」區塊。如果 Open WebUI 不支援 `<details>` 標籤，可以修改 `routers/chat.py` 中的 `format_thinking_block` 函數改用 blockquote 格式。

### Q: 想關閉思考過程顯示？

**A:** 在 Open WebUI 的 Pipe Function 設定中，將 `SHOW_THINKING` 設為 `false`。

### Q: 需要 SSE 格式的串流？

**A:** 使用 `/api/chat/events` 端點，提供完整的 trajectory 事件，適合自訂前端使用。

---

## 📞 問題回報

有任何問題請聯繫 Colin 或在 Teams/Slack 群組討論。

**後端測試指令：**
```bash
# 健康檢查
curl http://localhost:8000/health

# 列出 Agents
curl http://localhost:8000/api/agents

# 測試聊天
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello", "stream": false}'
```
