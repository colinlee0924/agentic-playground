# M公司 Multi-Agent Engine

> Prototype 版本 - 2024/12/08

Multi-Agent 後端服務，提供 Orchestrator + Worker Agents 架構。
**支援 Open WebUI Pipe Function 整合。**

## 🏗️ 架構

```
┌──────────────────────────────────────────────────────────┐
│                  Multi-Agent Engine                       │
│                                                          │
│  ┌─────────────┐     ┌─────────────────────────────┐    │
│  │   FastAPI   │────▶│    Orchestrator Agent       │    │
│  │  (Gateway)  │     │    (LangGraph Supervisor)   │    │
│  └─────────────┘     └──────────────┬──────────────┘    │
│        ▲                            │                    │
│        │ HTTP                       │ Route              │
│        │ Streaming                  ▼                    │
│  ┌─────────────┐     ┌─────────────────────────────┐    │
│  │ Open WebUI  │     │      Worker Agents          │    │
│  │   (Pipe)    │     │  ┌──────────┐ ┌──────────┐  │    │
│  └─────────────┘     │  │  Jira    │ │   FAQ    │  │    │
│                      │  │  Agent   │ │  Agent   │  │    │
│                      │  └──────────┘ └──────────┘  │    │
│                      └─────────────────────────────┘    │
│                                                          │
│  ┌─────────────────────────────────────────────────┐    │
│  │              Arize Phoenix (Tracing)             │    │
│  └─────────────────────────────────────────────────┘    │
└──────────────────────────────────────────────────────────┘
```

## 🚀 快速開始

### 1. 環境設定

```bash
# 建立虛擬環境
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 安裝依賴
pip install -r requirements.txt

# 複製環境變數
cp .env.example .env
# 編輯 .env 設定你的 API keys
```

### 2. 啟動 PostgreSQL（對話狀態持久化）

```bash
# Docker 啟動 PostgreSQL
docker run -d --name postgres-multiagent \
  -e POSTGRES_USER=postgres \
  -e POSTGRES_PASSWORD=postgres \
  -e POSTGRES_DB=multi_agent \
  -p 5432:5432 \
  postgres:16
```

### 3. 啟動 Phoenix（可觀測性，選用）

```bash
docker run -d -p 6006:6006 arizephoenix/phoenix:latest
```

### 4. 啟動服務

```bash
python main.py
# 或
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

服務啟動後：
- API: http://localhost:8000
- API 文件: http://localhost:8000/docs
- Phoenix: http://localhost:6006 (如有啟動)

### 4. 整合 Open WebUI

參考 `OPENWEBUI_INTEGRATION_GUIDE.md`，將 `openwebui_pipe_function.py` 加入 Open WebUI。

## 📡 API 端點

| 端點 | 方法 | 說明 |
|------|------|------|
| `/api/chat` | POST | 聊天（text/plain streaming，相容 Open WebUI） |
| `/api/chat/sse` | POST | SSE 串流（status/token/done 事件） |
| `/api/agents` | GET | 列出可用 Agents |
| `/health` | GET | 健康檢查 |

## 📁 專案結構

```
multi_agent_engine/
├── main.py                          # FastAPI 入口
├── config.py                        # 配置管理
├── requirements.txt                 # 依賴
├── .env.example                     # 環境變數範本
├── openwebui_pipe_function.py       # 👈 Open WebUI Pipe Function
├── OPENWEBUI_INTEGRATION_GUIDE.md   # 👈 給 Jimmy 的整合指南
├── COLIN_MILESTONE_BREAKDOWN.md     # Colin 個人 Milestone
├── routers/
│   ├── chat.py                      # 聊天 API + Streaming
│   └── health.py                    # 健康檢查
├── agents/
│   ├── orchestrator.py              # Orchestrator Agent
│   └── jira_agent.py                # Jira Agent
├── schemas/
│   └── messages.py                  # API Schema
├── tracing/
│   └── phoenix.py                   # Phoenix 整合
└── docs/
    └── ...                          # 研究報告與計劃文件
```

## 🧪 測試

```bash
# 健康檢查
curl http://localhost:8000/health

# 非串流測試
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "查詢 DEMO 專案的 tickets", "stream": false}'

# 串流測試
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello", "stream": true}'
```

## 👥 負責人

- Multi-Agent Engine: Colin
- UI Frontend (Open WebUI): Jimmy
- FAQ Agent: [同事名]
