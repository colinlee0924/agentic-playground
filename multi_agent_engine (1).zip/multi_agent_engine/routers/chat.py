"""
routers/chat.py - 聊天 API + SSE 串流
這是前端串接的核心端點
"""
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from typing import AsyncGenerator
import json
import uuid
import asyncio
from datetime import datetime

from schemas.messages import (
    ChatRequest, ChatResponse, AgentStatusUpdate, 
    TokenChunk, ErrorResponse, AgentStatus
)
from agents.orchestrator import OrchestratorAgent

router = APIRouter()

# 全域 Orchestrator 實例
orchestrator = OrchestratorAgent()

@router.post("/chat")
async def chat(request: ChatRequest):
    """
    聊天端點 - 支援 SSE 串流
    
    前端使用範例：
    ```javascript
    const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: "查詢我的 Jira tickets", stream: true })
    });
    
    const reader = response.body.getReader();
    // 處理 SSE 事件...
    ```
    """
    conversation_id = request.conversation_id or str(uuid.uuid4())
    
    if request.stream:
        return StreamingResponse(
            stream_chat_response(request.message, conversation_id),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",  # 關閉 nginx buffering
                "X-Conversation-ID": conversation_id
            }
        )
    else:
        # 非串流模式 - 等待完整結果
        result = await orchestrator.run(request.message, conversation_id)
        return ChatResponse(
            conversation_id=conversation_id,
            message=result["response"],
            agent="Orchestrator",
            execution_trace=result.get("trace")
        )

async def stream_chat_response(
    message: str, 
    conversation_id: str
) -> AsyncGenerator[str, None]:
    """
    SSE 串流生成器
    
    事件格式：
    event: status
    data: {"type": "status", "agent": "JiraAgent", "status": "using_tool", "tool": "search_tickets"}
    
    event: token
    data: {"type": "token", "agent": "Orchestrator", "content": "根據"}
    
    event: done
    data: {"conversation_id": "...", "message": "完整回應..."}
    
    event: error
    data: {"type": "error", "message": "錯誤訊息"}
    """
    try:
        # 發送開始狀態
        yield format_sse_event("status", AgentStatusUpdate(
            agent="Orchestrator",
            status=AgentStatus.THINKING,
            detail="分析使用者請求中..."
        ).model_dump())
        
        full_response = ""
        trace = []
        
        # 執行 Orchestrator 並串流結果
        async for event in orchestrator.stream(message, conversation_id):
            event_type = event.get("type")
            
            if event_type == "status":
                # Agent 狀態更新
                status_update = AgentStatusUpdate(
                    agent=event.get("agent", "Unknown"),
                    status=AgentStatus(event.get("status", "thinking")),
                    tool=event.get("tool"),
                    detail=event.get("detail")
                )
                trace.append(status_update)
                yield format_sse_event("status", status_update.model_dump())
                
            elif event_type == "token":
                # LLM Token 串流
                content = event.get("content", "")
                full_response += content
                yield format_sse_event("token", TokenChunk(
                    agent=event.get("agent", "Orchestrator"),
                    content=content
                ).model_dump())
                
            elif event_type == "tool_result":
                # 工具執行結果（可選是否顯示給前端）
                yield format_sse_event("tool_result", {
                    "agent": event.get("agent"),
                    "tool": event.get("tool"),
                    "result_preview": str(event.get("result", ""))[:200]
                })
        
        # 發送完成事件
        yield format_sse_event("done", {
            "conversation_id": conversation_id,
            "message": full_response,
            "trace": [t.model_dump() for t in trace]
        })
        
    except Exception as e:
        # 發送錯誤事件
        yield format_sse_event("error", ErrorResponse(
            message="處理請求時發生錯誤",
            detail=str(e)
        ).model_dump())

def format_sse_event(event_type: str, data: dict) -> str:
    """格式化 SSE 事件"""
    # 確保 datetime 可以序列化
    def json_serial(obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        raise TypeError(f"Type {type(obj)} not serializable")
    
    json_data = json.dumps(data, default=json_serial, ensure_ascii=False)
    return f"event: {event_type}\ndata: {json_data}\n\n"

# ========== 額外端點 ==========

@router.get("/conversations/{conversation_id}")
async def get_conversation(conversation_id: str):
    """取得對話歷史（如果有實作 checkpointing）"""
    # TODO: 從 checkpoint 讀取對話歷史
    return {
        "conversation_id": conversation_id,
        "messages": [],
        "status": "not_implemented_yet"
    }

@router.get("/agents")
async def list_agents():
    """列出可用的 Agents（供前端顯示）"""
    return {
        "agents": [
            {
                "id": "orchestrator",
                "name": "Orchestrator",
                "description": "主要協調者，負責理解請求並分派給專業 Agent"
            },
            {
                "id": "jira_agent", 
                "name": "Jira Agent",
                "description": "處理 Jira 相關查詢、建立和更新 tickets",
                "status": "active"
            },
            {
                "id": "faq_agent",
                "name": "FAQ Agent", 
                "description": "回答公司內部常見問題",
                "status": "coming_soon"  # 等同事完成
            }
        ]
    }
