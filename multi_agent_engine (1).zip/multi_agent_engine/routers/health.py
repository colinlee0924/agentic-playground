"""
routers/health.py - 健康檢查端點
"""
from fastapi import APIRouter
from datetime import datetime

router = APIRouter()

@router.get("/health")
async def health_check():
    """基本健康檢查"""
    return {
        "status": "healthy",
        "service": "Multi-Agent Engine",
        "timestamp": datetime.now().isoformat()
    }

@router.get("/ready")
async def readiness_check():
    """就緒檢查 - 確認所有依賴服務"""
    checks = {
        "phoenix": await check_phoenix(),
        "jira_mcp": await check_jira_mcp(),
    }
    
    all_ready = all(checks.values())
    
    return {
        "ready": all_ready,
        "checks": checks,
        "timestamp": datetime.now().isoformat()
    }

async def check_phoenix() -> bool:
    """檢查 Phoenix 連線"""
    try:
        import aiohttp
        from config import settings
        async with aiohttp.ClientSession() as session:
            async with session.get(
                settings.PHOENIX_ENDPOINT.replace("/v1/traces", "/health"),
                timeout=aiohttp.ClientTimeout(total=2)
            ) as resp:
                return resp.status == 200
    except:
        return False

async def check_jira_mcp() -> bool:
    """檢查 Jira MCP Server 連線"""
    try:
        import aiohttp
        from config import settings
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"{settings.JIRA_MCP_SERVER_URL}/health",
                timeout=aiohttp.ClientTimeout(total=2)
            ) as resp:
                return resp.status == 200
    except:
        # MCP Server 可能沒有 /health endpoint，暫時返回 True
        return True
