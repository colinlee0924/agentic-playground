"""
schemas/messages.py - API 訊息結構定義
"""
from pydantic import BaseModel, Field
from typing import Optional, List, Literal
from datetime import datetime
from enum import Enum

class MessageRole(str, Enum):
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"

class AgentStatus(str, Enum):
    IDLE = "idle"
    THINKING = "thinking"
    USING_TOOL = "using_tool"
    COMPLETED = "completed"
    ERROR = "error"

# ========== Request Schemas ==========

class ChatMessage(BaseModel):
    """單一聊天訊息"""
    role: MessageRole
    content: str
    timestamp: Optional[datetime] = None

class ChatRequest(BaseModel):
    """聊天請求"""
    message: str = Field(..., description="使用者訊息")
    conversation_id: Optional[str] = Field(None, description="對話 ID，用於多輪對話")
    stream: bool = Field(True, description="是否使用 SSE 串流")

# ========== Response Schemas ==========

class AgentStatusUpdate(BaseModel):
    """Agent 狀態更新（用於 SSE）"""
    type: Literal["status"] = "status"
    agent: str = Field(..., description="Agent 名稱，如 'Orchestrator', 'JiraAgent'")
    status: AgentStatus
    tool: Optional[str] = Field(None, description="正在使用的工具名稱")
    detail: Optional[str] = Field(None, description="額外細節")
    timestamp: datetime = Field(default_factory=datetime.now)

class TokenChunk(BaseModel):
    """LLM Token 串流（用於 SSE）"""
    type: Literal["token"] = "token"
    agent: str
    content: str
    timestamp: datetime = Field(default_factory=datetime.now)

class ChatResponse(BaseModel):
    """完整聊天回應（非串流模式）"""
    conversation_id: str
    message: str
    agent: str = "Orchestrator"
    execution_trace: Optional[List[AgentStatusUpdate]] = None

class ErrorResponse(BaseModel):
    """錯誤回應"""
    type: Literal["error"] = "error"
    message: str
    detail: Optional[str] = None

# ========== SSE Event Types ==========
# 前端需要處理的事件類型：
# - event: status  → AgentStatusUpdate
# - event: token   → TokenChunk  
# - event: done    → ChatResponse (最終結果)
# - event: error   → ErrorResponse
