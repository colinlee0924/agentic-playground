# M公司 Multi-Agent Engine

> Prototype 版本 - 2024/12/08

Multi-Agent 後端服務，提供 Orchestrator + Worker Agents 架構。

## 🏗️ 架構

```
┌──────────────────────────────────────────────────────────┐
│                  Multi-Agent Engine                       │
│                                                          │
│  ┌─────────────┐     ┌─────────────────────────────┐    │
│  │   FastAPI   │────▶│    Orchestrator Agent       │    │
│  │  (Gateway)  │     │    (LangGraph Supervisor)   │    │
│  └─────────────┘     └──────────────┬──────────────┘    │
│        │                            │                    │
│        │ SSE                        │ Route              │
│        ▼                            ▼                    │
│  ┌─────────────┐     ┌─────────────────────────────┐    │
│  │   Frontend  │     │      Worker Agents          │    │
│  │  (React)    │     │  ┌──────────┐ ┌──────────┐  │    │
│  └─────────────┘     │  │  Jira    │ │   FAQ    │  │    │
│                      │  │  Agent   │ │  Agent   │  │    │
│                      │  └──────────┘ └──────────┘  │    │
│                      └─────────────────────────────┘    │
│                                                          │
│  ┌─────────────────────────────────────────────────┐    │
│  │              Arize Phoenix (Tracing)             │    │
│  └─────────────────────────────────────────────────┘    │
└──────────────────────────────────────────────────────────┘
```

## 🚀 快速開始

### 1. 環境設定

```bash
# 建立虛擬環境
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 安裝依賴
pip install -r requirements.txt

# 複製環境變數
cp .env.example .env
# 編輯 .env 設定你的 API keys
```

### 2. 啟動 Phoenix（可觀測性）

```bash
# 方法 1: Docker
docker run -d -p 6006:6006 arizephoenix/phoenix:latest

# 方法 2: Python
pip install arize-phoenix
phoenix serve
```

開啟 http://localhost:6006 查看 traces

### 3. 啟動服務

```bash
# 開發模式（自動重載）
python main.py

# 或使用 uvicorn
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

服務啟動後：
- API: http://localhost:8000
- API 文件: http://localhost:8000/docs
- Phoenix: http://localhost:6006

## 📡 API 端點

### POST /api/chat

聊天端點，支援 SSE 串流。

**Request:**
```json
{
  "message": "查詢我的 Jira tickets",
  "conversation_id": "optional-uuid",
  "stream": true
}
```

**SSE Events:**
```
event: status
data: {"type": "status", "agent": "JiraAgent", "status": "using_tool", "tool": "search_tickets"}

event: token
data: {"type": "token", "agent": "Orchestrator", "content": "根據查詢結果..."}

event: done
data: {"conversation_id": "...", "message": "完整回應"}
```

### GET /api/agents

列出可用的 Agents。

### GET /health

健康檢查。

## 🔧 配置

編輯 `.env` 檔案：

```env
# LLM Provider: openai, azure, ollama
LLM_PROVIDER=openai
OPENAI_API_KEY=sk-xxx
OPENAI_MODEL=gpt-4

# Phoenix
PHOENIX_ENDPOINT=http://localhost:6006/v1/traces
PHOENIX_PROJECT_NAME=multi-agent-prototype

# Jira MCP Server
JIRA_MCP_SERVER_URL=http://localhost:3000
```

## 📁 專案結構

```
multi_agent_engine/
├── main.py              # FastAPI 入口
├── config.py            # 配置管理
├── requirements.txt     # 依賴
├── .env.example         # 環境變數範本
├── routers/
│   ├── chat.py          # 聊天 API + SSE
│   └── health.py        # 健康檢查
├── agents/
│   ├── orchestrator.py  # Orchestrator Agent
│   └── jira_agent.py    # Jira Agent
├── schemas/
│   └── messages.py      # API Schema
└── tracing/
    └── phoenix.py       # Phoenix 整合
```

## 🧪 測試

```bash
# 執行測試
pytest

# 手動測試 API
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "查詢 DEMO 專案的 tickets", "stream": false}'
```

## 📋 Milestone

- [x] FastAPI 骨架 + SSE streaming
- [x] Phoenix tracing 整合
- [x] Orchestrator Agent 基礎
- [x] Jira Agent 基礎（MCP 整合）
- [ ] 前端串接測試
- [ ] FAQ Agent 整合（同事負責）
- [ ] A2A Protocol 標準化
- [ ] Agent Registry
- [ ] Production 部署

## 👥 負責人

- Multi-Agent Engine: Colin
- UI Frontend: Jimmy
- FAQ Agent: [同事名]
