"""
agents/orchestrator.py - Orchestrator Agent
使用 LangGraph 實現的主要協調者

職責：
1. 理解使用者請求
2. 決定路由到哪個 Worker Agent
3. 彙整結果回覆使用者
4. 發送狀態更新到 SSE 串流
"""
from typing import AsyncGenerator, Dict, Any, List, Literal
from dataclasses import dataclass
import asyncio
import logging

from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langgraph.graph import StateGraph, MessagesState, START, END
from langgraph.checkpoint.sqlite import SqliteSaver

from agents.jira_agent import JiraAgent
from config import settings

logger = logging.getLogger(__name__)

# Orchestrator 的系統提示詞
ORCHESTRATOR_SYSTEM_PROMPT = """你是 M公司 的 AI 助手協調者（Orchestrator）。

你的職責是：
1. 理解使用者的請求
2. 判斷需要哪個專業 Agent 來處理
3. 將任務委派給適當的 Agent
4. 彙整結果，用清晰的中文回覆使用者

可用的專業 Agents：
- **Jira Agent**: 處理 Jira 相關任務，包括：
  - 查詢 tickets（搜尋、篩選、取得詳情）
  - 建立新 ticket
  - 更新 ticket 狀態
  - 查詢專案資訊

- **FAQ Agent**: 回答公司內部常見問題（開發中）

路由規則：
- 如果使用者詢問 Jira、ticket、issue、bug、任務、專案進度相關 → 使用 Jira Agent
- 如果使用者詢問公司政策、流程、常見問題 → 使用 FAQ Agent（目前不可用，請告知使用者）
- 如果不確定或是一般對話 → 直接回覆

回覆風格：
- 使用繁體中文
- 簡潔但完整
- 如果有 ticket 資訊，請用結構化方式呈現
"""

class OrchestratorAgent:
    """Orchestrator Agent - 主要協調者"""
    
    def __init__(self):
        self.jira_agent = JiraAgent()
        self.llm = self._create_llm()
        self.graph = self._build_graph()
        logger.info("Orchestrator Agent 初始化完成")
    
    def _create_llm(self):
        """根據配置建立 LLM 實例"""
        if settings.LLM_PROVIDER == "openai":
            from langchain_openai import ChatOpenAI
            return ChatOpenAI(
                model=settings.OPENAI_MODEL,
                api_key=settings.OPENAI_API_KEY,
                streaming=True
            )
        elif settings.LLM_PROVIDER == "azure":
            from langchain_openai import AzureChatOpenAI
            return AzureChatOpenAI(
                azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
                api_key=settings.AZURE_OPENAI_API_KEY,
                deployment_name=settings.AZURE_OPENAI_DEPLOYMENT,
                streaming=True
            )
        elif settings.LLM_PROVIDER == "ollama":
            from langchain_ollama import ChatOllama
            return ChatOllama(
                base_url=settings.OLLAMA_BASE_URL,
                model=settings.OLLAMA_MODEL
            )
        else:
            raise ValueError(f"不支援的 LLM Provider: {settings.LLM_PROVIDER}")
    
    def _build_graph(self) -> StateGraph:
        """建構 LangGraph 工作流程"""
        
        # 定義狀態
        class OrchestratorState(MessagesState):
            """Orchestrator 狀態"""
            route: str = ""  # 路由決策
            jira_result: str = ""  # Jira Agent 結果
            faq_result: str = ""  # FAQ Agent 結果
        
        # 路由決策節點
        def router_node(state: OrchestratorState) -> Dict:
            """分析請求並決定路由"""
            messages = state["messages"]
            last_message = messages[-1].content.lower()
            
            # 簡單關鍵字路由（Production 可用 LLM 做更智能的路由）
            jira_keywords = ["jira", "ticket", "issue", "bug", "task", "任務", "工單", "專案", "sprint"]
            faq_keywords = ["faq", "常見問題", "政策", "流程", "怎麼申請", "規定"]
            
            if any(kw in last_message for kw in jira_keywords):
                return {"route": "jira"}
            elif any(kw in last_message for kw in faq_keywords):
                return {"route": "faq"}
            else:
                return {"route": "direct"}
        
        # Jira Agent 節點
        async def jira_node(state: OrchestratorState) -> Dict:
            """呼叫 Jira Agent"""
            messages = state["messages"]
            query = messages[-1].content
            
            result = await self.jira_agent.run(query)
            return {"jira_result": result}
        
        # FAQ Agent 節點（預留）
        async def faq_node(state: OrchestratorState) -> Dict:
            """呼叫 FAQ Agent（目前未實作）"""
            return {"faq_result": "FAQ Agent 目前正在開發中，請稍後再試。"}
        
        # 最終回覆節點
        async def respond_node(state: OrchestratorState) -> Dict:
            """生成最終回覆"""
            route = state.get("route", "direct")
            jira_result = state.get("jira_result", "")
            faq_result = state.get("faq_result", "")
            
            # 組合上下文
            context = ""
            if jira_result:
                context += f"\n\nJira Agent 結果：\n{jira_result}"
            if faq_result:
                context += f"\n\nFAQ Agent 結果：\n{faq_result}"
            
            # 使用 LLM 生成回覆
            messages = [
                SystemMessage(content=ORCHESTRATOR_SYSTEM_PROMPT),
                *state["messages"],
            ]
            
            if context:
                messages.append(SystemMessage(content=f"根據以下資訊回覆使用者：{context}"))
            
            response = await self.llm.ainvoke(messages)
            
            return {"messages": [response]}
        
        # 路由決策函數
        def route_decision(state: OrchestratorState) -> str:
            route = state.get("route", "direct")
            if route == "jira":
                return "jira_agent"
            elif route == "faq":
                return "faq_agent"
            else:
                return "respond"
        
        # 建構 Graph
        builder = StateGraph(OrchestratorState)
        
        # 添加節點
        builder.add_node("router", router_node)
        builder.add_node("jira_agent", jira_node)
        builder.add_node("faq_agent", faq_node)
        builder.add_node("respond", respond_node)
        
        # 添加邊
        builder.add_edge(START, "router")
        builder.add_conditional_edges("router", route_decision, {
            "jira_agent": "jira_agent",
            "faq_agent": "faq_agent",
            "respond": "respond"
        })
        builder.add_edge("jira_agent", "respond")
        builder.add_edge("faq_agent", "respond")
        builder.add_edge("respond", END)
        
        return builder.compile()
    
    async def run(self, message: str, conversation_id: str) -> Dict[str, Any]:
        """執行（非串流模式）"""
        result = await self.graph.ainvoke({
            "messages": [HumanMessage(content=message)]
        })
        
        return {
            "response": result["messages"][-1].content,
            "trace": []
        }
    
    async def stream(
        self, 
        message: str, 
        conversation_id: str
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        串流執行 - 產生狀態更新事件
        
        事件類型：
        - {"type": "status", "agent": "...", "status": "...", "tool": "...", "detail": "..."}
        - {"type": "token", "agent": "...", "content": "..."}
        - {"type": "tool_result", "agent": "...", "tool": "...", "result": "..."}
        """
        
        # 發送路由開始狀態
        yield {
            "type": "status",
            "agent": "Orchestrator",
            "status": "thinking",
            "detail": "分析請求中..."
        }
        
        # 執行路由決策
        messages = [HumanMessage(content=message)]
        last_message = message.lower()
        
        # 簡單路由邏輯
        jira_keywords = ["jira", "ticket", "issue", "bug", "task", "任務", "工單", "專案", "sprint"]
        
        if any(kw in last_message for kw in jira_keywords):
            # 路由到 Jira Agent
            yield {
                "type": "status",
                "agent": "Orchestrator", 
                "status": "completed",
                "detail": "已決定路由到 Jira Agent"
            }
            
            # 執行 Jira Agent 並串流狀態
            async for event in self.jira_agent.stream(message):
                yield event
            
            # 取得 Jira Agent 結果
            jira_result = await self.jira_agent.run(message)
            
            # 生成最終回覆
            yield {
                "type": "status",
                "agent": "Orchestrator",
                "status": "thinking", 
                "detail": "整理回覆中..."
            }
            
            # 使用 LLM 串流生成回覆
            response_messages = [
                SystemMessage(content=ORCHESTRATOR_SYSTEM_PROMPT),
                HumanMessage(content=message),
                SystemMessage(content=f"根據 Jira Agent 的查詢結果回覆使用者：\n{jira_result}")
            ]
            
            async for chunk in self.llm.astream(response_messages):
                if chunk.content:
                    yield {
                        "type": "token",
                        "agent": "Orchestrator",
                        "content": chunk.content
                    }
        
        else:
            # 直接回覆
            yield {
                "type": "status",
                "agent": "Orchestrator",
                "status": "thinking",
                "detail": "直接回覆中..."
            }
            
            response_messages = [
                SystemMessage(content=ORCHESTRATOR_SYSTEM_PROMPT),
                HumanMessage(content=message)
            ]
            
            async for chunk in self.llm.astream(response_messages):
                if chunk.content:
                    yield {
                        "type": "token",
                        "agent": "Orchestrator", 
                        "content": chunk.content
                    }
        
        # 完成
        yield {
            "type": "status",
            "agent": "Orchestrator",
            "status": "completed",
            "detail": "回覆完成"
        }
