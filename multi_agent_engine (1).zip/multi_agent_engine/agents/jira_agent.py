"""
agents/jira_agent.py - Jira 專業 Agent
整合你現有的 Jira Remote MCP Server

這個 Agent 負責：
1. 查詢 Jira tickets
2. 建立新 tickets
3. 更新 ticket 狀態
4. 查詢專案資訊
"""
from typing import AsyncGenerator, Dict, Any, List
from dataclasses import dataclass
import asyncio
import logging
import json

from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.tools import tool
from langchain.agents import AgentExecutor, create_react_agent
from langchain_core.prompts import ChatPromptTemplate

from config import settings

logger = logging.getLogger(__name__)

# Jira Agent 系統提示詞
JIRA_AGENT_SYSTEM_PROMPT = """你是 M公司 的 Jira 專家 Agent。

你可以使用以下工具來處理 Jira 相關請求：

{tools}

工具使用格式：
Thought: 我需要做什麼
Action: 工具名稱
Action Input: 工具參數
Observation: 工具返回結果
... (重複直到完成)
Thought: 我已經有足夠資訊回答了
Final Answer: 最終回答

注意事項：
- 使用繁體中文回覆
- 如果查詢結果為空，請明確告知使用者
- 如果需要更多資訊，請詢問使用者

{agent_scratchpad}
"""

class JiraAgent:
    """Jira 專業 Agent"""
    
    def __init__(self):
        self.tools = self._create_tools()
        self.llm = self._create_llm()
        self.agent = self._create_agent()
        logger.info("Jira Agent 初始化完成")
    
    def _create_llm(self):
        """建立 LLM 實例"""
        if settings.LLM_PROVIDER == "openai":
            from langchain_openai import ChatOpenAI
            return ChatOpenAI(
                model=settings.OPENAI_MODEL,
                api_key=settings.OPENAI_API_KEY,
                temperature=0
            )
        elif settings.LLM_PROVIDER == "azure":
            from langchain_openai import AzureChatOpenAI
            return AzureChatOpenAI(
                azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
                api_key=settings.AZURE_OPENAI_API_KEY,
                deployment_name=settings.AZURE_OPENAI_DEPLOYMENT,
                temperature=0
            )
        elif settings.LLM_PROVIDER == "ollama":
            from langchain_ollama import ChatOllama
            return ChatOllama(
                base_url=settings.OLLAMA_BASE_URL,
                model=settings.OLLAMA_MODEL
            )
        else:
            raise ValueError(f"不支援的 LLM Provider: {settings.LLM_PROVIDER}")
    
    def _create_tools(self) -> List:
        """建立 Jira 工具（整合你的 MCP Server）"""
        
        # ========== 方法 1: 直接整合 MCP Server ==========
        # 如果你的 MCP Server 已經跑起來，可以用 HTTP 呼叫
        
        @tool
        async def search_jira_tickets(query: str) -> str:
            """
            搜尋 Jira tickets。
            
            Args:
                query: JQL 查詢語句或自然語言描述
                      例如: "project = MYPROJ AND status = Open"
                      或: "我的未完成任務"
            
            Returns:
                搜尋結果的 JSON 字串
            """
            try:
                # 呼叫你的 Jira MCP Server
                # TODO: 替換成你實際的 MCP Server 呼叫方式
                import aiohttp
                
                async with aiohttp.ClientSession() as session:
                    # 假設你的 MCP Server 有這個端點
                    # 請根據你的實際 MCP Server API 調整
                    async with session.post(
                        f"{settings.JIRA_MCP_SERVER_URL}/tools/search_issues",
                        json={"jql": query},
                        timeout=aiohttp.ClientTimeout(total=30)
                    ) as resp:
                        if resp.status == 200:
                            result = await resp.json()
                            return json.dumps(result, ensure_ascii=False, indent=2)
                        else:
                            return f"搜尋失敗: HTTP {resp.status}"
            except Exception as e:
                logger.error(f"Jira 搜尋錯誤: {e}")
                # Fallback: 返回模擬資料（開發用）
                return json.dumps({
                    "total": 2,
                    "issues": [
                        {
                            "key": "DEMO-123",
                            "summary": "範例 Ticket - API 整合",
                            "status": "In Progress",
                            "assignee": "colin",
                            "priority": "High"
                        },
                        {
                            "key": "DEMO-124",
                            "summary": "範例 Ticket - 前端修正",
                            "status": "Open",
                            "assignee": "colin",
                            "priority": "Medium"
                        }
                    ],
                    "_note": "這是模擬資料，請確認 MCP Server 連線"
                }, ensure_ascii=False, indent=2)
        
        @tool
        async def get_jira_ticket(ticket_key: str) -> str:
            """
            取得單一 Jira ticket 的詳細資訊。
            
            Args:
                ticket_key: Ticket 編號，例如 "PROJ-123"
            
            Returns:
                Ticket 詳細資訊的 JSON 字串
            """
            try:
                import aiohttp
                
                async with aiohttp.ClientSession() as session:
                    async with session.post(
                        f"{settings.JIRA_MCP_SERVER_URL}/tools/get_issue",
                        json={"issue_key": ticket_key},
                        timeout=aiohttp.ClientTimeout(total=30)
                    ) as resp:
                        if resp.status == 200:
                            result = await resp.json()
                            return json.dumps(result, ensure_ascii=False, indent=2)
                        else:
                            return f"取得 ticket 失敗: HTTP {resp.status}"
            except Exception as e:
                logger.error(f"取得 Jira ticket 錯誤: {e}")
                return json.dumps({
                    "key": ticket_key,
                    "summary": f"範例 Ticket {ticket_key}",
                    "description": "這是模擬資料",
                    "status": "In Progress",
                    "assignee": "colin",
                    "reporter": "manager",
                    "priority": "High",
                    "created": "2024-12-01",
                    "updated": "2024-12-08",
                    "_note": "這是模擬資料，請確認 MCP Server 連線"
                }, ensure_ascii=False, indent=2)
        
        @tool
        async def create_jira_ticket(
            project: str,
            summary: str, 
            description: str = "",
            issue_type: str = "Task",
            priority: str = "Medium"
        ) -> str:
            """
            建立新的 Jira ticket。
            
            Args:
                project: 專案代碼，例如 "MYPROJ"
                summary: Ticket 標題
                description: Ticket 描述（可選）
                issue_type: 類型，預設 "Task"，可選 "Bug", "Story", "Epic"
                priority: 優先級，預設 "Medium"，可選 "Highest", "High", "Medium", "Low", "Lowest"
            
            Returns:
                建立結果，包含新 ticket 的 key
            """
            try:
                import aiohttp
                
                async with aiohttp.ClientSession() as session:
                    async with session.post(
                        f"{settings.JIRA_MCP_SERVER_URL}/tools/create_issue",
                        json={
                            "project": project,
                            "summary": summary,
                            "description": description,
                            "issue_type": issue_type,
                            "priority": priority
                        },
                        timeout=aiohttp.ClientTimeout(total=30)
                    ) as resp:
                        if resp.status == 200:
                            result = await resp.json()
                            return json.dumps(result, ensure_ascii=False, indent=2)
                        else:
                            return f"建立 ticket 失敗: HTTP {resp.status}"
            except Exception as e:
                logger.error(f"建立 Jira ticket 錯誤: {e}")
                return json.dumps({
                    "success": True,
                    "key": f"{project}-999",
                    "summary": summary,
                    "_note": "這是模擬結果，請確認 MCP Server 連線"
                }, ensure_ascii=False, indent=2)
        
        @tool  
        async def update_jira_ticket(
            ticket_key: str,
            status: str = None,
            assignee: str = None,
            comment: str = None
        ) -> str:
            """
            更新 Jira ticket。
            
            Args:
                ticket_key: Ticket 編號，例如 "PROJ-123"
                status: 新狀態（可選），例如 "In Progress", "Done"
                assignee: 新指派人（可選）
                comment: 新增評論（可選）
            
            Returns:
                更新結果
            """
            try:
                import aiohttp
                
                update_data = {"issue_key": ticket_key}
                if status:
                    update_data["status"] = status
                if assignee:
                    update_data["assignee"] = assignee
                if comment:
                    update_data["comment"] = comment
                
                async with aiohttp.ClientSession() as session:
                    async with session.post(
                        f"{settings.JIRA_MCP_SERVER_URL}/tools/update_issue",
                        json=update_data,
                        timeout=aiohttp.ClientTimeout(total=30)
                    ) as resp:
                        if resp.status == 200:
                            result = await resp.json()
                            return json.dumps(result, ensure_ascii=False, indent=2)
                        else:
                            return f"更新 ticket 失敗: HTTP {resp.status}"
            except Exception as e:
                logger.error(f"更新 Jira ticket 錯誤: {e}")
                return json.dumps({
                    "success": True,
                    "key": ticket_key,
                    "updated_fields": {
                        "status": status,
                        "assignee": assignee,
                        "comment": comment
                    },
                    "_note": "這是模擬結果，請確認 MCP Server 連線"
                }, ensure_ascii=False, indent=2)
        
        return [
            search_jira_tickets,
            get_jira_ticket,
            create_jira_ticket,
            update_jira_ticket
        ]
    
    def _create_agent(self):
        """建立 ReAct Agent"""
        from langchain.agents import create_tool_calling_agent
        from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
        
        prompt = ChatPromptTemplate.from_messages([
            ("system", """你是 M公司 的 Jira 專家 Agent。
            
你可以使用工具來查詢、建立和更新 Jira tickets。
請用繁體中文回覆，並以結構化的方式呈現 ticket 資訊。

如果使用者的請求不明確，請詢問更多資訊。
如果查詢結果為空，請告知使用者並建議可能的原因。"""),
            MessagesPlaceholder(variable_name="chat_history", optional=True),
            ("human", "{input}"),
            MessagesPlaceholder(variable_name="agent_scratchpad")
        ])
        
        agent = create_tool_calling_agent(self.llm, self.tools, prompt)
        
        return AgentExecutor(
            agent=agent,
            tools=self.tools,
            verbose=True,
            handle_parsing_errors=True,
            max_iterations=5
        )
    
    async def run(self, query: str) -> str:
        """執行 Jira Agent（非串流）"""
        try:
            result = await self.agent.ainvoke({"input": query})
            return result.get("output", "無法處理此請求")
        except Exception as e:
            logger.error(f"Jira Agent 執行錯誤: {e}")
            return f"處理請求時發生錯誤: {str(e)}"
    
    async def stream(self, query: str) -> AsyncGenerator[Dict[str, Any], None]:
        """
        串流執行 Jira Agent - 產生狀態更新事件
        
        用於向前端報告執行進度
        """
        yield {
            "type": "status",
            "agent": "JiraAgent",
            "status": "thinking",
            "detail": "分析 Jira 請求..."
        }
        
        # 模擬工具使用狀態（實際上 LangChain AgentExecutor 有 callbacks 可以用）
        # TODO: 使用 LangChain callbacks 來捕獲實際的工具呼叫
        
        yield {
            "type": "status",
            "agent": "JiraAgent",
            "status": "using_tool",
            "tool": "search_jira_tickets",
            "detail": f"搜尋 Jira tickets..."
        }
        
        # 執行實際查詢
        try:
            result = await self.agent.ainvoke({"input": query})
            
            yield {
                "type": "status",
                "agent": "JiraAgent",
                "status": "completed",
                "detail": "Jira 查詢完成"
            }
            
            yield {
                "type": "tool_result",
                "agent": "JiraAgent",
                "tool": "search_jira_tickets",
                "result": result.get("output", "")
            }
            
        except Exception as e:
            yield {
                "type": "status",
                "agent": "JiraAgent",
                "status": "error",
                "detail": str(e)
            }


# ========== 方法 2: 使用 MCP Python SDK（如果你用這種方式）==========
# 如果你是用 MCP Python SDK 連接 MCP Server，可以用以下方式：

"""
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

class JiraAgentWithMCP:
    def __init__(self):
        self.mcp_server_command = "npx"
        self.mcp_server_args = ["jira-mcp-server"]  # 替換成你的 MCP server
    
    async def get_mcp_tools(self):
        server_params = StdioServerParameters(
            command=self.mcp_server_command,
            args=self.mcp_server_args,
        )
        
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                tools = await session.list_tools()
                return tools
    
    async def call_mcp_tool(self, tool_name: str, arguments: dict):
        server_params = StdioServerParameters(
            command=self.mcp_server_command,
            args=self.mcp_server_args,
        )
        
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.call_tool(tool_name, arguments)
                return result
"""
