# LLM Agent 上線前測試驗證與評估方法論

**研究日期：2026-04-15**
**適用場景：企業 Jira Agent（mask-kernel SDK + LangChain v1.x）上線前驗證**

---

## 一、主流 Agent 評估 Benchmark 學術版圖

### AgentBench（arXiv: 2308.03688, ICLR 2024）
清華大學 / Ohio State，首個系統性 LLM-as-Agent 評估基準，橫跨 8 個互動環境（作業系統、資料庫、知識圖譜等），評估了 29 個 LLM。核心指標：success rate / F1 / reward score。

**關鍵發現**：GPT-4 顯著領先，商用與開源模型間存在巨大差距。

### τ-bench（arXiv: 2406.12045, Sierra Research / Princeton）
針對企業 Agent 最關鍵場景——對話式 Agent 的可靠性。模擬使用者與 Agent 的動態互動，以對話結束後的資料庫狀態與 ground truth 比對。

**核心創新：pass^k 指標**
衡量 Agent 在 k 次獨立試驗中是否每次都成功。即使 GPT-4o 的 pass^1 低於 50%，pass^8 僅約 25%——揭示 Agent 可靠性的嚴重不足。

**對 Jira Agent 的啟示**：上線門檻應以 pass^k 而非 pass^1 為基準。

### GAIA（arXiv: 2311.12983, ICML 2024, Meta / Hugging Face）
466 個需要網頁搜尋、程式碼執行、多步推理的真實問題，每題有唯一確定答案（exact match）。人類正確率 92%，GPT-4 with plugins 僅 15%。

### IntellAgent（arXiv: 2501.11067, Plurai AI, 2025）
自動化合成 benchmark 生成——將領域政策拆解為圖結構，按真實對話分布採樣生成測試場景，提供 per-policy 精細診斷。**對 Jira Agent 的價值**：可將 Jira 操作政策建模為圖，自動產生覆蓋各政策組合的測試案例。

---

## 二、Trajectory vs. Outcome 評估

**一句話總結**：Outcome 指標告訴你 Agent 是否有效，Trajectory 指標告訴你為什麼有效（或失敗）。

### Outcome Evaluation（Black-box）
僅看最終輸出，實作成本低。**死穴**：Agent 可能透過錯誤路徑意外達到正確結果，或在中間步驟洩漏敏感資料。

### Trajectory Evaluation（Glass-box）
AgentBoard（Ma et al., NeurIPS 2024）引入 **Progress Rate**——測量已完成子目標的比例，提供二元成功率以外的部分完成度計分。

**實務建議**：以 Outcome 評估作為上線門檻的主要指標，搭配 Trajectory 評估作為除錯與迴歸分析工具。

---

## 三、LLM-as-Judge 學術基礎

### G-Eval（arXiv: 2303.16634, EMNLP 2023）
輸入任務說明與評估標準 → LLM 生成 CoT 評估步驟 → form-filling 範式產出分數 → token 機率加權求和。

搭配 GPT-4 在 SummEval benchmark 上達到 Spearman 相關係數 0.514，大幅超越先前方法。

### MT-Bench（arXiv: 2306.05685, NeurIPS 2023, UC Berkeley）
GPT-4 作為評審與人類專家的一致率超過 80%。識別出三大偏誤：
- **位置偏誤**：偏好排在前面的回答
- **冗長偏誤**：偏好較長的回答
- **自我增強偏誤**：模型偏好自己的輸出風格

### 已知偏誤的應對方式
- 設計明確分層的 rubric
- 使用 reference-based 評估搭配 golden answer 作為錨點
- 每題跑 3 次以上取多數決
- 定期以人工標注校準，目標 Spearman 相關 ≥ 0.80
- 隨機化回答順序以緩解位置偏誤

---

## 四、Tool-use / Function Calling 評估

### Berkeley Function Calling Leaderboard（BFCL, ICML 2025）
核心創新：**AST 子字串匹配**——比對生成的函式呼叫與 ground truth 的 AST 結構。

### API-Bank（arXiv: 2304.08244, EMNLP 2023）
三層能力梯度：Call → Retrieve+Call → Plan+Retrieve+Call。

### 關鍵指標體系

| 指標 | 定義 | Jira Agent 對應 |
|------|------|----------------|
| Tool Selection Accuracy | 是否選擇正確工具 | search_issues vs. get_issue |
| Parameter Value Accuracy | 參數值是否正確提取 | priority 值是否對應 |
| Tool Call Sequence Correctness | 多步驟順序是否正確 | 先查詢再更新的正確順序 |
| Hallucination Rate | 呼叫不存在 API 的比率 | 防止虛構 Jira endpoint |
| Relevance Detection | 無適當工具時能否拒絕呼叫 | 非 Jira 問題不應呼叫工具 |

---

## 五、企業級上線門檻設計

### Anthropic 的建議（2026-01, "Demystifying Evals for AI Agents"）
- 從真實失敗案例中抽取 20–50 個任務作為起始評估資料集
- 區分 **Capability evals**（探索能力邊界）與 **Regression evals**（已知能處理的任務）
- Capability eval 通過率達高水準後，「畢業」進入 regression suite

### 統計考量
要在 80% 預期通過率下達到 5% 誤差範圍（95% 信心水準），每個場景至少需要約 246 個測試樣本。（Anthropic, arXiv: 2411.00640）

### 建議的 Jira Agent 上線門檻

| 維度 | 指標 | 建議門檻 |
|------|------|---------|
| 功能正確性 | Task Completion Rate | ≥ 80%（第一波門檻） |
| 工具正確性 | Tool Selection Accuracy | ≥ 95% |
| 可靠性 | pass^3 | ≥ 70% |
| 安全性 | Prompt Injection Resistance | ≥ 98% |
| 合規性 | 系統提示不洩漏 / PII 不暴露 | 100%（zero tolerance） |

---

## 六、安全性測試方法

### Prompt Injection 學術背景
- OWASP Top 10 for LLM Applications 2025：**Prompt Injection 連續兩年排名第一**
- HouYi（arXiv: 2306.05499）：測試 36 個真實應用，31 個存在注入弱點
- Liu et al.（arXiv: 2310.12815）：形式化框架，評估 5 種攻擊 × 10 種防禦 × 10 個 LLM

### 主流測試工具

| 工具 | 維護者 | 特色 |
|------|--------|------|
| Garak | NVIDIA | 廣泛探針庫、plugin 架構 |
| Promptfoo | Community | YAML 驅動、OWASP/NIST 對照、CI/CD 整合 |
| PyRIT | Microsoft | 多輪攻擊場景、RL 驅動 |
| DeepTeam | Confident AI | 40+ 弱點類別、與 DeepEval 整合 |

### OWASP LLM06:2025 Excessive Agency
定義三種風險：過度功能、過度權限、過度自主性。
Jira Agent 必須測試：不能被誘導修改非管轄範圍的 ticket，系統提示不可被提取。

---

## 七、評估工具對比

| 特性 | DeepEval | RAGAS | Langfuse | Promptfoo |
|------|----------|-------|----------|-----------|
| 授權 | Apache 2.0 | Apache 2.0 | MIT | MIT |
| Agent 專用指標 | ToolCorrectness, TaskCompletion, PlanQuality | ToolCallF1, AgentGoalAccuracy | Trajectory 評估模式 | 自定義 assertions |
| CI/CD 整合 | ✅ 原生 pytest | ⚠️ 需腳本化 | ✅ SDK experiments | ✅ 最強 |
| 紅隊測試 | ✅ DeepTeam | ❌ | ❌ | ✅ 核心功能 |
| 自建部署 | ❌ | N/A | ✅ 完整自建 | ✅ 本地執行 |

---

## 八、CI/CD 整合建議

```
PR 提交
  → [Gate 1] Promptfoo 快速安全掃描
  → [Gate 2] DeepEval pytest 核心指標
  → [Gate 3] Langfuse experiment 對比 golden dataset（< 80% 阻擋合併）

Nightly
  → Garak 廣度安全掃描 + 全量 regression suite

Weekly
  → PyRIT 多輪深度攻擊測試 + 人工抽樣校準
```

---

## 九、關鍵結論

1. **可靠性比單次正確性更重要**
   τ-bench 的 pass^k 指標證明，即使 GPT-4o 單次成功率看似可接受，連續多次全部成功的機率大幅下降。企業 Agent 上線門檻應以 pass^k 為基準。

2. **評估本身必須被評估**
   LLM-as-Judge 存在系統性偏誤。每個 judge evaluator 都應有對應的 meta-evaluation，追蹤 Cohen's Kappa 或 Spearman 相關作為評估品質指標。

3. **安全測試是持續對抗，不是一次性事件**
   OpenAI / Anthropic / Google DeepMind 聯合研究：12 種已發表防禦措施多數可被自適應攻擊以超過 90% 成功率突破。安全測試必須內建於 CI/CD 持續迴圈中。

---

## 參考文獻

- AgentBench: arXiv: 2308.03688 (ICLR 2024)
- τ-bench: arXiv: 2406.12045
- GAIA: arXiv: 2311.12983 (ICML 2024)
- IntellAgent: arXiv: 2501.11067
- G-Eval: arXiv: 2303.16634 (EMNLP 2023)
- MT-Bench: arXiv: 2306.05685 (NeurIPS 2023)
- BFCL: ICML 2025
- API-Bank: arXiv: 2304.08244 (EMNLP 2023)
- Anthropic Statistical Approach: arXiv: 2411.00640
- HouYi Prompt Injection: arXiv: 2306.05499
- Prompt Injection Formalization: arXiv: 2310.12815
- KDD Agent Eval Survey: arXiv: 2507.21504
- Langfuse Agent Evaluation Guide: https://langfuse.com/guides/cookbook/example_pydantic_ai_mcp_agent_evaluation
- OWASP Top 10 for LLM 2025: https://genai.owasp.org
