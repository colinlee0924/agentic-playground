"""
Jira Agent Benchmark — Upload Dataset to Langfuse
將 dataset_v1.json 推進 Langfuse Dataset（self-hosted）

使用方式：
  python upload_dataset.py
  python upload_dataset.py --file dataset_v2.json --name jira-agent-benchmark-v2
"""

import json
import argparse
from langfuse import Langfuse

# ── 設定 ──────────────────────────────────────────────────────────────────
LANGFUSE_HOST    = "https://your-langfuse.internal"
LANGFUSE_PUB_KEY = "pk-..."
LANGFUSE_SEC_KEY = "sk-..."
DEFAULT_DATASET  = "jira-agent-benchmark-v1"
DEFAULT_FILE     = "dataset_v1.json"

lf = Langfuse(
    host=LANGFUSE_HOST,
    public_key=LANGFUSE_PUB_KEY,
    secret_key=LANGFUSE_SEC_KEY,
)


def upload_dataset(json_path: str, dataset_name: str):
    with open(json_path, encoding="utf-8") as f:
        items: list[dict] = json.load(f)

    print(f"📂 讀取 {json_path}：{len(items)} 題")
    print(f"📡 推進 Langfuse Dataset：{dataset_name}")

    success = 0
    for item in items:
        try:
            lf.create_dataset_item(
                dataset_name=dataset_name,
                input={"question": item["input"]},
                expected_output=item.get("expected_output"),
                metadata={
                    "id":            item["id"],
                    "category":      item["category"],
                    "layer":         item["layer"],
                    "original_uid":  item.get("original_uid", ""),
                    "expected_tool": item.get("expected_tool"),
                    "expected_jql":  item.get("expected_jql"),
                    "eval_type":     item["eval_type"],
                    "is_critical":   item.get("is_critical", False),
                },
            )
            success += 1
            print(f"  ✓ [{item['id']}] {item['input'][:50]}...")
        except Exception as e:
            print(f"  ✗ [{item['id']}] 上傳失敗：{e}")

    print(f"\n✅ 完成：{success}/{len(items)} 題上傳成功")
    print(f"🔗 Langfuse：{LANGFUSE_HOST} → Datasets → {dataset_name}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Upload benchmark dataset to Langfuse")
    parser.add_argument("--file", default=DEFAULT_FILE, help="JSON 題庫路徑")
    parser.add_argument("--name", default=DEFAULT_DATASET, help="Langfuse Dataset 名稱")
    args = parser.parse_args()
    upload_dataset(args.file, args.name)
