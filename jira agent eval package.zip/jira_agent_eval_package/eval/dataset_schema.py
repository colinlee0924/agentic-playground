"""
Jira Agent Benchmark — Dataset Schema
每題的 Pydantic model，用於驗證 dataset_v1.json 格式。
"""

from pydantic import BaseModel
from typing import Literal, Optional


class EvalItem(BaseModel):
    id: str  # e.g. "SEC-001", "DAY-003"
    category: Literal[
        "security_test", "error_report",          # 安全底線
        "jql_search", "count_query",              # 日常操作
        "list_filter", "issue_lookup",
        "issue_detail", "get_field_id",
        "multi_fields_search", "summarize",       # 深度理解
        "review", "analytical", "time_based",
        "project_detail", "other"                 # 跨場景
    ]
    layer: Literal["安全底線", "日常操作", "深度理解", "跨場景覆蓋"]
    original_uid: str                            # 原始提問者的員工 uid，如 mtk27969
    input: str                                   # 使用者問題
    expected_output: Optional[str] = None        # 標準答案（open-ended 可 null）
    expected_tool: Optional[str] = None          # 預期呼叫的 tool name
    expected_jql: Optional[str] = None           # JQL 類題目的預期 query
    eval_type: Literal["deterministic", "llm_judge"]
    is_critical: bool = False                    # 安全底線題設 True
