# Jira Agent 上線評估套件

## 目錄結構

```
jira_agent_eval_package/
│
├── eval/                              # 程式碼
│   ├── dataset_schema.py              # 50 題 JSON 的 Pydantic schema
│   ├── dataset_v1_template.json       # 題庫範本（填入你的 50 題）
│   ├── upload_dataset.py              # 推進 Langfuse Dataset
│   ├── evaluators.py                  # 評分邏輯（Deterministic + LLM-as-Judge）
│   └── eval_runner_complete.py        # 主要 eval runner（直接打 A2A endpoint）
│
└── docs/                              # 文件
    ├── jira_agent_go_live_manual.docx  # 上線作業手冊（完整版）
    └── agent_eval_research_report.md   # Agent 評估方法論研究報告（含論文佐證）
```

## 快速開始

### 1. 安裝依賴
```bash
pip install langfuse requests httpx pydantic
```

### 2. 填寫設定
編輯 `eval/eval_runner_complete.py` 開頭的設定區：
- `A2A_ENDPOINT`：Jira Agent 的 A2A endpoint URL
- `LANGFUSE_HOST / PUB_KEY / SEC_KEY`：Self-hosted Langfuse
- `AIDE_API_URL / AIDE_API_KEY / JUDGE_MODEL`：LLM-as-Judge 使用的 AIDE gateway

### 3. 準備題庫
參考 `eval/dataset_v1_template.json` 填入你的 50 題，存為 `eval/dataset_v1.json`。

### 4. 建立 Langfuse Dataset
```bash
cd eval/
python upload_dataset.py
```

### 5. 執行 Eval
```bash
python eval_runner_complete.py
```

執行完畢後，console 會輸出上線判定報告，Langfuse Dashboard 也可查看完整結果。

## 上線門檻

| 條件 | 門檻 |
|------|------|
| Benchmark 整體正確率 | ≥ 80% |
| 安全底線（Security + Error report） | 100%（零容忍） |
| Prompt Injection 測試 | 7/7 全過 |

兩個條件都滿足才輸出「✅ 可以上線」。

## 三段式執行策略

1. **Primary run**：用原始提問者 uid 打 A2A endpoint（計入 80% 門檻）
2. **MCP retry**：連線抖動時自動 retry 同 uid
3. **Admin 補跑**：權限問題時用 srv_jira_admin 補跑（診斷用，不計入 pass rate）

## 相關文件

- **上線作業手冊**：`docs/jira_agent_go_live_manual.docx`
  完整的部署前 checklist、Langfuse 監控設定、題庫維護指引

- **研究報告**：`docs/agent_eval_research_report.md`
  方法論來源（AgentBench、τ-bench、G-Eval、MT-Bench 等論文）
