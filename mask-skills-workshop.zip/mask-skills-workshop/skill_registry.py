"""
SkillRegistry: 讀取標準 SKILL.md 格式，提供 progressive disclosure
"""

import yaml
from pathlib import Path
from typing import Optional


class SkillRegistry:
    def __init__(self, skills_dirs: list[str]):
        self.skills: dict[str, dict] = {}
        for d in skills_dirs:
            self._scan_skills(Path(d))

    def _scan_skills(self, base: Path):
        """掃描目錄下所有 SKILL.md，只讀 frontmatter（progressive disclosure）"""
        if not base.exists():
            print(f"⚠️  Skills directory not found: {base}")
            return

        for skill_md in base.rglob("SKILL.md"):
            content = skill_md.read_text(encoding="utf-8")
            frontmatter, body = self._parse_frontmatter(content)

            if "name" not in frontmatter:
                print(f"⚠️  Skipping {skill_md}: missing 'name' in frontmatter")
                continue

            self.skills[frontmatter["name"]] = {
                "description": frontmatter.get("description", ""),
                "content": body,
                "path": skill_md.parent,
                "frontmatter": frontmatter,
            }
            print(f"✅ Loaded skill: {frontmatter['name']}")

    def _parse_frontmatter(self, text: str) -> tuple[dict, str]:
        """解析 SKILL.md 的 YAML frontmatter"""
        if text.startswith("---"):
            parts = text.split("---", 2)
            if len(parts) >= 3:
                meta = yaml.safe_load(parts[1]) or {}
                body = parts[2].strip()
                return meta, body
        return {}, text

    def get_skill_summaries(self) -> str:
        """給 agent system prompt 用的摘要（只有 name + description）"""
        if not self.skills:
            return "No skills available."
        return "\n".join(
            f"- {name}: {s['description']}"
            for name, s in self.skills.items()
        )

    def load_skill(self, name: str) -> str:
        """Progressive disclosure：需要時才載入完整內容"""
        skill = self.skills.get(name)
        if not skill:
            available = ", ".join(self.skills.keys()) if self.skills else "none"
            return f"Skill '{name}' not found. Available skills: {available}"
        return skill["content"]

    def list_skill_files(self, skill_name: str) -> list[str]:
        """列出某個 skill 目錄下所有可用檔案"""
        skill = self.skills.get(skill_name)
        if not skill:
            return []
        base = skill["path"]
        return [
            str(f.relative_to(base))
            for f in base.rglob("*")
            if f.is_file() and f.name != "SKILL.md"
        ]

    def get_script_meta(self, skill_name: str, script_path: str) -> dict:
        """從 SKILL.md 中讀取特定 script 的 metadata（如 approval 等級）"""
        skill = self.skills.get(skill_name)
        if not skill:
            return {}
        content = skill["content"]
        # 簡單解析 [approval: xxx] 標記
        for line in content.split("\n"):
            if script_path in line:
                if "[approval: auto]" in line:
                    return {"approval": "auto"}
                elif "[approval: required]" in line:
                    return {"approval": "required"}
        # 預設需要確認
        return {"approval": "required"}
