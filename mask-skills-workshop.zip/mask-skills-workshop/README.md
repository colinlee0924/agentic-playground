# M.A.S.K. Agent — Skills + MCP Workshop

## 安裝

```bash
pip install langgraph langchain langchain-anthropic langchain-mcp-adapters pyyaml mcp
export ANTHROPIC_API_KEY=your-key
```

## 啟動

```bash
python agent.py
```

## 專案結構

```
mask-skills-workshop/
├── agent.py                          # 主程式（終端機互動 + HITL）
├── skill_registry.py                 # Skill 載入引擎
├── src/
│   ├── configs/
│   │   └── mcp_settings.json         # MCP servers 設定（標準 mcpServers 格式）
│   └── mcp_servers/
│       └── math_server.py            # 範例 MCP server
└── skills/
    ├── jql-helper/
    │   ├── SKILL.md
    │   ├── references/
    │   │   └── field_mapping.json
    │   └── scripts/
    │       └── validate_jql.py
    └── sprint-report/
        ├── SKILL.md
        └── scripts/
            └── generate_report.py
```

## MCP 設定

編輯 `src/configs/mcp_settings.json`，格式跟 Claude Desktop / Claude Code 一樣：

```json
{
  "mcpServers": {
    "math": {
      "transport": "stdio",
      "command": "python",
      "args": ["src/mcp_servers/math_server.py"]
    },
    "my-remote-server": {
      "transport": "http",
      "url": "http://localhost:8000/mcp"
    }
  }
}
```

## 新增 Skill

在 `skills/` 下建資料夾，寫 `SKILL.md`，重啟 agent 即自動載入。

## 終端機指令

- `/skills` — 查看已載入的 skills
- `/mcp` — 查看已載入的 MCP tools
- `/quit` — 離開
