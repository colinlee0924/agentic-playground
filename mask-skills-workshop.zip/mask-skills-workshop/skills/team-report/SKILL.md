---
name: team-report
description: Generate fun terminal-style team workload reports with ASCII character avatars for JIRA project members. Shows issue counts, status distribution, and work summary per assignee.
---

# team-report

## Overview
This skill generates visually fun terminal reports for team members in a JIRA project.
Each member gets a cute ASCII character avatar alongside their work summary.

## Instructions

1. Ask the user for the JIRA project key and group name (or use defaults: project=PROJDEMO)
2. Use the MCP tool `jira_search` to search for issues:
   - JQL: `project = {PROJECT} AND assignee in membersOf("{group}")` 
   - If group is not provided, use: `project = {PROJECT} AND assignee is not EMPTY`
   - Fetch fields: assignee, status, summary, issuetype, priority
   - Use maxResults=100 or paginate if needed
3. Use `read_skill_file` to read `references/avatar_pool.json` for the avatar mappings
4. Use `run_skill_script` to generate the report:
   - Pass the JIRA data as a JSON file: first write it, then pass the path
   - Or pass a simplified JSON string as argument
5. Present the output to the user

## Data Flow
- Input: JIRA issues JSON (from jira_search MCP tool)
- Processing: `scripts/generate_team_report.py` groups by assignee, calculates stats, picks avatars
- Output: Beautiful terminal report with ASCII art

## Available Resources

### References
- `references/avatar_pool.json` - Pool of ASCII character avatars [approval: auto]

### Scripts
- `scripts/generate_team_report.py` - Generate the ASCII team report. Pass JIRA issues as JSON via stdin. [approval: required]
