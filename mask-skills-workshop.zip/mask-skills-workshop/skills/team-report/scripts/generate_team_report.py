"""
Team Report Generator - ASCII Art Terminal Style
=================================================
Reads JIRA issues JSON from stdin, generates a fun terminal report
with character avatars per team member.

Usage:
    echo '{"issues": [...]}' | python generate_team_report.py
    python generate_team_report.py < issues.json
    python generate_team_report.py --demo  (使用範例資料)
"""

import sys
import json
import hashlib
from pathlib import Path
from collections import defaultdict

# ============================================================
# Load avatar pool
# ============================================================

SCRIPT_DIR = Path(__file__).parent
AVATAR_FILE = SCRIPT_DIR.parent / "references" / "avatar_pool.json"

def load_avatars():
    if AVATAR_FILE.exists():
        with open(AVATAR_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"avatars": [], "colors": {}, "status_icons": {}}

POOL = load_avatars()
AVATARS = POOL.get("avatars", [])
COLORS = POOL.get("colors", {})
STATUS_ICONS = POOL.get("status_icons", {})

# ANSI
C_RESET = COLORS.get("reset", "")
C_BOLD = COLORS.get("bold", "")
C_DIM = COLORS.get("dim", "")
COLOR_LIST = [COLORS.get(c, "") for c in ["cyan", "yellow", "green", "magenta", "blue", "red"]]


def pick_avatar(name: str) -> dict:
    """根據名字 hash 穩定地選一個 avatar"""
    if not AVATARS:
        return {"name": "default", "art": ["  (^_^)  "]}
    idx = int(hashlib.md5(name.encode()).hexdigest(), 16) % len(AVATARS)
    return AVATARS[idx]


def pick_color(name: str) -> str:
    if not COLOR_LIST:
        return ""
    idx = int(hashlib.sha1(name.encode()).hexdigest(), 16) % len(COLOR_LIST)
    return COLOR_LIST[idx]


def status_icon(status: str) -> str:
    for key, icon in STATUS_ICONS.items():
        if key.lower() in status.lower():
            return icon
    return "⬜"


# ============================================================
# Parse JIRA data
# ============================================================

def parse_issues(data: dict) -> dict:
    """
    解析 JIRA search 回傳的 JSON，按 assignee 分組
    支援兩種格式：
    1. 標準 JIRA REST: {"issues": [{"key": ..., "fields": {...}}]}
    2. 簡化格式: {"issues": [{"key": ..., "assignee": ..., "status": ..., "summary": ...}]}
    """
    issues = data.get("issues", data.get("sections", []))
    if not issues and isinstance(data, list):
        issues = data

    grouped = defaultdict(list)

    for issue in issues:
        # 標準 JIRA 格式
        if "fields" in issue:
            fields = issue["fields"]
            assignee_obj = fields.get("assignee") or {}
            assignee = assignee_obj.get("displayName", assignee_obj.get("name", "Unassigned"))
            status_obj = fields.get("status") or {}
            status = status_obj.get("name", "Unknown")
            summary = fields.get("summary", "")
            issuetype_obj = fields.get("issuetype") or {}
            issuetype = issuetype_obj.get("name", "Task")
            priority_obj = fields.get("priority") or {}
            priority = priority_obj.get("name", "Medium")
        else:
            # 簡化格式
            assignee = issue.get("assignee", "Unassigned")
            status = issue.get("status", "Unknown")
            summary = issue.get("summary", "")
            issuetype = issue.get("issuetype", issue.get("type", "Task"))
            priority = issue.get("priority", "Medium")

        grouped[assignee].append({
            "key": issue.get("key", "?"),
            "summary": summary,
            "status": status,
            "type": issuetype,
            "priority": priority,
        })

    return dict(grouped)


# ============================================================
# Render report
# ============================================================

def render_bar(value: int, max_value: int, width: int = 20, char: str = "█") -> str:
    """畫一個簡單的 bar chart"""
    if max_value == 0:
        return ""
    filled = int(value / max_value * width)
    empty = width - filled
    return char * filled + "░" * empty


def render_member_card(name: str, issues: list, total_max: int) -> str:
    """為一個成員產生報告卡片"""
    avatar = pick_avatar(name)
    color = pick_color(name)
    art_lines = avatar["art"]

    # 統計
    total = len(issues)
    status_counts = defaultdict(int)
    type_counts = defaultdict(int)
    priority_counts = defaultdict(int)

    for iss in issues:
        status_counts[iss["status"]] += 1
        type_counts[iss["type"]] += 1
        priority_counts[iss["priority"]] += 1

    # 主要工作內容（取前3個）
    top_summaries = [iss["summary"][:45] for iss in issues[:3]]

    # ---- 組裝卡片 ----
    card_width = 65
    lines = []

    # 頂部邊框
    lines.append(f"{color}{'━' * card_width}{C_RESET}")

    # 名字 + avatar
    name_line = f"{color}{C_BOLD}  {avatar['name'].upper()} | {name}{C_RESET}"
    lines.append(name_line)
    lines.append(f"{color}{'─' * card_width}{C_RESET}")

    # Avatar + 統計並排
    stat_lines = [
        f"  📋 Issues: {C_BOLD}{total}{C_RESET}  {render_bar(total, total_max, 15)}",
        f"",
        f"  Status:",
    ]
    for status, count in sorted(status_counts.items(), key=lambda x: -x[1]):
        icon = status_icon(status)
        bar = render_bar(count, total, 10)
        stat_lines.append(f"    {icon} {status:<15s} {count:>3d}  {bar}")

    stat_lines.append(f"")
    stat_lines.append(f"  Type:")
    for itype, count in sorted(type_counts.items(), key=lambda x: -x[1]):
        stat_lines.append(f"    • {itype:<15s} {count:>3d}")

    # 合併 avatar 和 stats
    max_lines = max(len(art_lines), len(stat_lines))
    for i in range(max_lines):
        art_part = ""
        if i < len(art_lines):
            art_part = f"{color}{art_lines[i]:<14s}{C_RESET}"
        else:
            art_part = " " * 14

        stat_part = ""
        if i < len(stat_lines):
            stat_part = stat_lines[i]

        lines.append(f"  {art_part} {stat_part}")

    # 工作摘要
    if top_summaries:
        lines.append(f"")
        lines.append(f"  {C_DIM}主要工作:{C_RESET}")
        for s in top_summaries:
            lines.append(f"  {C_DIM}  → {s}{C_RESET}")
        if total > 3:
            lines.append(f"  {C_DIM}  ... and {total - 3} more{C_RESET}")

    # 底部邊框
    lines.append(f"{color}{'━' * card_width}{C_RESET}")
    lines.append("")

    return "\n".join(lines)


def render_report(grouped: dict, project: str = "PROJDEMO") -> str:
    """產生完整報告"""
    total_issues = sum(len(v) for v in grouped.values())
    total_members = len(grouped)
    total_max = max(len(v) for v in grouped.values()) if grouped else 1

    # 全域狀態統計
    all_statuses = defaultdict(int)
    for issues in grouped.values():
        for iss in issues:
            all_statuses[iss["status"]] += 1

    # Header
    header = f"""
{C_BOLD}╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║   🎮  T E A M   W O R K L O A D   R E P O R T                   ║
║                                                                  ║
║   Project: {project:<20s}                                 ║
║   Members: {total_members:<5d}  Issues: {total_issues:<5d}                          ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝{C_RESET}
"""

    # 全域 overview
    overview_lines = [f"\n  {C_BOLD}📊 Overall Status Distribution:{C_RESET}\n"]
    for status, count in sorted(all_statuses.items(), key=lambda x: -x[1]):
        icon = status_icon(status)
        bar = render_bar(count, total_issues, 25)
        pct = count / total_issues * 100 if total_issues > 0 else 0
        overview_lines.append(f"    {icon} {status:<15s} {count:>3d} ({pct:4.1f}%)  {bar}")
    overview_lines.append("")
    overview = "\n".join(overview_lines)

    # 各成員卡片（按 issue 數量排序）
    cards = []
    for name, issues in sorted(grouped.items(), key=lambda x: -len(x[1])):
        cards.append(render_member_card(name, issues, total_max))

    # Footer
    footer = f"""
{C_DIM}{'─' * 65}
Generated by M.A.S.K. Team Report Skill | Powered by Agent Skills
{'─' * 65}{C_RESET}
"""

    return header + overview + "\n".join(cards) + footer


# ============================================================
# Demo data
# ============================================================

DEMO_DATA = {
    "issues": [
        {"key": "PROJDEMO-1", "assignee": "Colin Chen", "status": "Done", "summary": "Design MCP server architecture for JIRA", "type": "Story", "priority": "High"},
        {"key": "PROJDEMO-2", "assignee": "Colin Chen", "status": "Done", "summary": "Implement agent skills framework", "type": "Story", "priority": "High"},
        {"key": "PROJDEMO-3", "assignee": "Colin Chen", "status": "In Progress", "summary": "Build HITL approval workflow", "type": "Story", "priority": "Medium"},
        {"key": "PROJDEMO-4", "assignee": "Colin Chen", "status": "In Progress", "summary": "Integrate observability with Phoenix", "type": "Task", "priority": "Medium"},
        {"key": "PROJDEMO-5", "assignee": "Colin Chen", "status": "To Do", "summary": "Write workshop materials for Skills", "type": "Task", "priority": "High"},
        {"key": "PROJDEMO-10", "assignee": "Alice Wang", "status": "Done", "summary": "Setup CI/CD pipeline for agent service", "type": "Story", "priority": "High"},
        {"key": "PROJDEMO-11", "assignee": "Alice Wang", "status": "Done", "summary": "Dockerize MCP server", "type": "Task", "priority": "Medium"},
        {"key": "PROJDEMO-12", "assignee": "Alice Wang", "status": "In Progress", "summary": "Configure K8s deployment manifests", "type": "Task", "priority": "High"},
        {"key": "PROJDEMO-13", "assignee": "Alice Wang", "status": "In Progress", "summary": "Setup Helm charts for multi-tenant", "type": "Story", "priority": "Medium"},
        {"key": "PROJDEMO-14", "assignee": "Alice Wang", "status": "To Do", "summary": "Network policy for sandbox pods", "type": "Task", "priority": "Low"},
        {"key": "PROJDEMO-15", "assignee": "Alice Wang", "status": "Blocked", "summary": "Waiting for VPN access to staging", "type": "Bug", "priority": "High"},
        {"key": "PROJDEMO-20", "assignee": "Bob Lin", "status": "Done", "summary": "Implement Oracle MCP server", "type": "Story", "priority": "High"},
        {"key": "PROJDEMO-21", "assignee": "Bob Lin", "status": "Done", "summary": "Write unit tests for JQL validator", "type": "Task", "priority": "Medium"},
        {"key": "PROJDEMO-22", "assignee": "Bob Lin", "status": "In Progress", "summary": "Build data analysis skill", "type": "Story", "priority": "High"},
        {"key": "PROJDEMO-30", "assignee": "Diana Lee", "status": "In Progress", "summary": "Design Figma mockups for agent dashboard", "type": "Story", "priority": "Medium"},
        {"key": "PROJDEMO-31", "assignee": "Diana Lee", "status": "To Do", "summary": "Implement React frontend for HITL", "type": "Story", "priority": "High"},
        {"key": "PROJDEMO-32", "assignee": "Diana Lee", "status": "Done", "summary": "User research for agent interaction UX", "type": "Task", "priority": "Medium"},
        {"key": "PROJDEMO-40", "assignee": "Eric Huang", "status": "In Progress", "summary": "Evaluate LangFuse vs Phoenix", "type": "Task", "priority": "Medium"},
        {"key": "PROJDEMO-41", "assignee": "Eric Huang", "status": "Done", "summary": "Setup LangSmith tracing", "type": "Task", "priority": "High"},
        {"key": "PROJDEMO-42", "assignee": "Eric Huang", "status": "To Do", "summary": "Build custom metrics dashboard", "type": "Story", "priority": "Low"},
        {"key": "PROJDEMO-43", "assignee": "Eric Huang", "status": "Done", "summary": "Document observability best practices", "type": "Task", "priority": "Medium"},
    ]
}


# ============================================================
# Main
# ============================================================

def main():
    # 判斷是 demo 模式還是從 stdin 讀資料
    if len(sys.argv) > 1 and sys.argv[1] == "--demo":
        data = DEMO_DATA
        project = "PROJDEMO"
    elif not sys.stdin.isatty():
        raw = sys.stdin.read()
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as e:
            print(f"Error: Invalid JSON input: {e}", file=sys.stderr)
            sys.exit(1)
        project = sys.argv[1] if len(sys.argv) > 1 else "PROJDEMO"
    else:
        # 沒有 stdin 也沒有 --demo，用 demo 資料
        data = DEMO_DATA
        project = "PROJDEMO"

    grouped = parse_issues(data)

    if not grouped:
        print("⚠️  No issues found.")
        sys.exit(0)

    report = render_report(grouped, project=project)
    print(report)


if __name__ == "__main__":
    main()
