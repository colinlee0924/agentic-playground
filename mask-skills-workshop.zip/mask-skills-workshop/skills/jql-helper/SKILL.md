---
name: jql-helper
description: Help users write, validate, and optimize JIRA JQL queries. Provides field mapping references and JQL syntax validation.
---

# jql-helper

## Overview
This skill helps users work with JIRA JQL (JIRA Query Language). It can validate JQL syntax, suggest optimizations, and provide field mapping information.

## Instructions

1. When a user asks about JIRA fields or field IDs, read `references/field_mapping.json` for the complete mapping.
2. When writing or validating JQL queries, use `scripts/validate_jql.py` to check syntax.
3. Always validate JQL before presenting it to the user.

## Available Resources

### References (read directly, no approval needed)
- `references/field_mapping.json` - JIRA field ID to display name mapping [approval: auto]

### Scripts
- `scripts/validate_jql.py` - JQL syntax validator. Pass JQL string as argument. [approval: required]
