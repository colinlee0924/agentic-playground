"""
JQL Syntax Validator - Workshop Demo
Usage: python validate_jql.py "project = BU3 AND priority = P1"
"""
import sys
import json
import re


def validate_jql(jql: str) -> dict:
    errors = []
    warnings = []
    suggestions = []

    # Basic checks
    if not jql.strip():
        errors.append("JQL cannot be empty")
        return {"valid": False, "errors": errors, "warnings": warnings, "suggestions": suggestions, "jql": jql}

    # Check common syntax errors
    if "==" in jql:
        errors.append("Use '=' not '==' in JQL. Example: project = 'KEY'")

    if jql.count("(") != jql.count(")"):
        errors.append(f"Mismatched parentheses: {jql.count('(')} opening vs {jql.count(')')} closing")

    if jql.count('"') % 2 != 0:
        errors.append("Mismatched double quotes")

    if jql.count("'") % 2 != 0:
        errors.append("Mismatched single quotes")

    # Check for valid operators
    invalid_ops = re.findall(r'[!<>]=?=', jql)
    for op in invalid_ops:
        if op not in ("!=", ">=", "<="):
            errors.append(f"Invalid operator: '{op}'")

    # Check for valid keywords (case-insensitive)
    valid_keywords = {"AND", "OR", "NOT", "IN", "IS", "WAS", "CHANGED", "ORDER", "BY", "ASC", "DESC", "EMPTY", "NULL"}
    words = re.findall(r'\b[A-Z]{2,}\b', jql.upper())
    for word in words:
        if word not in valid_keywords and not word.startswith("CF["):
            # Could be a project key or field name, skip
            pass

    # Warnings
    if "ORDER BY" not in jql.upper() and len(jql) > 30:
        warnings.append("Consider adding ORDER BY for consistent results")

    if "*" in jql:
        warnings.append("Wildcard '*' is not supported in JQL. Use '~' for text search")

    # Suggestions
    if "created >" in jql.lower() and "d" not in jql:
        suggestions.append("Use relative dates like 'created >= -7d' for dynamic queries")

    if "sprint" in jql.lower() and "opensprint" not in jql.lower():
        suggestions.append("Use 'sprint in openSprints()' to target active sprints")

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings,
        "suggestions": suggestions,
        "jql": jql,
    }


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({"error": "Usage: python validate_jql.py <jql_query>"}, indent=2, ensure_ascii=False))
        sys.exit(1)

    jql = " ".join(sys.argv[1:])
    result = validate_jql(jql)
    print(json.dumps(result, indent=2, ensure_ascii=False))
