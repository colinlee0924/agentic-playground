---
name: sprint-report
description: Generate sprint summary reports with velocity metrics, completion rates, and carry-over analysis. Outputs formatted markdown reports.
---

# sprint-report

## Overview
This skill generates sprint summary reports based on provided sprint data. It calculates velocity, completion rates, and identifies carry-over items.

## Instructions

1. Gather sprint information from the user (sprint name, dates, or use sample data for demo)
2. Use `scripts/generate_report.py` to produce a formatted report
3. Present the report to the user

## Available Resources

### Scripts
- `scripts/generate_report.py` - Generate sprint report. Pass sprint name as argument. Uses sample data for demo. [approval: required]
