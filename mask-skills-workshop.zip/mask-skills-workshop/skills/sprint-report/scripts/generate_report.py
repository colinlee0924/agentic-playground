"""
Sprint Report Generator - Workshop Demo
Usage: python generate_report.py "Sprint 2026-Q1-3"
"""
import sys
import json
from datetime import datetime

# Demo sample data
SAMPLE_DATA = {
    "sprint_name": "Sprint 2026-Q1-3",
    "start_date": "2026-01-27",
    "end_date": "2026-02-07",
    "team": "DevOps Platform",
    "stories": [
        {"key": "DEVOPS-101", "title": "MCP Server for JIRA integration", "points": 5, "status": "Done"},
        {"key": "DEVOPS-102", "title": "Agent Skills framework design", "points": 8, "status": "Done"},
        {"key": "DEVOPS-103", "title": "HITL approval workflow", "points": 5, "status": "Done"},
        {"key": "DEVOPS-104", "title": "Sandbox execution environment", "points": 8, "status": "In Progress"},
        {"key": "DEVOPS-105", "title": "Multi-tenant skill registry", "points": 13, "status": "In Progress"},
        {"key": "DEVOPS-106", "title": "Observability dashboard", "points": 3, "status": "Done"},
        {"key": "DEVOPS-107", "title": "A2A protocol integration", "points": 5, "status": "To Do"},
    ],
    "bugs_fixed": 4,
    "bugs_found": 2,
    "previous_velocity": [28, 32, 25],
}


def generate_report(sprint_name: str) -> str:
    data = SAMPLE_DATA.copy()
    data["sprint_name"] = sprint_name or data["sprint_name"]

    total_points = sum(s["points"] for s in data["stories"])
    done_points = sum(s["points"] for s in data["stories"] if s["status"] == "Done")
    in_progress = [s for s in data["stories"] if s["status"] == "In Progress"]
    carry_over = [s for s in data["stories"] if s["status"] in ("In Progress", "To Do")]

    avg_velocity = sum(data["previous_velocity"]) / len(data["previous_velocity"])
    completion_rate = (done_points / total_points * 100) if total_points > 0 else 0

    report = f"""# 📊 Sprint Report: {data['sprint_name']}

## Basic Info
- **Team**: {data['team']}
- **Period**: {data['start_date']} ~ {data['end_date']}
- **Generated**: {datetime.now().strftime('%Y-%m-%d %H:%M')}

## Velocity & Completion
- **Planned**: {total_points} story points
- **Completed**: {done_points} story points
- **Completion Rate**: {completion_rate:.0f}%
- **Avg Velocity (last 3 sprints)**: {avg_velocity:.0f} points
- **Trend**: {"📈 Above average" if done_points > avg_velocity else "📉 Below average"}

## Completed Stories
| Key | Title | Points |
|-----|-------|--------|
"""
    for s in data["stories"]:
        if s["status"] == "Done":
            report += f"| {s['key']} | {s['title']} | {s['points']} |\n"

    if carry_over:
        report += "\n## Carry-over Items\n"
        report += "| Key | Title | Points | Status |\n"
        report += "|-----|-------|--------|--------|\n"
        for s in carry_over:
            report += f"| {s['key']} | {s['title']} | {s['points']} | {s['status']} |\n"

    report += f"""
## Bug Metrics
- **Bugs Fixed**: {data['bugs_fixed']}
- **Bugs Found**: {data['bugs_found']}
- **Net**: {"✅ Reduced" if data['bugs_fixed'] > data['bugs_found'] else "⚠️ Increased"} bug count

## Summary
This sprint completed {done_points} out of {total_points} planned story points ({completion_rate:.0f}%).
{len(carry_over)} items will carry over to the next sprint.
"""

    return report


if __name__ == "__main__":
    sprint_name = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else ""
    print(generate_report(sprint_name))
