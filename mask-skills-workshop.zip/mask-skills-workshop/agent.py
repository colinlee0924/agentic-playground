"""
M.A.S.K. Agent Skills + MCP Workshop Demo (Terminal)
=====================================================
Usage:
    export ANTHROPIC_API_KEY=your-key
    python agent.py

MCP config: src/configs/mcp_settings.json (standard mcpServers format)
Skills:     skills/
"""

import os
import json
import asyncio
import subprocess
from pathlib import Path

from langchain_anthropic import ChatAnthropic
from langchain_core.tools import tool
from langgraph.prebuilt import create_react_agent
from langgraph.types import interrupt, Command
from langgraph.checkpoint.memory import MemorySaver

from skill_registry import SkillRegistry

# ============================================================
# Paths
# ============================================================

PROJECT_ROOT = Path(__file__).parent
SKILLS_DIR = PROJECT_ROOT / "skills"
SKILLS_ROOT = SKILLS_DIR.resolve()
MCP_CONFIG = PROJECT_ROOT / "src" / "configs" / "mcp_settings.json"


# ============================================================
# Skill Registry & Tools
# ============================================================

registry = SkillRegistry(skills_dirs=[str(SKILLS_DIR)])


def _safe_resolve(skill_name: str, relative_path: str) -> Path:
    target = (SKILLS_ROOT / skill_name / relative_path).resolve()
    if not str(target).startswith(str(SKILLS_ROOT)):
        raise PermissionError("Path traversal detected")
    if not target.exists():
        raise FileNotFoundError(f"{relative_path} not found in skill '{skill_name}'")
    return target


@tool
def load_skill(skill_name: str) -> str:
    """Load a skill's full instructions. Use when you need specialized knowledge."""
    content = registry.load_skill(skill_name)
    files = registry.list_skill_files(skill_name)
    if files:
        content += "\n\n## Available files:\n" + "\n".join(f"- {f}" for f in files)
    return content


@tool
def read_skill_file(skill_name: str, relative_path: str) -> str:
    """Read a reference file from a skill. No approval needed."""
    return _safe_resolve(skill_name, relative_path).read_text(encoding="utf-8")


@tool
def run_skill_script(skill_name: str, script_path: str, args: str = "", stdin_data: str = "") -> str:
    """Run a script from a skill directory. Requires human approval.

    Args:
        skill_name: Name of the skill
        script_path: Path to script relative to skill folder
        args: Arguments to pass to the script
        stdin_data: Optional data to pass via stdin (useful for large JSON payloads)
    """
    target = _safe_resolve(skill_name, script_path)
    code = target.read_text(encoding="utf-8")

    approval = interrupt({
        "skill": skill_name,
        "script": script_path,
        "args": args,
        "stdin_preview": stdin_data[:200] + "..." if len(stdin_data) > 200 else stdin_data if stdin_data else "(none)",
        "code": code,
    })

    if approval.get("action") == "reject":
        return f"⛔ Rejected: {approval.get('reason', '')}"

    result = subprocess.run(
        ["python", str(target)] + (args.split() if args else []),
        input=stdin_data if stdin_data else None,
        capture_output=True, text=True, timeout=30,
        cwd=str(target.parent),
    )
    output = result.stdout
    if result.returncode != 0:
        output += f"\n[stderr]: {result.stderr}"
    return output if output.strip() else "(no output)"


# ============================================================
# MCP Loader
# ============================================================

def load_mcp_config() -> dict:
    """讀取標準 mcpServers 格式的設定檔"""
    if not MCP_CONFIG.exists():
        print(f"  ℹ️  No MCP config at {MCP_CONFIG}")
        return {}

    with open(MCP_CONFIG, "r", encoding="utf-8") as f:
        config = json.load(f)

    servers = config.get("mcpServers", {})
    if servers:
        print(f"  📡 Found {len(servers)} MCP server(s):")
        for name, cfg in servers.items():
            transport = cfg.get("transport", cfg.get("type", "stdio"))
            if transport == "stdio":
                cmd = cfg.get("command", "?")
                args = " ".join(cfg.get("args", []))
                print(f"     • {name} (stdio: {cmd} {args})")
            else:
                print(f"     • {name} ({transport}: {cfg.get('url', '?')})")
    return servers


def build_adapters_config(servers: dict) -> dict:
    """將標準 mcpServers 格式轉為 langchain-mcp-adapters 格式"""
    result = {}
    for name, cfg in servers.items():
        transport = cfg.get("transport", cfg.get("type", "stdio"))

        if transport == "stdio":
            # 相對路徑轉絕對路徑
            resolved_args = []
            for arg in cfg.get("args", []):
                p = PROJECT_ROOT / arg
                resolved_args.append(str(p.resolve()) if p.exists() else arg)

            entry = {
                "transport": "stdio",
                "command": cfg.get("command", ""),
                "args": resolved_args,
            }
            if "env" in cfg:
                entry["env"] = {**os.environ, **cfg["env"]}

        elif transport in ("http", "sse", "streamable-http"):
            entry = {
                "transport": "http" if transport == "streamable-http" else transport,
                "url": cfg.get("url", ""),
            }
            if "headers" in cfg:
                entry["headers"] = cfg["headers"]
        else:
            print(f"  ⚠️  Unknown transport '{transport}' for {name}, skipping")
            continue

        result[name] = entry
    return result


async def connect_mcp(adapters_config: dict):
    """連接 MCP servers，回傳 (tools, client)"""
    if not adapters_config:
        return [], None

    try:
        from langchain_mcp_adapters.client import MultiServerMCPClient
    except ImportError:
        print("  ⚠️  langchain-mcp-adapters not installed.")
        print("     Run: pip install langchain-mcp-adapters")
        return [], None

    client = MultiServerMCPClient(adapters_config)
    # MultiServerMCPClient 是 async context manager
    await client.__aenter__()
    tools = await client.get_tools()
    print(f"  🔧 Loaded {len(tools)} MCP tool(s): {[t.name for t in tools]}")
    return tools, client


# ============================================================
# Terminal HITL
# ============================================================

def handle_hitl(interrupt_data: dict) -> dict:
    print("\n" + "=" * 55)
    print("⚠️  Agent 請求執行腳本")
    print("=" * 55)
    print(f"  Skill:  {interrupt_data['skill']}")
    print(f"  Script: {interrupt_data['script']}")
    print(f"  Args:   {interrupt_data.get('args') or '(none)'}")
    if interrupt_data.get('stdin_preview') and interrupt_data['stdin_preview'] != '(none)':
        print(f"  Stdin:  {interrupt_data['stdin_preview'][:80]}...")
    print("-" * 55)

    while True:
        choice = input("\n  [A] 允許  [R] 拒絕  [V] 查看程式碼 > ").strip().upper()
        if choice == "V":
            print("\n" + "-" * 55)
            print(interrupt_data["code"])
            print("-" * 55)
        elif choice == "A":
            print("  ✅ 已允許")
            return {"action": "approve"}
        elif choice == "R":
            reason = input("  拒絕原因（可留空）> ").strip()
            print("  ❌ 已拒絕")
            return {"action": "reject", "reason": reason}
        else:
            print("  請輸入 A / R / V")


# ============================================================
# Streaming + HITL
# ============================================================

async def stream_agent_response(agent, user_input: str, config: dict):
    """串流 agent 回應，遇到 HITL 時暫停審核後繼續串流"""
    inputs = {"messages": [{"role": "user", "content": user_input}]}
    await _stream_and_handle_hitl(agent, inputs, config)


async def _stream_and_handle_hitl(agent, inputs, config):
    """核心串流迴圈：串流輸出 + HITL 處理"""

    print("\n🤖 ", end="", flush=True)

    streamed_any = False
    tool_called = None

    try:
        async for event in agent.astream_events(inputs, config=config, version="v2"):
            kind = event["event"]

            # --- LLM token 串流 ---
            if kind == "on_chat_model_stream":
                chunk = event["data"]["chunk"]
                content = chunk.content if hasattr(chunk, "content") else ""
                if content:
                    print(content, end="", flush=True)
                    streamed_any = True

            # --- Tool 開始呼叫 ---
            elif kind == "on_tool_start":
                tool_name = event.get("name", "?")
                if tool_name == "run_skill_script":
                    tool_called = tool_name
                    # 不需要特別印什麼，等 HITL interrupt
                elif tool_name != "load_skill":
                    # MCP tools 或 read_skill_file
                    if streamed_any:
                        print()
                    print(f"  🔧 calling {tool_name}...", flush=True)

            # --- Tool 結束 ---
            elif kind == "on_tool_end":
                tool_name = event.get("name", "?")
                if tool_name not in ("load_skill", "run_skill_script"):
                    pass  # 靜默，讓 LLM 繼續回應

    except Exception as e:
        err_msg = str(e)
        # GraphInterrupt 表示 HITL 被觸發
        if "GraphInterrupt" in type(e).__name__ or "interrupt" in err_msg.lower():
            pass  # 正常流程，下面處理 HITL
        else:
            print(f"\n⚠️ Error: {e}\n")
            return

    # 換行
    if streamed_any:
        print()

    # --- 檢查 HITL ---
    while True:
        snapshot = agent.get_state(config)
        if not snapshot.next:
            break

        for task in snapshot.tasks:
            if hasattr(task, "interrupts") and task.interrupts:
                interrupt_data = task.interrupts[0].value
                approval = handle_hitl(interrupt_data)

                # Resume 後繼續串流
                print("\n🤖 ", end="", flush=True)
                streamed_any = False

                try:
                    async for event in agent.astream_events(
                        Command(resume=approval), config=config, version="v2"
                    ):
                        kind = event["event"]
                        if kind == "on_chat_model_stream":
                            chunk = event["data"]["chunk"]
                            content = chunk.content if hasattr(chunk, "content") else ""
                            if content:
                                print(content, end="", flush=True)
                                streamed_any = True
                        elif kind == "on_tool_start":
                            tool_name = event.get("name", "?")
                            if tool_name not in ("load_skill", "run_skill_script"):
                                if streamed_any:
                                    print()
                                print(f"  🔧 calling {tool_name}...", flush=True)
                except Exception as e:
                    if "GraphInterrupt" not in type(e).__name__:
                        print(f"\n⚠️ Error: {e}")

                if streamed_any:
                    print()

    print()  # 最後空行


# ============================================================
# Main
# ============================================================

async def amain():
    MODEL = os.getenv("MASK_MODEL", "claude-sonnet-4-20250514")
    llm = ChatAnthropic(model=MODEL, temperature=0)
    checkpointer = MemorySaver()

    # --- Load MCP ---
    print()
    mcp_servers = load_mcp_config()
    adapters_config = build_adapters_config(mcp_servers)

    mcp_tools = []
    mcp_client = None
    if adapters_config:
        try:
            mcp_tools, mcp_client = await connect_mcp(adapters_config)
        except Exception as e:
            print(f"  ⚠️  MCP connection failed: {e}")

    # --- All tools ---
    skill_tools = [load_skill, read_skill_file, run_skill_script]
    all_tools = skill_tools + mcp_tools

    # --- System prompt ---
    skill_summaries = registry.get_skill_summaries()
    mcp_section = ""
    if mcp_tools:
        mcp_section = "\n\n## MCP Tools\n" + "\n".join(
            f"- {t.name}: {t.description[:100]}" for t in mcp_tools
        )

    agent = create_react_agent(
        model=llm,
        tools=all_tools,
        prompt=f"""You are M.A.S.K. (Multi-Agent Skills Kit) assistant for the DevOps team.

## Available Skills
{skill_summaries}

## How to use skills
1. Use `load_skill` to get full instructions for a skill.
2. Use `read_skill_file` for references (no approval needed).
3. Use `run_skill_script` for scripts (requires user approval via HITL).
{mcp_section}

Respond in the same language as the user.""",
        checkpointer=checkpointer,
    )

    config = {"configurable": {"thread_id": "workshop-demo"}}

    # --- Banner ---
    skill_names = ", ".join(registry.skills.keys()) or "(none)"
    mcp_names = ", ".join(mcp_servers.keys()) or "(none)"
    mcp_tool_count = len(mcp_tools)

    print(f"""
╔═══════════════════════════════════════════════════════╗
║  M.A.S.K. Agent — Skills + MCP Workshop                ║
╠═══════════════════════════════════════════════════════╣
║  Model:      {MODEL:<41s}║
║  Skills:     {skill_names:<41s}║
║  MCP:        {mcp_names:<41s}║
║  MCP Tools:  {mcp_tool_count:<41d}║
╚═══════════════════════════════════════════════════════╝

指令:  /quit    離開
       /skills  查看 skills 清單
       /mcp     查看 MCP tools 清單
""")

    # --- Chat loop ---
    while True:
        try:
            user_input = input("You > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n👋 Bye!")
            break

        if not user_input:
            continue

        if user_input == "/quit":
            print("👋 Bye!")
            break

        if user_input == "/skills":
            if not registry.skills:
                print("  (no skills loaded)")
            for name, s in registry.skills.items():
                print(f"  📁 {name}: {s['description']}")
                for f in registry.list_skill_files(name):
                    print(f"     └── {f}")
            print()
            continue

        if user_input == "/mcp":
            if not mcp_tools:
                print("  (no MCP tools loaded)")
            else:
                for t in mcp_tools:
                    desc = t.description[:80] if t.description else "(no description)"
                    print(f"  🔧 {t.name}: {desc}")
            print()
            continue

        # Stream agent response
        await stream_agent_response(agent, user_input, config)

    # Cleanup
    if mcp_client:
        try:
            await mcp_client.__aexit__(None, None, None)
        except Exception:
            pass


def main():
    asyncio.run(amain())


if __name__ == "__main__":
    main()
