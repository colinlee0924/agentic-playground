#!/usr/bin/env python3
"""
Langfuse 批次使用者佈建腳本 (Batch User Provisioning)

功能：
1. 透過 SCIM API 批次建立使用者並加入 Organization
2. 透過 Membership API 批次更新使用者的 Organization Role
3. 支援從 CSV 檔案匯入使用者清單
4. 支援 dry-run 模式預覽操作

前置需求：
- Organization-scoped API Key（在 Organization Settings 中建立）
- Langfuse Enterprise Edition 或 Self-hosted Enterprise

使用方式：
    # 直接指定 email 清單
    python langfuse_batch_provision.py --emails user1@company.com user2@company.com

    # 從 CSV 匯入（CSV 需有 email 欄位）
    python langfuse_batch_provision.py --csv users.csv

    # 指定角色（預設 MEMBER）
    python langfuse_batch_provision.py --csv users.csv --role VIEWER

    # Dry-run 模式（只預覽不執行）
    python langfuse_batch_provision.py --csv users.csv --dry-run

    # 只更新既有使用者的 role（跳過建立）
    python langfuse_batch_provision.py --csv users.csv --update-role-only
"""

import argparse
import csv
import json
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

import requests
from requests.auth import HTTPBasicAuth

# ============================================================
# 設定區 - 請根據你的環境修改
# ============================================================
LANGFUSE_BASE_URL = "https://your-langfuse-instance.com"  # 改成你的 Langfuse URL
ORG_PUBLIC_KEY = "pk-lf-xxxxxxxx"                          # Organization API Key (public)
ORG_SECRET_KEY = "sk-lf-xxxxxxxx"                          # Organization API Key (secret)

# 可選：如果想指定 project-level role，填入 project ID
# PROJECT_ID = ""

# ============================================================
# 常數
# ============================================================
VALID_ORG_ROLES = {"OWNER", "ADMIN", "MEMBER", "VIEWER", "NONE"}
SCIM_BASE = f"{LANGFUSE_BASE_URL}/api/public/scim"
ORG_MEMBERSHIP_URL = f"{LANGFUSE_BASE_URL}/api/public/organizations/memberships"

SCIM_SCHEMA = "urn:ietf:params:scim:schemas:core:2.0:User"


@dataclass
class ProvisionResult:
    email: str
    scim_status: str = ""       # created / exists / skipped / error
    scim_user_id: str = ""
    role_status: str = ""       # updated / skipped / error
    error_msg: str = ""


def get_auth() -> HTTPBasicAuth:
    return HTTPBasicAuth(ORG_PUBLIC_KEY, ORG_SECRET_KEY)


# ============================================================
# SCIM 操作
# ============================================================

def scim_list_users() -> list[dict]:
    """列出 Organization 中所有 SCIM 使用者"""
    users = []
    start_index = 1
    count = 100

    while True:
        resp = requests.get(
            f"{SCIM_BASE}/Users",
            auth=get_auth(),
            params={"startIndex": start_index, "count": count},
        )
        resp.raise_for_status()
        data = resp.json()
        resources = data.get("Resources", [])
        users.extend(resources)

        total = data.get("totalResults", 0)
        if start_index + count > total:
            break
        start_index += count

    return users


def scim_create_user(email: str, password: str | None = None) -> dict:
    """
    透過 SCIM API 建立使用者。
    如果 email 已存在，會回傳 409 Conflict。
    建立後使用者預設 role 為 NONE。
    """
    payload = {
        "schemas": [SCIM_SCHEMA],
        "userName": email,
        "emails": [{"value": email, "primary": True}],
        "active": True,
    }
    if password:
        payload["password"] = password

    resp = requests.post(
        f"{SCIM_BASE}/Users",
        auth=get_auth(),
        json=payload,
        headers={"Content-Type": "application/json"},
    )
    return {"status_code": resp.status_code, "body": resp.json() if resp.content else {}}


# ============================================================
# Membership 操作
# ============================================================

def get_org_memberships() -> list[dict]:
    """取得 Organization 中所有成員及其 role"""
    resp = requests.get(
        ORG_MEMBERSHIP_URL,
        auth=get_auth(),
    )
    resp.raise_for_status()
    return resp.json().get("data", resp.json() if isinstance(resp.json(), list) else [])


def update_org_membership(user_id: str, role: str) -> dict:
    """
    更新使用者在 Organization 中的角色。
    
    PUT /api/public/organizations/memberships
    Body: { "userId": "<user-id>", "role": "<ROLE>" }
    """
    payload = {
        "userId": user_id,
        "role": role,
    }
    resp = requests.put(
        ORG_MEMBERSHIP_URL,
        auth=get_auth(),
        json=payload,
        headers={"Content-Type": "application/json"},
    )
    return {"status_code": resp.status_code, "body": resp.json() if resp.content else {}}


# ============================================================
# 批次佈建流程
# ============================================================

def batch_provision(
    emails: list[str],
    target_role: str = "MEMBER",
    dry_run: bool = False,
    update_role_only: bool = False,
    password: str | None = None,
    delay: float = 0.5,
) -> list[ProvisionResult]:
    """
    批次佈建使用者：
    1. SCIM POST /Users 建立使用者（預設 role=NONE）
    2. 查詢 membership 取得 userId
    3. PUT /organizations/memberships 更新 role
    """
    results: list[ProvisionResult] = []

    if target_role not in VALID_ORG_ROLES:
        print(f"❌ 無效的 role: {target_role}，有效值為: {VALID_ORG_ROLES}")
        sys.exit(1)

    print(f"\n{'='*60}")
    print(f"Langfuse 批次使用者佈建")
    print(f"{'='*60}")
    print(f"  Base URL:    {LANGFUSE_BASE_URL}")
    print(f"  使用者數量:  {len(emails)}")
    print(f"  目標 Role:   {target_role}")
    print(f"  Dry Run:     {dry_run}")
    print(f"  僅更新 Role: {update_role_only}")
    print(f"{'='*60}\n")

    # --- Step 1: 建立使用者 (SCIM) ---
    if not update_role_only:
        print("📦 Step 1: 透過 SCIM API 建立使用者...\n")
        for i, email in enumerate(emails, 1):
            result = ProvisionResult(email=email)

            if dry_run:
                print(f"  [{i}/{len(emails)}] [DRY-RUN] 將建立: {email}")
                result.scim_status = "dry-run"
                results.append(result)
                continue

            resp = scim_create_user(email, password=password)
            code = resp["status_code"]
            body = resp["body"]

            if code in (200, 201):
                user_id = body.get("id", "")
                result.scim_status = "created"
                result.scim_user_id = user_id
                print(f"  [{i}/{len(emails)}] ✅ 已建立: {email} (id: {user_id})")
            elif code == 409:
                result.scim_status = "exists"
                print(f"  [{i}/{len(emails)}] ⏭️  已存在: {email}")
            else:
                result.scim_status = "error"
                result.error_msg = f"SCIM error {code}: {json.dumps(body, ensure_ascii=False)}"
                print(f"  [{i}/{len(emails)}] ❌ 失敗: {email} - HTTP {code}")

            results.append(result)
            time.sleep(delay)  # 避免 rate limit
    else:
        results = [ProvisionResult(email=email, scim_status="skipped") for email in emails]

    # --- Step 2: 查詢 membership 取得 userId mapping ---
    print(f"\n📋 Step 2: 查詢 Organization Memberships...\n")

    if dry_run:
        print("  [DRY-RUN] 跳過查詢")
        for r in results:
            r.role_status = "dry-run"
        _print_summary(results, dry_run=True)
        return results

    try:
        memberships = get_org_memberships()
        print(f"  找到 {len(memberships)} 個成員")
    except Exception as e:
        print(f"  ❌ 查詢 memberships 失敗: {e}")
        print(f"  💡 嘗試透過 SCIM Users list 取得 userId...\n")
        memberships = []

    # 建立 email -> userId mapping
    # Memberships response 的格式可能是:
    #   [{"userId": "...", "email": "...", "orgRole": "...", ...}]
    email_to_user_id: dict[str, str] = {}
    email_to_current_role: dict[str, str] = {}

    for m in memberships:
        email_key = (m.get("email") or m.get("userName") or "").lower()
        user_id = m.get("userId") or m.get("id") or ""
        current_role = m.get("orgRole") or m.get("role") or ""
        if email_key and user_id:
            email_to_user_id[email_key] = user_id
            email_to_current_role[email_key] = current_role

    # 如果 memberships 沒有完整資料，用 SCIM list 補齊
    if len(email_to_user_id) < len(emails):
        try:
            scim_users = scim_list_users()
            for u in scim_users:
                email_key = (u.get("userName") or "").lower()
                user_id = u.get("id", "")
                if email_key and user_id and email_key not in email_to_user_id:
                    email_to_user_id[email_key] = user_id
        except Exception as e:
            print(f"  ⚠️ SCIM list 也失敗: {e}")

    # --- Step 3: 更新 Role ---
    print(f"\n🔑 Step 3: 更新使用者 Role 為 {target_role}...\n")

    for i, result in enumerate(results, 1):
        email_lower = result.email.lower()
        user_id = result.scim_user_id or email_to_user_id.get(email_lower, "")

        if not user_id:
            result.role_status = "error"
            result.error_msg += f" | 找不到 userId for {result.email}"
            print(f"  [{i}/{len(results)}] ❌ 找不到 userId: {result.email}")
            continue

        current_role = email_to_current_role.get(email_lower, "")
        if current_role == target_role:
            result.role_status = "already_correct"
            print(f"  [{i}/{len(results)}] ⏭️  已是 {target_role}: {result.email}")
            continue

        resp = update_org_membership(user_id, target_role)
        code = resp["status_code"]

        if code in (200, 201, 204):
            result.role_status = "updated"
            print(f"  [{i}/{len(results)}] ✅ 已更新: {result.email} → {target_role}")
        else:
            result.role_status = "error"
            body = resp.get("body", {})
            result.error_msg += f" | Role update error {code}: {json.dumps(body, ensure_ascii=False)}"
            print(f"  [{i}/{len(results)}] ❌ 更新失敗: {result.email} - HTTP {code}")

        time.sleep(delay)

    _print_summary(results)
    return results


def _print_summary(results: list[ProvisionResult], dry_run: bool = False):
    """印出執行摘要"""
    print(f"\n{'='*60}")
    print(f"執行摘要")
    print(f"{'='*60}")

    created = sum(1 for r in results if r.scim_status == "created")
    existed = sum(1 for r in results if r.scim_status == "exists")
    role_updated = sum(1 for r in results if r.role_status == "updated")
    role_correct = sum(1 for r in results if r.role_status == "already_correct")
    errors = [r for r in results if "error" in r.scim_status or "error" in r.role_status]

    print(f"  SCIM 建立:     {created} 個新使用者")
    print(f"  SCIM 已存在:   {existed} 個")
    print(f"  Role 已更新:   {role_updated} 個")
    print(f"  Role 已正確:   {role_correct} 個")
    print(f"  錯誤:          {len(errors)} 個")

    if errors:
        print(f"\n⚠️ 以下使用者有錯誤：")
        for r in errors:
            print(f"  - {r.email}: {r.error_msg}")

    print(f"{'='*60}\n")


# ============================================================
# CLI
# ============================================================

def load_emails_from_csv(csv_path: str) -> list[str]:
    """從 CSV 讀取 email 清單（支援 email / Email / e-mail 等欄位名稱）"""
    emails = []
    with open(csv_path, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        # 找到 email 欄位（不分大小寫）
        email_col = None
        for col in reader.fieldnames or []:
            if col.lower().replace("-", "").replace("_", "") in ("email", "emailaddress", "mail", "useremail"):
                email_col = col
                break

        if not email_col:
            print(f"❌ CSV 中找不到 email 欄位，可用欄位: {reader.fieldnames}")
            sys.exit(1)

        for row in reader:
            email = row[email_col].strip()
            if email and "@" in email:
                emails.append(email)

    return emails


def main():
    parser = argparse.ArgumentParser(
        description="Langfuse 批次使用者佈建工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
範例：
  # 直接指定 email
  python langfuse_batch_provision.py --emails user1@company.com user2@company.com

  # 從 CSV 匯入（需有 email 欄位）
  python langfuse_batch_provision.py --csv users.csv

  # 指定角色
  python langfuse_batch_provision.py --csv users.csv --role MEMBER

  # Dry-run（預覽模式）
  python langfuse_batch_provision.py --csv users.csv --dry-run

  # 只更新既有使用者的 role
  python langfuse_batch_provision.py --csv users.csv --update-role-only

角色說明：
  OWNER   - 完整管理權限
  ADMIN   - 可管理 Organization 設定和專案
  MEMBER  - 可查看及建立 traces、prompts 等 ✅ (你要的)
  VIEWER  - 只能查看
  NONE    - 無預設存取（需另設 project-level role）
        """,
    )

    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--emails", nargs="+", help="直接指定 email 清單")
    group.add_argument("--csv", type=str, help="CSV 檔案路徑（需有 email 欄位）")

    parser.add_argument("--role", type=str, default="MEMBER",
                        choices=["OWNER", "ADMIN", "MEMBER", "VIEWER", "NONE"],
                        help="目標角色 (預設: MEMBER)")
    parser.add_argument("--dry-run", action="store_true", help="只預覽不執行")
    parser.add_argument("--update-role-only", action="store_true",
                        help="跳過 SCIM 建立步驟，只更新既有使用者的 role")
    parser.add_argument("--password", type=str, default=None,
                        help="為新建使用者設定初始密碼（如果用 SSO 則不需要）")
    parser.add_argument("--delay", type=float, default=0.5,
                        help="每個 API 呼叫之間的延遲秒數 (預設: 0.5)")
    parser.add_argument("--base-url", type=str, default=None,
                        help="覆蓋 Langfuse Base URL")
    parser.add_argument("--public-key", type=str, default=None,
                        help="覆蓋 Organization Public Key")
    parser.add_argument("--secret-key", type=str, default=None,
                        help="覆蓋 Organization Secret Key")

    args = parser.parse_args()

    # 覆蓋設定
    global LANGFUSE_BASE_URL, ORG_PUBLIC_KEY, ORG_SECRET_KEY
    global SCIM_BASE, ORG_MEMBERSHIP_URL

    if args.base_url:
        LANGFUSE_BASE_URL = args.base_url.rstrip("/")
        SCIM_BASE = f"{LANGFUSE_BASE_URL}/api/public/scim"
        ORG_MEMBERSHIP_URL = f"{LANGFUSE_BASE_URL}/api/public/organizations/memberships"
    if args.public_key:
        ORG_PUBLIC_KEY = args.public_key
    if args.secret_key:
        ORG_SECRET_KEY = args.secret_key

    # Validate keys
    if "xxxxxxxx" in ORG_PUBLIC_KEY or "xxxxxxxx" in ORG_SECRET_KEY:
        print("❌ 請先設定 Organization API Key！")
        print("   修改腳本頂部的 ORG_PUBLIC_KEY / ORG_SECRET_KEY")
        print("   或使用 --public-key / --secret-key 參數")
        sys.exit(1)

    # 載入 email 清單
    if args.csv:
        emails = load_emails_from_csv(args.csv)
    else:
        emails = args.emails

    if not emails:
        print("❌ 沒有找到任何有效的 email")
        sys.exit(1)

    # 去重
    seen = set()
    unique_emails = []
    for e in emails:
        if e.lower() not in seen:
            seen.add(e.lower())
            unique_emails.append(e)

    if len(unique_emails) < len(emails):
        print(f"⚠️ 移除了 {len(emails) - len(unique_emails)} 個重複的 email\n")

    # 執行
    batch_provision(
        emails=unique_emails,
        target_role=args.role,
        dry_run=args.dry_run,
        update_role_only=args.update_role_only,
        password=args.password,
        delay=args.delay,
    )


if __name__ == "__main__":
    main()
