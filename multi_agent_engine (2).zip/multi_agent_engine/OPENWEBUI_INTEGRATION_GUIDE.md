# Open WebUI + Multi-Agent Engine 整合指南
## 給 Jimmy 的前端串接文件

> 版本: v0.1.0-prototype
> 更新日期: 2024/12/08
> 後端負責人: Colin
> 前端負責人: Jimmy

---

## 🎯 整合架構

```
┌─────────────────────────────────────────────────────────────┐
│                      Open WebUI                              │
│                   (http://localhost:3001)                    │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              Pipe Function                           │   │
│  │         "M公司 AI 助手"                              │   │
│  │                                                      │   │
│  │  • 提取使用者訊息                                    │   │
│  │  • 轉發到 FastAPI 後端                               │   │
│  │  • 串流顯示回應                                      │   │
│  └──────────────────────┬──────────────────────────────┘   │
│                         │                                   │
└─────────────────────────┼───────────────────────────────────┘
                          │ HTTP POST (streaming)
                          ▼
┌─────────────────────────────────────────────────────────────┐
│                 Multi-Agent Engine                           │
│                (http://localhost:8000)                       │
│                                                             │
│  ┌──────────────────┐    ┌──────────────────────────────┐  │
│  │    FastAPI       │───▶│    Orchestrator Agent        │  │
│  │   /api/chat      │    │    (LangGraph)               │  │
│  └──────────────────┘    └──────────────┬───────────────┘  │
│                                         │                   │
│                          ┌──────────────┴──────────────┐   │
│                          ▼                             ▼   │
│                    ┌──────────┐                 ┌──────────┐│
│                    │  Jira    │                 │   FAQ    ││
│                    │  Agent   │                 │  Agent   ││
│                    └──────────┘                 └──────────┘│
└─────────────────────────────────────────────────────────────┘
```

---

## 📋 整合步驟

### Step 1: 確認後端已啟動

```bash
# Colin 的 Multi-Agent Engine
cd multi_agent_engine
pip install -r requirements.txt
python main.py

# 確認服務運行中
curl http://localhost:8000/health
# 應該回傳: {"status": "healthy", ...}
```

### Step 2: 在 Open WebUI 新增 Pipe Function

1. 開啟 Open WebUI: `http://localhost:3001`
2. 點擊右上角頭像 → **Admin Panel**
3. 進入 **Functions** 分頁
4. 點擊 **"+"** 新增 function
5. **複製 `openwebui_pipe_function.py` 的內容貼上**
6. 點擊 **Save**

### Step 3: 使用 M公司 AI 助手

1. 回到聊天頁面
2. 在模型選單中選擇 **"M公司 AI 助手"**
3. 開始對話！

---

## 📁 檔案說明

| 檔案 | 說明 |
|------|------|
| `openwebui_pipe_function.py` | 👈 **Jimmy 要用的！** Open WebUI Pipe Function 程式碼 |
| `main.py` | FastAPI 後端入口 |
| `routers/chat.py` | 聊天 API（支援 text/plain streaming） |

---

## 🔌 API 規格

### POST /api/chat

**Request:**
```json
{
  "message": "查詢我的 Jira tickets",
  "session_id": "open-webui-chat-id",
  "stream": true
}
```

**Response (stream=true):**
- Content-Type: `text/plain`
- 直接串流文字內容，逐 chunk 輸出

**Response (stream=false):**
```json
{
  "conversation_id": "uuid",
  "message": "完整回應內容",
  "agent": "Orchestrator"
}
```

---

## 🔧 Pipe Function 設定

在 Open WebUI 的 Pipe 設定中可以調整：

| 參數 | 預設值 | 說明 |
|------|--------|------|
| `FASTAPI_BASE_URL` | `http://127.0.0.1:8000` | 後端 URL |
| `API_PATH` | `/api/chat` | API 端點路徑 |
| `READ_TIMEOUT` | `120.0` | 讀取超時（秒） |

如果後端部署在其他位置，修改 `FASTAPI_BASE_URL` 即可。

---

## 🧪 測試

### 1. 測試後端 API

```bash
# 非串流模式
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "查詢我的 Jira tickets", "stream": false}'

# 串流模式
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "查詢我的 Jira tickets", "stream": true}'
```

### 2. 測試 Open WebUI 整合

1. 在 Open WebUI 選擇 "M公司 AI 助手"
2. 輸入: "幫我查詢 DEMO 專案的 tickets"
3. 應該看到串流回應

---

## 📅 串接時程

| 日期 | 里程碑 | 狀態 |
|------|--------|------|
| 12/8 (一) 晚上 | Colin 完成 FastAPI 後端 | 🔵 進行中 |
| 12/9 (二) 上午 | Colin 交付後端 + Pipe Function | ⏳ 待進行 |
| 12/9 (二) 上午 | Jimmy 將 Pipe Function 加入 Open WebUI | ⏳ 待進行 |
| 12/9 (二) 下午 | **首次串接測試** 🤝 | ⏳ 待進行 |
| 12/10 (三) | 調整 UI 顯示、錯誤處理 | ⏳ 待進行 |
| 12/12 (五) | **Prototype 交付** | ⏳ 待進行 |

---

## ❓ FAQ

### Q: 看到 "無法連接到後端服務" 錯誤？

**A:** 確認 Multi-Agent Engine 已啟動：
```bash
python main.py
```

### Q: 串流沒有即時顯示？

**A:** 檢查 Open WebUI 設定，確保沒有開啟 response buffering。

### Q: 想顯示 Agent 執行狀態（如 "Jira Agent 使用 search 工具..."）？

**A:** 編輯 `routers/chat.py`，取消 `stream_chat_response` 中 status 輸出的註解：
```python
elif event_type == "status":
    agent = event.get("agent", "")
    tool = event.get("tool")
    if tool:
        yield f"\n🔧 [{agent}] 使用 {tool}...\n"
```

### Q: 需要 SSE 格式的串流？

**A:** 使用 `/api/chat/sse` 端點，提供 `event: status/token/done` 格式的 SSE 事件。

---

## 📞 問題回報

有任何問題請聯繫 Colin 或在 Teams/Slack 群組討論。

**後端測試指令：**
```bash
# 健康檢查
curl http://localhost:8000/health

# 列出 Agents
curl http://localhost:8000/api/agents

# 測試聊天
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello", "stream": false}'
```
