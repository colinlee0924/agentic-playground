"""
Open WebUI Pipe Function - Multi-Agent Engine 整合
====================================================

這個檔案是給 Jimmy 在 Open WebUI 中使用的 Pipe function。

使用方式：
1. 開啟 Open WebUI (http://localhost:3001)
2. 點擊右上角頭像 → Admin Panel
3. 進入 Functions 分頁
4. 點擊 "+" 新增 function
5. 貼上以下程式碼
6. 儲存後，在聊天時選擇 "M公司 AI 助手" 即可使用

注意：需要先啟動 Multi-Agent Engine 後端
     python main.py (預設 http://localhost:8000)
"""

from typing import Any, Dict, Iterator, Optional

import httpx
from pydantic import BaseModel, Field


class Pipe:
    """
    M公司 Multi-Agent Engine Pipe
    
    連接 Open WebUI 到 LangGraph 多代理後端
    """
    
    class Valves(BaseModel):
        """可配置參數 - 可在 Open WebUI 介面中修改"""
        
        FASTAPI_BASE_URL: str = Field(
            default="http://127.0.0.1:8000",
            description="Multi-Agent Engine 後端 URL",
        )
        API_PATH: str = Field(
            default="/api/chat",
            description="聊天 API 端點路徑",
        )
        
        # httpx 超時設定
        CONNECT_TIMEOUT: float = Field(
            default=5.0, 
            description="連線超時 (秒)"
        )
        READ_TIMEOUT: Optional[float] = Field(
            default=120.0,  # LLM 回應可能較慢
            description="讀取超時 (秒)，None = 無限制"
        )
        WRITE_TIMEOUT: float = Field(
            default=10.0, 
            description="寫入超時 (秒)"
        )
        POOL_TIMEOUT: float = Field(
            default=5.0, 
            description="連線池超時 (秒)"
        )

    def __init__(self):
        self.valves = self.Valves()

    def pipes(self):
        """定義可用的 Pipe（會顯示在 Open WebUI 模型選單中）"""
        return [
            {
                "id": "multi_agent_engine.pipe",
                "name": "M公司 AI 助手",
            }
        ]

    # --- 輔助函數 ---

    def _extract_last_user_message(self, body: Dict[str, Any]) -> str:
        """從 Open WebUI 請求中提取最後一則使用者訊息"""
        msgs = body.get("messages") or []
        
        for m in reversed(msgs):
            if m.get("role") == "user":
                content = m.get("content")
                
                # 純文字內容
                if isinstance(content, str):
                    return content.strip()
                
                # 結構化內容 (可能包含圖片等)
                if isinstance(content, list):
                    parts = []
                    for p in content:
                        if (
                            isinstance(p, dict)
                            and p.get("type") == "text"
                            and isinstance(p.get("text"), str)
                        ):
                            parts.append(p["text"])
                    if parts:
                        return "\n".join(parts).strip()
        
        # 備用: 使用 prompt 欄位
        if isinstance(body.get("prompt"), str):
            return body["prompt"].strip()
        
        return ""

    def _iter_stream(
        self,
        url: str,
        payload: Dict[str, Any],
        headers: Dict[str, str],
        timeout: httpx.Timeout,
    ) -> Iterator[str]:
        """串流請求後端並逐 chunk 回傳"""
        try:
            with httpx.Client(timeout=timeout) as client:
                with client.stream("POST", url, json=payload, headers=headers) as resp:
                    if resp.status_code >= 400:
                        try:
                            err = resp.text
                        except Exception:
                            err = ""
                        yield f"❌ API 錯誤 {resp.status_code}: {err or '無錯誤訊息'}"
                        return
                    
                    # 逐 chunk 回傳文字
                    for chunk in resp.iter_bytes():
                        if chunk:
                            yield chunk.decode("utf-8", errors="replace")
                            
        except httpx.ConnectError:
            yield f"❌ 無法連接到後端服務 ({url})。請確認 Multi-Agent Engine 已啟動。"
        except httpx.ReadTimeout:
            yield "❌ 讀取超時，請稍後再試。"
        except httpx.HTTPError as e:
            yield f"❌ HTTP 錯誤: {e}"
        except Exception as e:
            yield f"❌ 未預期的錯誤: {e}"

    # --- 主入口點 ---

    def pipe(self, body: Dict[str, Any], __metadata__: dict):
        """
        Pipe 主函數 - Open WebUI 會呼叫這個函數處理訊息
        
        Args:
            body: Open WebUI 請求內容，包含 messages 陣列
            __metadata__: 中繼資料，包含 chat_id 等
        
        Returns:
            Iterator[str] (串流) 或 str (非串流)
        """
        # 組合 API URL
        base = (self.valves.FASTAPI_BASE_URL or "").rstrip("/")
        path = (self.valves.API_PATH or "").lstrip("/")
        url = f"{base}/{path}"

        # 提取使用者訊息
        user_msg = self._extract_last_user_message(body)
        if not user_msg:
            return "請輸入您的問題。"

        # 建立請求 payload
        chat_req = {
            "message": user_msg,
            "session_id": __metadata__.get("chat_id"),  # 用於對話持久化
            "stream": True
        }

        headers = {"Content-Type": "application/json"}
        timeout = httpx.Timeout(
            connect=self.valves.CONNECT_TIMEOUT,
            read=self.valves.READ_TIMEOUT,
            write=self.valves.WRITE_TIMEOUT,
            pool=self.valves.POOL_TIMEOUT,
        )

        # 檢查是否要串流
        do_stream = body.get("stream", True)

        if do_stream:
            # 回傳 generator，Open WebUI 會串流顯示
            return self._iter_stream(url, chat_req, headers, timeout)

        # 非串流模式: 緩衝完整回應後回傳
        full = ""
        for piece in self._iter_stream(url, chat_req, headers, timeout):
            full += piece
        return full.strip() or "(空回應)"
