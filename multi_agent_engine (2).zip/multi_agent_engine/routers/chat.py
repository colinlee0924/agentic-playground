"""
routers/chat.py - 聊天 API + Streaming
支援 Open WebUI Pipe function 整合

Open WebUI 使用 Pipe function 連接後端，
streaming 使用 text/plain 而非 SSE
"""
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse, JSONResponse
from typing import AsyncGenerator, Optional
import json
import uuid
import asyncio
from datetime import datetime

from schemas.messages import (
    ChatRequest, ChatResponse, AgentStatusUpdate, 
    TokenChunk, ErrorResponse, AgentStatus
)
from agents.orchestrator import OrchestratorAgent

router = APIRouter()

# 全域 Orchestrator 實例
orchestrator = OrchestratorAgent()


# ========== Open WebUI 相容端點 ==========

@router.post("/chat")
async def chat(request: ChatRequest):
    """
    聊天端點 - 支援 streaming (Open WebUI 相容)
    
    Open WebUI Pipe function 使用範例：
    ```python
    with httpx.Client() as client:
        with client.stream("POST", url, json={"message": "...", "session_id": "..."}) as resp:
            for chunk in resp.iter_bytes():
                yield chunk.decode("utf-8")
    ```
    """
    conversation_id = request.conversation_id or str(uuid.uuid4())
    
    if request.stream:
        return StreamingResponse(
            stream_chat_response(request.message, conversation_id),
            media_type="text/plain",  # Open WebUI Pipe 使用 text/plain
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
                "X-Conversation-ID": conversation_id
            }
        )
    else:
        # 非串流模式 - 等待完整結果
        result = await orchestrator.run(request.message, conversation_id)
        return ChatResponse(
            conversation_id=conversation_id,
            message=result["response"],
            agent="Orchestrator",
            execution_trace=result.get("trace")
        )


async def stream_chat_response(
    message: str, 
    conversation_id: str
) -> AsyncGenerator[str, None]:
    """
    Streaming 生成器 - 直接輸出文字
    
    Open WebUI Pipe function 會逐 chunk 接收並顯示
    """
    try:
        has_yielded = False
        
        # 執行 Orchestrator 並串流結果
        async for event in orchestrator.stream(message, conversation_id):
            event_type = event.get("type")
            
            if event_type == "token":
                # 直接輸出 token 內容
                content = event.get("content", "")
                if content:
                    yield content
                    has_yielded = True
            
            elif event_type == "status":
                # 可選：顯示 Agent 狀態 (取消註解以啟用)
                # agent = event.get("agent", "")
                # tool = event.get("tool")
                # if tool:
                #     yield f"\n🔧 [{agent}] 使用 {tool}...\n"
                pass
        
        if not has_yielded:
            yield "抱歉，我無法正確回應您的問題。請嘗試換個方式描述。"
            
    except Exception as e:
        yield f"\n❌ 處理請求時發生錯誤: {str(e)}"


# ========== SSE 端點（給自訂前端使用）==========

@router.post("/chat/sse")
async def chat_sse(request: ChatRequest):
    """
    SSE 串流端點 - 給自訂前端使用（非 Open WebUI）
    
    提供更豐富的事件類型：status, token, done, error
    """
    conversation_id = request.conversation_id or str(uuid.uuid4())
    
    return StreamingResponse(
        stream_sse_response(request.message, conversation_id),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
            "X-Conversation-ID": conversation_id
        }
    )


async def stream_sse_response(
    message: str, 
    conversation_id: str
) -> AsyncGenerator[str, None]:
    """
    SSE 串流生成器 - 包含豐富事件類型
    
    事件格式：
    event: status
    data: {"agent": "JiraAgent", "status": "using_tool", "tool": "search_tickets"}
    
    event: token
    data: {"agent": "Orchestrator", "content": "根據"}
    
    event: done
    data: {"conversation_id": "...", "message": "完整回應"}
    """
    try:
        # 發送開始狀態
        yield format_sse_event("status", {
            "agent": "Orchestrator",
            "status": "thinking",
            "detail": "分析使用者請求中..."
        })
        
        full_response = ""
        trace = []
        
        async for event in orchestrator.stream(message, conversation_id):
            event_type = event.get("type")
            
            if event_type == "status":
                trace.append(event)
                yield format_sse_event("status", event)
                
            elif event_type == "token":
                content = event.get("content", "")
                full_response += content
                yield format_sse_event("token", {
                    "agent": event.get("agent", "Orchestrator"),
                    "content": content
                })
        
        # 發送完成事件
        yield format_sse_event("done", {
            "conversation_id": conversation_id,
            "message": full_response,
            "trace": trace
        })
        
    except Exception as e:
        yield format_sse_event("error", {
            "message": "處理請求時發生錯誤",
            "detail": str(e)
        })


def format_sse_event(event_type: str, data: dict) -> str:
    """格式化 SSE 事件"""
    def json_serial(obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        raise TypeError(f"Type {type(obj)} not serializable")
    
    json_data = json.dumps(data, default=json_serial, ensure_ascii=False)
    return f"event: {event_type}\ndata: {json_data}\n\n"


# ========== 其他端點 ==========

@router.get("/conversations/{conversation_id}")
async def get_conversation(conversation_id: str):
    """取得對話歷史（如果有實作 checkpointing）"""
    return {
        "conversation_id": conversation_id,
        "messages": [],
        "status": "not_implemented_yet"
    }


@router.get("/agents")
async def list_agents():
    """列出可用的 Agents（供前端顯示）"""
    return {
        "agents": [
            {
                "id": "orchestrator",
                "name": "Orchestrator",
                "description": "主要協調者，負責理解請求並分派給專業 Agent"
            },
            {
                "id": "jira_agent", 
                "name": "Jira Agent",
                "description": "處理 Jira 相關查詢、建立和更新 tickets",
                "status": "active"
            },
            {
                "id": "faq_agent",
                "name": "FAQ Agent", 
                "description": "回答公司內部常見問題",
                "status": "coming_soon"
            }
        ]
    }
