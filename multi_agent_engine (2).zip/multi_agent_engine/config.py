"""
config.py - 配置管理
"""
from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    """應用程式設定"""
    
    # 應用程式
    APP_NAME: str = "Multi-Agent Engine"
    DEBUG: bool = True
    
    # Phoenix Tracing
    PHOENIX_ENDPOINT: str = "http://localhost:6006/v1/traces"
    PHOENIX_PROJECT_NAME: str = "multi-agent-prototype"
    
    # LLM 設定 (根據你的環境調整)
    LLM_PROVIDER: str = "openai"  # openai, azure, bedrock, ollama
    OPENAI_API_KEY: Optional[str] = None
    OPENAI_MODEL: str = "gpt-4"
    
    # Azure OpenAI (如果使用)
    AZURE_OPENAI_ENDPOINT: Optional[str] = None
    AZURE_OPENAI_API_KEY: Optional[str] = None
    AZURE_OPENAI_DEPLOYMENT: Optional[str] = None
    
    # Ollama (本地開發)
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_MODEL: str = "llama3.2"
    
    # Jira MCP Server (你已有的)
    JIRA_MCP_SERVER_URL: str = "http://localhost:3000"
    
    # Database (POC 用 SQLite)
    DATABASE_URL: str = "sqlite:///./checkpoints.db"
    
    class Config:
        env_file = ".env"
        extra = "ignore"

settings = Settings()
